/**
 * MAIN world hook on naukri.com — captures nkparam + job search API responses.
 * Isolated bridge (content-naukri-bridge.js) persists nkparam via chrome.storage.
 */
;(function () {
  if (window.__kgNaukriHookInstalled) return
  window.__kgNaukriHookInstalled = true

  const SOURCE = 'kareergrowth-naukri-bridge'

  function emitNkparam(nkparam) {
    const nk = String(nkparam || '').trim()
    if (!nk) return
    try {
      window.__kgLastNkparam = nk
      window.__kgLastNkparamAt = Date.now()
    } catch {
      /* ignore */
    }
    try {
      window.postMessage({ source: SOURCE, type: 'NAUKRI_NKPARAM', payload: { nkparam: nk } }, window.location.origin)
    } catch {
      /* ignore */
    }
  }

  function pageNoFromSearchUrl(url) {
    try {
      const u = new URL(String(url || ''), window.location.origin)
      return Math.max(1, parseInt(u.searchParams.get('pageNo'), 10) || 1)
    } catch {
      return 1
    }
  }

  function emitSearchData(data, url) {
    if (!data || !Array.isArray(data.jobDetails) || !data.jobDetails.length) return
    const pageNo = pageNoFromSearchUrl(url)
    try {
      window.__kgLastSearchData = data
      window.__kgLastSearchAt = Date.now()
      window.__kgLastSearchPageNo = pageNo
      window.__kgLastSearchSid = data.sid || window.__kgLastSearchSid || null
    } catch {
      /* ignore */
    }
    try {
      window.postMessage(
        { source: SOURCE, type: 'NAUKRI_SEARCH_DATA', payload: { pageNo, jobCount: data.jobDetails.length } },
        window.location.origin
      )
    } catch {
      /* ignore */
    }
  }

  function readNkparamFromHeaders(headers) {
    if (!headers) return ''
    try {
      if (typeof Headers !== 'undefined' && headers instanceof Headers) {
        return headers.get('nkparam') || headers.get('Nkparam') || headers.get('NKPARAM') || ''
      }
      if (Array.isArray(headers)) {
        const hit = headers.find(function (row) {
          return String(row[0] || '').toLowerCase() === 'nkparam'
        })
        return hit ? hit[1] : ''
      }
      if (typeof headers === 'object') {
        return headers.nkparam || headers.Nkparam || headers.NKPARAM || headers['nkparam'] || ''
      }
    } catch {
      /* ignore */
    }
    return ''
  }

  function isNaukriApiUrl(url) {
    try {
      const u = typeof url === 'string' ? url : url && url.url ? url.url : ''
      if (!u || u.indexOf('naukri.com') === -1) return false
      return u.indexOf('jobapi') !== -1 || u.indexOf('/jobapi/') !== -1
    } catch {
      return false
    }
  }

  function isSearchApiUrl(url) {
    const u = String(url || '')
    return u.indexOf('/jobapi/v3/search') !== -1 || u.indexOf('jobapi/v3/search') !== -1
  }

  const origFetch = window.fetch
  window.fetch = function patchedFetch(input, init) {
    let url = ''
    try {
      url = typeof input === 'string' ? input : input && input.url ? input.url : ''
      if (isNaukriApiUrl(url)) {
        let nk = readNkparamFromHeaders(init && init.headers)
        if (!nk && typeof Request !== 'undefined' && input instanceof Request) {
          nk = readNkparamFromHeaders(input.headers)
        }
        emitNkparam(nk)
      }
    } catch {
      /* ignore */
    }

    return origFetch.apply(this, arguments).then(function (response) {
      try {
        if (isNaukriApiUrl(url) && isSearchApiUrl(url) && response && response.ok) {
          response
            .clone()
            .json()
            .then(function (data) {
              emitSearchData(data, url)
            })
            .catch(function () {})
        }
      } catch {
        /* ignore */
      }
      return response
    })
  }

  const origOpen = XMLHttpRequest.prototype.open
  const origSetHeader = XMLHttpRequest.prototype.setRequestHeader
  const origSend = XMLHttpRequest.prototype.send

  XMLHttpRequest.prototype.open = function (method, url) {
    this.__naukriUrl = url
    this.__naukriNkparam = ''
    return origOpen.apply(this, arguments)
  }

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (String(name).toLowerCase() === 'nkparam') {
      this.__naukriNkparam = String(value || '').trim()
    }
    return origSetHeader.apply(this, arguments)
  }

  XMLHttpRequest.prototype.send = function () {
    const xhr = this
    try {
      if (isNaukriApiUrl(xhr.__naukriUrl) && xhr.__naukriNkparam) {
        emitNkparam(xhr.__naukriNkparam)
      }
      if (isNaukriApiUrl(xhr.__naukriUrl) && isSearchApiUrl(xhr.__naukriUrl)) {
        xhr.addEventListener('load', function () {
          try {
            if (xhr.status < 200 || xhr.status >= 300) return
            const data = JSON.parse(xhr.responseText || '{}')
            emitSearchData(data, xhr.__naukriUrl)
          } catch {
            /* ignore */
          }
        })
      }
    } catch {
      /* ignore */
    }
    return origSend.apply(this, arguments)
  }
})()
