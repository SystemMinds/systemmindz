/**
 * Capture Monster session metadata from page network requests (MAIN world).
 * Chains fetch/XHR so re-injection on sync still wraps DataDome's patched fetch.
 */
(function installMonsterPageHook() {
  function readHeader(headers, name) {
    if (!headers) return '';
    const want = String(name).toLowerCase();
    try {
      if (typeof Headers !== 'undefined' && headers instanceof Headers) {
        return headers.get(name) || headers.get(want) || '';
      }
      if (Array.isArray(headers)) {
        const hit = headers.find(([k]) => String(k || '').toLowerCase() === want);
        return hit ? hit[1] : '';
      }
      if (typeof headers === 'object') {
        for (const [k, v] of Object.entries(headers)) {
          if (String(k).toLowerCase() === want) return v;
        }
      }
    } catch {
      /* ignore */
    }
    return '';
  }

  function captureFromHeaders(headers) {
    const dd = readHeader(headers, 'x-datadome-clientid');
    if (dd) window.__kgMonsterDatadomeClientId = String(dd).trim();
    const pid = readHeader(headers, 'profile-id');
    if (pid) window.__kgMonsterProfileId = String(pid).trim();
  }

  function captureFromBody(bodyText, url) {
    if (!bodyText || typeof bodyText !== 'string') return;
    const u = String(url || '');
    if (!u.includes('monster.io') && !u.includes('search-jobs')) return;
    try {
      const body = JSON.parse(bodyText);
      if (body.fingerprintId) window.__kgMonsterFingerprintId = String(body.fingerprintId).trim();
      if (body.profileId) window.__kgMonsterProfileId = String(body.profileId).trim();
    } catch {
      /* ignore */
    }
  }

  function isMonsterApiUrl(url) {
    try {
      const u = String(url || '');
      return u.includes('appsapi.monster.io') || u.includes('search-jobs');
    } catch {
      return false;
    }
  }

  function emitSession() {
    const payload = {
      datadomeClientId: String(window.__kgMonsterDatadomeClientId || '').trim(),
      profileId: String(window.__kgMonsterProfileId || '').trim(),
      fingerprintId: String(window.__kgMonsterFingerprintId || '').trim(),
    };
    if (!payload.datadomeClientId && !payload.profileId) return;
    try {
      window.postMessage(
        { source: 'kg-monster-page-hook', type: 'MONSTER_SESSION_SNAPSHOT', payload },
        window.location.origin
      );
    } catch {
      /* ignore */
    }
  }

  function captureFromStores() {
    const readStore = (store) => {
      if (!store) return;
      try {
        for (let i = 0; i < store.length; i += 1) {
          const key = String(store.key(i) || '');
          const val = String(store.getItem(key) || '').trim();
          if (!val) continue;
          const kl = key.toLowerCase();
          if (!window.__kgMonsterProfileId && kl.includes('profile') && /^[0-9a-f-]{36}$/i.test(val)) {
            window.__kgMonsterProfileId = val;
          }
          if (!window.__kgMonsterFingerprintId && kl.includes('fingerprint') && val.length >= 16 && val.length <= 64) {
            window.__kgMonsterFingerprintId = val;
          }
          if (!window.__kgMonsterDatadomeClientId && kl.includes('datadome') && val.length >= 20) {
            window.__kgMonsterDatadomeClientId = val;
          }
          if (val.startsWith('{')) {
            try {
              const parsed = JSON.parse(val);
              if (parsed.profileId) window.__kgMonsterProfileId = String(parsed.profileId).trim();
              if (parsed.fingerprintId) window.__kgMonsterFingerprintId = String(parsed.fingerprintId).trim();
            } catch {
              /* ignore */
            }
          }
        }
      } catch {
        /* ignore */
      }
    };
    readStore(window.localStorage);
    readStore(window.sessionStorage);
    try {
      if (!window.__kgMonsterDatadomeClientId && window.DD?.clientId) {
        window.__kgMonsterDatadomeClientId = String(window.DD.clientId).trim();
      }
    } catch {
      /* ignore */
    }
  }

  captureFromStores();

  const prevFetch = window.fetch.bind(window);
  window.fetch = async function patchedFetch(input, init) {
    try {
      const url = typeof input === 'string' ? input : input?.url || '';
      if (isMonsterApiUrl(url)) {
        captureFromHeaders(init?.headers);
        if (typeof Request !== 'undefined' && input instanceof Request) {
          captureFromHeaders(input.headers);
        }
        const bodyText =
          typeof init?.body === 'string'
            ? init.body
            : init?.body && typeof init.body === 'object' && typeof init.body.text === 'function'
              ? null
              : null;
        if (bodyText) captureFromBody(bodyText, url);
      }
    } catch {
      /* ignore */
    }
    const res = await prevFetch(input, init);
    try {
      const url = typeof input === 'string' ? input : input?.url || '';
      if (isMonsterApiUrl(url)) {
        // DataDome mutates init.headers inside its fetch wrapper — capture after the call.
        captureFromHeaders(init?.headers);
        if (typeof Request !== 'undefined' && input instanceof Request) {
          captureFromHeaders(input.headers);
        }
        emitSession();
      }
    } catch {
      /* ignore */
    }
    return res;
  };

  const prevXhrOpen = XMLHttpRequest.prototype.open;
  const prevXhrSetHeader = XMLHttpRequest.prototype.setRequestHeader;
  const prevXhrSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (...args) {
    this.__kgMonsterUrl = String(args[1] || '');
    return prevXhrOpen.apply(this, args);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    try {
      const n = String(name || '').toLowerCase();
      if (n === 'x-datadome-clientid' && value) {
        window.__kgMonsterDatadomeClientId = String(value).trim();
      }
      if (n === 'profile-id' && value) {
        window.__kgMonsterProfileId = String(value).trim();
      }
    } catch {
      /* ignore */
    }
    return prevXhrSetHeader.call(this, name, value);
  };

  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (isMonsterApiUrl(this.__kgMonsterUrl)) {
        if (typeof body === 'string') captureFromBody(body, this.__kgMonsterUrl);
        this.addEventListener('loadend', () => emitSession(), { once: true });
      }
    } catch {
      /* ignore */
    }
    return prevXhrSend.call(this, body);
  };

  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || event.data.source !== 'kg-monster-bridge') return;
    if (event.data.type !== 'REQUEST_MONSTER_SESSION') return;
    captureFromStores();
    window.postMessage(
      {
        source: 'kg-monster-page-hook',
        type: 'MONSTER_SESSION_SNAPSHOT',
        payload: {
          datadomeClientId: window.__kgMonsterDatadomeClientId || '',
          profileId: window.__kgMonsterProfileId || '',
          fingerprintId: window.__kgMonsterFingerprintId || '',
        },
      },
      window.location.origin
    );
  });

  window.__kgMonsterPageHookInstalled = true;
})();
