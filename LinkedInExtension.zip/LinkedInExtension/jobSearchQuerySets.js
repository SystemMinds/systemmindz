/** ESM mirror of shared/jobSearchQuerySets.js for the extension service worker. */

import { resolveIndeedJobTitle } from './jobSearchPrefs.js'

const DEFAULT_TARGET = 15
const MAX_TARGET = 25
const MAX_QUERY_SETS = 28
const MAX_SKILLS_IN_QUERIES = 24

function normalizeSkillList(skills) {
  if (!skills) return []
  if (Array.isArray(skills)) return skills.map((s) => String(s).trim()).filter(Boolean)
  return String(skills)
    .split(/[,;|]/)
    .map((s) => s.trim())
    .filter(Boolean)
}

export function mergeResumeSearchSkills(skills, skillsStr) {
  const out = []
  const seen = new Set()
  const add = (list) => {
    for (const raw of normalizeSkillList(list)) {
      const key = raw.toLowerCase()
      if (!key || key.length < 2 || seen.has(key)) continue
      seen.add(key)
      out.push(raw)
    }
  }
  add(skills)
  add(skillsStr)
  return out.slice(0, MAX_SKILLS_IN_QUERIES)
}

function resolvePrimaryTitle(input = {}) {
  const targetRole = String(input.targetRole || '').trim()
  const prefTitle = String(input.jobTitle || '').trim()
  const keywords = String(input.keywords || '').trim()
  if (targetRole) return targetRole
  return prefTitle || keywords.split(/\s+/).slice(0, 6).join(' ') || ''
}

function buildResumeDrivenQuerySets(platform, input = {}) {
  const skills = mergeResumeSearchSkills(input.skills, input.skillsStr)
  const experienceTitles = normalizeSkillList(input.experienceTitles).slice(0, 5)
  let primaryTitle = resolvePrimaryTitle(input)

  if (platform === 'indeed' || platform === 'naukri') {
    primaryTitle =
      resolveIndeedJobTitle({
        jobTitle: input.jobTitle,
        keywords: input.keywords,
        targetRole: input.targetRole,
        skills: skills.length ? skills : input.skills || input.skillsStr,
        combinedKeywords: input.combinedKeywords,
      }) || primaryTitle
  }

  const queries = []
  const seen = new Set()
  const add = (q) => {
    const text = String(q || '').trim()
    const key = text.toLowerCase()
    if (!text || seen.has(key)) return
    seen.add(key)
    queries.push(text)
  }

  if (primaryTitle) add(primaryTitle)

  for (const title of experienceTitles) {
    if (!primaryTitle || title.toLowerCase() !== primaryTitle.toLowerCase()) add(title)
  }

  for (const skill of skills) add(skill)

  for (let i = 0; i < Math.min(skills.length - 1, 8); i += 1) {
    add(`${skills[i]} ${skills[i + 1]}`)
  }

  if (primaryTitle) {
    for (const skill of skills.slice(0, 10)) add(`${primaryTitle} ${skill}`)
  }

  for (const skill of skills.slice(0, 3)) {
    if (!/\b(developer|engineer|architect|lead|manager|consultant|analyst)\b/i.test(skill)) {
      add(`${skill} developer`)
    }
  }

  if (skills.length >= 3) add(skills.slice(0, 3).join(' '))
  if (skills.length >= 5) add(skills.slice(0, 5).join(' '))

  if (!queries.length) {
    const fallback = String(input.combinedKeywords || input.keywords || '').trim()
    if (fallback) add(fallback)
  }

  return queries.length ? queries.slice(0, MAX_QUERY_SETS) : ['software engineer']
}

export function buildJobSearchQuerySets(platform, input = {}) {
  return buildResumeDrivenQuerySets(platform, input)
}

export function resolvePerQueryJobBudget(targetCount, queryCount) {
  const target = Math.max(5, Number(targetCount) || DEFAULT_TARGET)
  const queries = Math.max(1, Number(queryCount) || 1)
  return Math.min(4, Math.max(2, Math.ceil(target / queries)))
}

export function resolveJobSearchTarget(raw, fallback = DEFAULT_TARGET) {
  const n = parseInt(String(raw ?? ''), 10)
  if (!Number.isFinite(n) || n < 1) return fallback
  return Math.min(MAX_TARGET, Math.max(5, n))
}

export function resolveJobsPerApiRequest(raw) {
  const n = parseInt(String(raw ?? ''), 10)
  if (!Number.isFinite(n) || n < 1) return DEFAULT_TARGET
  return Math.min(20, Math.max(10, n))
}

export { DEFAULT_TARGET as DEFAULT_JOB_SEARCH_TARGET, MAX_TARGET as MAX_JOB_SEARCH_TARGET }
