/**
 * Naukri HTTP client for the extension service worker (browser cookies + nkparam).
 * Mirrors LinkedInExtension/indeedClient.js — no tabs opened; cookies passed to jobapi.
 */

const NAUKRI_ORIGINS = [
  'https://www.naukri.com',
  'https://naukri.com',
  'https://login.naukri.com',
  'https://my.naukri.com',
  'https://login.recruit.naukri.com',
  'https://recruit.naukri.com',
]

export const NAUKRI_BASE = 'https://www.naukri.com'
const NAUKRI_TAB_URLS = ['https://www.naukri.com/*', 'https://*.naukri.com/*']
export { NAUKRI_TAB_URLS }

/** Cookies that indicate an authenticated Naukri session when present. */
const NAUKRI_AUTH_COOKIE_NAMES = ['nauk_at', 'nauk_sid', 'JSESSIONID', 'nnuid', 'NNUID', 'PS']

export async function getAllNaukriCookies(baseUrl = NAUKRI_BASE) {
  const all = []
  for (const origin of NAUKRI_ORIGINS) {
    try {
      const batch = await chrome.cookies.getAll({ url: origin })
      if (Array.isArray(batch)) all.push(...batch)
    } catch {
      /* ignore per-origin failures */
    }
  }
  try {
    const batch = await chrome.cookies.getAll({ url: baseUrl })
    if (Array.isArray(batch)) all.push(...batch)
  } catch {
    /* ignore */
  }
  const seen = new Set()
  const unique = []
  for (const c of all) {
    const key = `${c.domain}|${c.name}`
    if (seen.has(key)) continue
    seen.add(key)
    unique.push(c)
  }
  return unique
}

export function cookieValue(cookies, name) {
  const hit = cookies.find((c) => String(c.name).toLowerCase() === String(name).toLowerCase())
  return hit?.value ? String(hit.value).trim() : ''
}

export function buildCookieHeader(cookies) {
  return cookies
    .filter((c) => c?.name && c?.value != null)
    .map((c) => `${c.name}=${c.value}`)
    .join('; ')
}

export function isLoggedIn(cookies) {
  if (!Array.isArray(cookies) || !cookies.length) return false

  if (cookieValue(cookies, 'nauk_at')) return true
  if (cookieValue(cookies, 'nauk_sid')) return true

  const jsession = cookieValue(cookies, 'JSESSIONID')
  if (jsession && cookies.length >= 2) return true

  const names = cookies.map((c) => String(c.name || '').toLowerCase())
  if (names.some((n) => NAUKRI_AUTH_COOKIE_NAMES.some((auth) => n === auth.toLowerCase()))) {
    return true
  }

  return names.some(
    (n) => n.includes('nauk') && (n.includes('session') || n.includes('at') || n.includes('sid') || n.includes('token'))
  )
}

export function isNaukriAuthCookie(name) {
  const n = String(name || '').toLowerCase()
  if (NAUKRI_AUTH_COOKIE_NAMES.some((c) => c.toLowerCase() === n)) return true
  return n.includes('nauk') && (n.includes('at') || n.includes('sid') || n.includes('session'))
}

export async function getNaukriSessionSnapshot() {
  const cookies = await getAllNaukriCookies()
  const cookieHeader = buildCookieHeader(cookies)
  const { naukriNkparam = '', naukriNkparamAt = '' } = await chrome.storage.local.get([
    'naukriNkparam',
    'naukriNkparamAt',
  ])
  const nkparam = String(naukriNkparam || '').trim()
  return {
    loggedIn: isLoggedIn(cookies),
    cookieHeader,
    nkparam,
    hasNkparam: Boolean(nkparam),
    nkparamAt: naukriNkparamAt || null,
    cookieCount: cookies.length,
    authCookies: cookies.filter((c) => isNaukriAuthCookie(c.name)).map((c) => c.name),
  }
}

function slugifySeoKey(keyword) {
  const slug = String(keyword || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
  return slug ? `${slug}-jobs` : ''
}

/** SEO job-list URL / Referer — matches www.naukri.com.json HAR. */
export function buildNaukriSearchReferer(keyword) {
  const k = String(keyword || '').trim()
  if (!k) return `${NAUKRI_BASE}/`
  const seoKey = slugifySeoKey(k)
  return `${NAUKRI_BASE}/${seoKey}?k=${encodeURIComponent(k)}&nignbevent_src=jobsearchDeskGNB`
}

/**
 * Build headers for Naukri jobapi calls from browser cookies (LinkedIn/Indeed pattern).
 */
export async function buildNaukriHeaders(opts = {}) {
  const cookies = await getAllNaukriCookies()
  const cookieHeader = buildCookieHeader(cookies)
  const snap = await getNaukriSessionSnapshot()
  const nkparam = String(opts.nkparam || snap.nkparam || '').trim()

  if (!cookies.length) {
    const err = new Error('Not logged into Naukri (no cookies). Open naukri.com and sign in.')
    err.code = 'NAUKRI_NOT_LOGGED_IN'
    throw err
  }

  const referer = opts.referer || `${NAUKRI_BASE}/`
  const headers = {
    Accept: 'application/json',
    'Accept-Language': 'en-US,en;q=0.9',
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    Pragma: 'no-cache',
    appid: '109',
    clientid: 'd3skt0p',
    systemid: 'Naukri',
    gid: 'LOCATION,INDUSTRY,EDUCATION,FAREA_ROLE',
    Origin: NAUKRI_BASE,
    Referer: referer,
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
  }
  if (cookieHeader) headers.Cookie = cookieHeader
  if (nkparam) headers.nkparam = nkparam

  return { headers, cookies, cookieHeader, nkparam, referer }
}

/**
 * GET jobapi (or other Naukri URL) using browser cookies — no new tabs.
 */
export async function naukriFetch(url, options = {}) {
  const built = await buildNaukriHeaders({
    referer: options.referer,
    nkparam: options.nkparam,
  })

  const res = await fetch(url, {
    method: options.method || 'GET',
    headers: { ...built.headers, ...(options.headers || {}) },
    credentials: 'include',
    body: options.body,
  })

  const text = await res.text()
  let data = null
  try {
    data = text ? JSON.parse(text) : {}
  } catch {
    data = { message: text.slice(0, 400) }
  }

  if (res.status === 401 || res.status === 403) {
    const err = new Error('Naukri session expired or blocked. Log in on naukri.com and sync again.')
    err.code = 'COOKIE_EXPIRED'
    err.status = res.status
    err.data = data
    throw err
  }
  if (res.status === 429) {
    const err = new Error('Naukri rate limited this request. Wait and retry.')
    err.code = 'RATE_LIMITED'
    err.status = res.status
    err.data = data
    throw err
  }

  return { res, data, built }
}

/** Verify Naukri cookies via jobapi (same as LinkedIn sync probe). */
export async function probeNaukriCookieSession() {
  const snap = await getNaukriSessionSnapshot()
  if (!snap.loggedIn || !snap.cookieHeader) {
    return { ok: false, reason: 'NAUKRI_NOT_LOGGED_IN' }
  }

  const referer = buildNaukriSearchReferer('software engineer')
  const probeUrl =
    `${NAUKRI_BASE}/jobapi/v3/search?` +
    new URLSearchParams({
      noOfResults: '1',
      urlType: 'search_by_keyword',
      searchType: 'adv',
      keyword: 'software',
      k: 'software',
      pageNo: '1',
      src: 'jobsearchDesk',
      latLong: '',
      nignbevent_src: 'jobsearchDeskGNB',
      seoKey: 'software-engineer-jobs',
    }).toString()

  try {
    const { res, data } = await naukriFetch(probeUrl, { referer, nkparam: snap.nkparam })
    if (res.status === 406) {
      return { ok: false, reason: 'NAUKRI_NEEDS_NKPARAM', status: 406, message: data?.message }
    }
    if (!res.ok) {
      return { ok: false, reason: 'PROBE_HTTP', status: res.status }
    }
    if (data.isLoggedIn === false) {
      return { ok: false, reason: 'NAUKRI_NOT_LOGGED_IN' }
    }
    return {
      ok: true,
      hasNkparam: snap.hasNkparam,
      jobCount: Array.isArray(data.jobDetails) ? data.jobDetails.length : 0,
    }
  } catch (e) {
    if (e?.code === 'COOKIE_EXPIRED') return { ok: false, reason: 'COOKIE_EXPIRED' }
    return { ok: false, reason: 'NETWORK', message: e?.message || String(e) }
  }
}

/** Read nkparam from extension storage or an already-open naukri.com tab (never opens tabs). */
export async function captureNkparamSilently() {
  const fromOpen = await pullNkparamFromOpenNaukriTabs()
  if (fromOpen) return fromOpen

  const stored = await chrome.storage.local.get('naukriNkparam')
  const nk = String(stored.naukriNkparam || '').trim()
  return nk || null
}

/** Read nkparam from open Naukri tabs only — does not create or navigate tabs. */
export async function pullNkparamFromOpenNaukriTabs() {
  let tabs = []
  try {
    tabs = await chrome.tabs.query({ url: NAUKRI_TAB_URLS })
  } catch {
    return null
  }

  for (const tab of tabs) {
    if (!tab?.id) continue
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: () => String(window.__kgLastNkparam || '').trim(),
      })
      const nk = String(result || '').trim()
      if (nk) {
        await chrome.storage.local.set({
          naukriNkparam: nk,
          naukriNkparamAt: new Date().toISOString(),
          naukriHasNkparam: true,
        })
        return nk
      }
    } catch {
      /* tab may be restricted */
    }
  }
  return null
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function waitForTabLoad(tabId, timeoutMs = 28000) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => resolve(false), timeoutMs)
    const listener = (updatedTabId, info) => {
      if (updatedTabId === tabId && info.status === 'complete') {
        clearTimeout(timeout)
        chrome.tabs.onUpdated.removeListener(listener)
        resolve(true)
      }
    }
    chrome.tabs.onUpdated.addListener(listener)
    chrome.tabs
      .get(tabId)
      .then((t) => {
        if (t?.status === 'complete') {
          clearTimeout(timeout)
          chrome.tabs.onUpdated.removeListener(listener)
          resolve(true)
        }
      })
      .catch(() => {})
  })
}

async function readNaukriCaptureState(tabId) {
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: () => {
        const href = String(location.href || '')
        const onLogin =
          /login\.naukri\.com/i.test(href) ||
          (/\/login/i.test(href) && !/jobs|job-listings|jobapi/i.test(href))
        return {
          nk: String(window.__kgLastNkparam || '').trim(),
          searchData: window.__kgLastSearchData || null,
          searchAt: Number(window.__kgLastSearchAt || 0),
          sid: window.__kgLastSearchSid || null,
          onLogin,
        }
      },
    })
    return result || null
  } catch {
    return null
  }
}

/**
 * Opens a background Naukri job-list tab, waits for nkparam + search API response, then closes the tab.
 * Used when nkparam is missing or jobapi returns 406 from the service worker.
 */
export async function captureNkparamViaBackgroundTab({ keyword, timeoutMs = 48000 } = {}) {
  const k = String(keyword || 'software engineer').trim() || 'software engineer'
  const searchUrl = buildNaukriSearchReferer(k)
  let tab = null

  try {
    tab = await chrome.tabs.create({ url: searchUrl, active: false })
    const tabId = tab?.id
    if (!tabId) return { nkparam: null, searchData: null, sid: null }

    await waitForTabLoad(tabId, Math.min(timeoutMs, 28000))
    await sleep(1200)

    const deadline = Date.now() + timeoutMs
    let nkparam = null
    let searchData = null
    let sid = null

    while (Date.now() < deadline) {
      const state = await readNaukriCaptureState(tabId)
      if (state?.onLogin) {
        const err = new Error('Log in on naukri.com in Chrome, then sync Naukri and search again.')
        err.code = 'NAUKRI_NOT_LOGGED_IN'
        throw err
      }
      if (state?.nk) nkparam = state.nk
      if (state?.searchData?.jobDetails?.length) {
        searchData = state.searchData
        sid = state.searchData.sid || state.sid || sid
      } else if (state?.sid) {
        sid = state.sid
      }

      const stored = await chrome.storage.local.get('naukriNkparam')
      const storedNk = String(stored.naukriNkparam || '').trim()
      if (storedNk) nkparam = storedNk

      if (nkparam && searchData) break
      if (nkparam && Date.now() > deadline - 7000) break

      await sleep(650)
    }

    if (nkparam) {
      await chrome.storage.local.set({
        naukriNkparam: nkparam,
        naukriNkparamAt: new Date().toISOString(),
        naukriHasNkparam: true,
      })
    }

    return { nkparam, searchData, sid }
  } finally {
    if (tab?.id) chrome.tabs.remove(tab.id).catch(() => {})
  }
}
