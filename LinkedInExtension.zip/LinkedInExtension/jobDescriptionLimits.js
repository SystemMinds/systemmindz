/** ESM mirror of shared/jobDescriptionLimits.js */

export const MAX_JOB_DESCRIPTION_LEN = 50000
export const MIN_FULL_DESCRIPTION_LEN = 300

export function capJobDescription(raw) {
  const text = String(raw || '').trim()
  if (!text) return ''
  return text.length > MAX_JOB_DESCRIPTION_LEN ? text.slice(0, MAX_JOB_DESCRIPTION_LEN) : text
}

export function needsDescriptionEnrichment(raw) {
  return String(raw || '').trim().length < MIN_FULL_DESCRIPTION_LEN
}
