/**
 * Multi-origin LinkedIn cookie collection (mirrors Indeed/Naukri pattern).
 */

const LINKEDIN_ORIGINS = [
  'https://www.linkedin.com',
  'https://linkedin.com',
]

export async function getAllLinkedInCookies() {
  const all = []
  for (const origin of LINKEDIN_ORIGINS) {
    try {
      const batch = await chrome.cookies.getAll({ url: origin })
      if (Array.isArray(batch)) all.push(...batch)
    } catch {
      /* ignore per-origin failures */
    }
  }
  try {
    const batch = await chrome.cookies.getAll({ domain: 'linkedin.com' })
    if (Array.isArray(batch)) all.push(...batch)
  } catch {
    /* ignore */
  }
  const seen = new Set()
  const unique = []
  for (const c of all) {
    const key = `${c.domain}|${c.name}`
    if (seen.has(key)) continue
    seen.add(key)
    unique.push(c)
  }
  return unique
}

export function buildLinkedInCookieHeader(cookies) {
  return cookies.map((c) => `${c.name}=${c.value}`).join('; ')
}

export async function getLinkedInAuthCookies() {
  const cookies = await getAllLinkedInCookies()
  const liAt = cookies.find((c) => c.name === 'li_at')
  const jsession = cookies.find((c) => c.name === 'JSESSIONID')
  return {
    cookies,
    cookieHeader: buildLinkedInCookieHeader(cookies),
    liAtCookie: liAt || null,
    jsessionCookie: jsession || null,
  }
}
