/**
 * Isolated world bridge on naukri.com — stores nkparam from page hook into extension storage.
 */
;(function () {
  const SOURCE = 'kareergrowth-naukri-bridge'

  function persistNkparam(nkparam) {
    const nk = String(nkparam || '').trim()
    if (!nk) return
    try {
      chrome.storage.local.set({ naukriNkparam: nk, naukriNkparamAt: new Date().toISOString() }, () => {
        try {
          chrome.runtime?.sendMessage?.({ type: 'NAUKRI_NKPARAM_CAPTURED', nkparam: nk })
        } catch {
          /* ignore */
        }
      })
    } catch {
      /* ignore */
    }
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data) return
    if (event.data.source !== SOURCE || event.data.type !== 'NAUKRI_NKPARAM') return
    persistNkparam(event.data.payload?.nkparam)
  })

  try {
    chrome.runtime?.sendMessage?.({ type: 'NAUKRI_PAGE_ACTIVE' })
  } catch {
    /* ignore */
  }
})()
