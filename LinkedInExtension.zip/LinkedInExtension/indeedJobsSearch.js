/**
 * Indeed job discovery from the extension service worker (browser session).
 * Search: SSR HTML at /jobs with embedded mosaic-provider-jobcards JSON.
 * Details: JSON viewjob API (confirmed in in.indeed.com.json HAR capture).
 */

import { indeedFetch, resolveIndeedBase } from './indeedClient.js'
import { analyzeIndeedPage, buildIndeedJobsSearchUrl } from './indeedSecurityCheck.js'
import { resolveIndeedJobTitle, resolvePostedWithinDays } from './jobSearchPrefs.js'
import {
  buildJobSearchQuerySets,
  mergeResumeSearchSkills,
  resolveJobSearchTarget,
  resolveJobsPerApiRequest,
  resolvePerQueryJobBudget,
} from './jobSearchQuerySets.js'
import { extractIndeedSalary, mergeSalaryFields } from './jobSalary.js'
import { mergeIndeedJobMeta, parseSerpCard, parseViewJobBody } from './indeedJobMeta.js'
import { capJobDescription } from './jobDescriptionLimits.js'
import { dedupeSearchJobs } from './jobDedupe.js'

function stripHtml(html) {
  if (!html) return ''
  return String(html)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim()
}

function textFrom(value) {
  if (value == null) return ''
  if (typeof value === 'string') return value.trim()
  if (typeof value === 'object' && value.text != null) return String(value.text).trim()
  return String(value).trim()
}

function isJobComplete(job) {
  const jid = String(job?.jobId || '').trim()
  const title = String(job?.title || '').trim()
  const company = String(job?.company || '').trim()
  const desc = String(job?.description || '').trim()
  return Boolean(jid && title && company && desc.length > 50)
}

function dedupeJobs(jobs) {
  const seen = new Set()
  const out = []
  for (const j of jobs) {
    const id = String(j?.jobId || '').trim()
    if (!id || seen.has(id)) continue
    seen.add(id)
    out.push(j)
  }
  return out
}

function extractMosaicJobCards(html) {
  const patterns = [
    /window\.mosaic\.providerData\["mosaic-provider-jobcards"\]\s*=\s*(\{[\s\S]*?\});/,
    /window\.mosaic\.providerData\['mosaic-provider-jobcards'\]\s*=\s*(\{[\s\S]*?\});/,
    /"mosaic-provider-jobcards"\]\s*=\s*(\{[\s\S]*?\});/,
  ]
  for (const re of patterns) {
    const m = html.match(re)
    if (!m?.[1]) continue
    try {
      return JSON.parse(m[1])
    } catch {
      /* try next pattern */
    }
  }
  return null
}

function parseJobCardsFromMosaic(mosaic, base, count = 25) {
  const results =
    mosaic?.metaData?.mosaicProviderJobCardsModel?.results ||
    mosaic?.metaData?.mosaicProviderJobCardsModel?.jobs ||
    mosaic?.results ||
    []
  const jobs = []
  for (const r of results) {
    if (jobs.length >= count) break
    const jobKey = String(r.jobkey || r.jobKey || r.key || '').trim()
    if (!jobKey) continue
    const title = textFrom(r.title || r.jobTitle || r.displayTitle)
    const company = textFrom(r.company || r.companyName || r.truncatedCompany)
    const location = textFrom(r.formattedLocation || r.jobLocation || r.location)
    const snippet = textFrom(r.snippet || r.jobDescription || r.summary)
    const salaryRaw = textFrom(r.salarySnippet?.text || r.estimatedSalary || r.salary)
    const salaryFields = mergeSalaryFields({ salary: salaryRaw })
    const postedAt = r.pubDate ? new Date(r.pubDate) : r.formattedRelativeTime ? new Date() : new Date()
    const sponsored = Boolean(r.sponsored || r.isSponsored)
    jobs.push(
      mergeIndeedJobMeta(
        {
          jobId: jobKey,
          title,
          company,
          location,
          description: snippet,
          salary: salaryFields.salaryText || salaryRaw || null,
          salaryText: salaryFields.salaryText || salaryRaw || null,
          salaryMin: salaryFields.salaryMin,
          salaryMax: salaryFields.salaryMax,
          salaryCurrency: salaryFields.salaryCurrency,
          salaryPeriod: salaryFields.salaryPeriod,
          postedAt,
          jobUrl: `${base}/viewjob?jk=${jobKey}`,
          source: 'indeed',
          isIndeedApply: Boolean(r.indeedApply || r.indeedApplyEnabled),
          sponsored,
          logoUrl: r.companyBrandingAttributes?.logoUrl || r.logoUrl || null,
        },
        parseSerpCard(r)
      )
    )
  }
  return jobs
}

function parseJobKeysFromHtml(html, base, count = 25) {
  const keys = []
  const re = /data-jk="([a-f0-9]{16})"/gi
  let m
  while ((m = re.exec(html)) && keys.length < count) {
    if (!keys.includes(m[1])) keys.push(m[1])
  }
  return keys.map((jobKey) => ({
    jobId: jobKey,
    title: '',
    company: '',
    location: '',
    description: '',
    jobUrl: `${base}/viewjob?jk=${jobKey}`,
    source: 'indeed',
    postedAt: new Date(),
  }))
}

function mergeParsedIndeedJobs(mosaicJobs, domJobs, base, count) {
  const byId = new Map()
  for (const job of mosaicJobs || []) {
    const id = String(job?.jobId || '').trim()
    if (!id) continue
    byId.set(id, job)
  }
  for (const dom of domJobs || []) {
    const id = String(dom?.jobId || '').trim()
    if (!id) continue
    const existing = byId.get(id) || {
      jobId: id,
      title: '',
      company: '',
      location: '',
      description: '',
      jobUrl: `${base}/viewjob?jk=${id}`,
      source: 'indeed',
      postedAt: new Date(),
    }
    byId.set(id, {
      ...existing,
      title: String(existing.title || dom.title || '').trim(),
      company: String(existing.company || dom.company || '').trim(),
      location: String(existing.location || dom.location || '').trim(),
    })
  }
  return [...byId.values()].slice(0, count)
}

function indeedJobHasListMeta(job) {
  return Boolean(String(job?.jobId || '').trim() && String(job?.title || '').trim() && String(job?.company || '').trim())
}

function parseJobsFromSearchHtml(html, base, count, domJobs = []) {
  const mosaic = extractMosaicJobCards(html)
  let jobs = mosaic ? parseJobCardsFromMosaic(mosaic, base, count) : []
  if (!jobs.length) jobs = parseJobKeysFromHtml(html, base, count)
  return mergeParsedIndeedJobs(jobs, domJobs, base, count)
}

const INDEED_TAB_URLS = [
  'https://*.indeed.com/*',
  'https://indeed.com/*',
  'https://in.indeed.com/*',
]

function indeedChallengeError(message, extra = {}) {
  const err = new Error(
    message ||
      'Indeed needs a quick verification. Complete the checkbox in the Indeed tab that opened, then search again.'
  )
  err.code = 'INDEED_CHALLENGE'
  Object.assign(err, extra)
  return err
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function waitForTabLoad(tabId, timeoutMs = 28000) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => resolve(false), timeoutMs)
    const listener = (updatedTabId, info) => {
      if (updatedTabId === tabId && info.status === 'complete') {
        clearTimeout(timeout)
        chrome.tabs.onUpdated.removeListener(listener)
        resolve(true)
      }
    }
    chrome.tabs.onUpdated.addListener(listener)
    chrome.tabs
      .get(tabId)
      .then((t) => {
        if (t?.status === 'complete') {
          clearTimeout(timeout)
          chrome.tabs.onUpdated.removeListener(listener)
          resolve(true)
        }
      })
      .catch(() => {})
  })
}

async function readIndeedPageFromTab(tabId) {
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: () => {
        try {
          window.scrollTo(0, Math.min(900, document.body?.scrollHeight || 900))
        } catch {
          /* ignore */
        }
        const pickText = (el) => (el?.innerText || el?.textContent || '').replace(/\s+/g, ' ').trim()
        const domJobs = []
        const seen = new Set()

        const addCard = (card, jk) => {
          const id = String(jk || '').trim()
          if (!id || seen.has(id)) return
          const titleEl =
            card.querySelector?.('h2.jobTitle span[title]') ||
            card.querySelector?.('h2.jobTitle a span') ||
            card.querySelector?.('[class*="jobTitle"] span[title]') ||
            card.querySelector?.('a[data-jk] span[title]') ||
            card.querySelector?.('a[data-jk] span')
          const companyEl =
            card.querySelector?.('[data-testid="company-name"]') ||
            card.querySelector?.('.companyName') ||
            card.querySelector?.('[class*="companyName"]')
          const locEl =
            card.querySelector?.('[data-testid="text-location"]') ||
            card.querySelector?.('.companyLocation') ||
            card.querySelector?.('[class*="companyLocation"]')
          const title = String(titleEl?.getAttribute?.('title') || pickText(titleEl) || '').trim()
          const company = pickText(companyEl)
          const location = pickText(locEl)
          if (!title && !company) return
          seen.add(id)
          domJobs.push({ jobId: id, title, company, location })
        }

        document.querySelectorAll('[data-jk]').forEach((el) => {
          const card = el.closest('.job_seen_beacon') || el.closest('.tapItem') || el.closest('.resultContent') || el
          addCard(card, el.getAttribute('data-jk'))
        })
        document.querySelectorAll('.job_seen_beacon, .tapItem').forEach((card) => {
          const jk = card.getAttribute?.('data-jk') || card.querySelector?.('[data-jk]')?.getAttribute?.('data-jk')
          if (jk) addCard(card, jk)
        })

        return {
          html: document.documentElement?.outerHTML || '',
          href: location.href,
          title: document.title || '',
          domJobs,
        }
      },
    })
    if (!result) return null
    const html = String(result.html || '')
    const page = analyzeIndeedPage(html, result.title || '', result.href || '')
    return { html, href: result.href, title: result.title, page, domJobs: result.domJobs || [] }
  } catch {
    return null
  }
}

async function focusIndeedTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId)
    await chrome.tabs.update(tabId, { active: true })
    if (tab?.windowId != null) {
      await chrome.windows.update(tab.windowId, { focused: true })
    }
  } catch {
    /* ignore */
  }
}

/** Poll until job cards have title + company (Indeed loads listings after tab "complete"). */
async function waitForIndeedJobsOnTab(tabId, filters, start = 0, { timeoutMs = 120000, pollMs = 1500 } = {}) {
  const deadline = Date.now() + timeoutMs
  let sawSecurity = false
  while (Date.now() < deadline) {
    const snap = await readIndeedPageFromTab(tabId)
    if (!snap) {
      await sleep(pollMs)
      continue
    }
    if (snap.page?.isLogin) {
      const err = new Error('Log in on indeed.com in Chrome, then search again.')
      err.code = 'INDEED_NOT_LOGGED_IN'
      throw err
    }
    if (snap.page?.isSecurity) sawSecurity = true
    const parsed = parseSearchResultFromSnap(snap, filters, start)
    if (parsed?.jobs?.length) return snap
    await sleep(pollMs)
  }
  if (sawSecurity) {
    throw indeedChallengeError(
      'Indeed verification timed out. Complete the security check in the Indeed tab, then run search again.',
      { verificationTimedOut: true }
    )
  }
  return null
}

function parseSearchResultFromSnap(snap, filters, start = 0) {
  const country = String(filters.country || 'IN').toUpperCase()
  const base = resolveIndeedBase(country)
  const count = Math.min(25, Math.max(5, Number(filters.count) || 20))
  const jobs = parseJobsFromSearchHtml(snap.html, base, count, snap.domJobs).filter(indeedJobHasListMeta)
  if (!jobs.length) return null
  return { jobs, html: snap.html, base, country }
}

/**
 * Hidden background Indeed tab (Monster/Naukri pattern). Tab is only focused when Indeed
 * shows human verification; closed automatically after jobs are captured.
 */
async function captureIndeedSearchViaBackgroundTab(filters, start = 0, { timeoutMs = 52000 } = {}) {
  const url = buildIndeedJobsSearchUrl({ ...filters, start })
  let tab = null
  let keepTabOpen = false

  try {
    tab = await chrome.tabs.create({ url, active: false })
    const id = tab?.id
    if (!id) return null

    await waitForTabLoad(id, Math.min(timeoutMs, 32000))
    await sleep(800)

    let snap = await readIndeedPageFromTab(id)
    if (!snap) return null

    if (snap.page?.isLogin) {
      const err = new Error('Log in on indeed.com in Chrome, then search again.')
      err.code = 'INDEED_NOT_LOGGED_IN'
      throw err
    }

    const needsVerification = snap.page?.isSecurity && !snap.page?.hasJobs
    if (needsVerification) await focusIndeedTab(id)

    try {
      snap = await waitForIndeedJobsOnTab(id, filters, start, {
        timeoutMs: needsVerification ? 120000 : 48000,
      })
    } catch (e) {
      if (e?.code === 'INDEED_CHALLENGE') keepTabOpen = true
      throw e
    }

    const parsed = snap ? parseSearchResultFromSnap(snap, filters, start) : null
    if (!parsed?.jobs?.length) {
      if (snap?.page?.isSecurity) {
        keepTabOpen = true
        throw indeedChallengeError(
          'Complete the Indeed security check in the tab (checkbox), then run search again.'
        )
      }
      return null
    }
    return parsed
  } finally {
    if (tab?.id && !keepTabOpen) {
      chrome.tabs.remove(tab.id).catch(() => {})
    }
  }
}

async function fetchSearchPage(filters, start = 0) {
  const country = String(filters.country || 'IN').toUpperCase()
  const base = resolveIndeedBase(country)
  const q = String(filters.keywords || '').trim() || 'software engineer'
  const count = Math.min(25, Math.max(5, Number(filters.count) || 20))
  const urlFilters = { ...filters, start }
  const url = buildIndeedJobsSearchUrl(urlFilters)

  let html = ''
  try {
    const { res } = await indeedFetch(url, {
      country,
      referer: `${base}/`,
      headers: { Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' },
    })
    html = await res.text()
    if (res.status >= 400) {
      const err = new Error(`Indeed search failed (HTTP ${res.status})`)
      err.code = res.status === 429 ? 'RATE_LIMITED' : 'SEARCH_FAILED'
      throw err
    }
  } catch (e) {
    if (e?.code === 'INDEED_NOT_LOGGED_IN') throw e
    /* fall through — background tab path in fetchSearchPageWithFallback */
    return { jobs: [], html: '', base, country }
  }

  const jobs = parseJobsFromSearchHtml(html, base, count).filter(indeedJobHasListMeta)
  return { jobs, html, base, country }
}

async function fetchIndeedSearchHtmlFromOpenTabs(url) {
  let tabs = []
  try {
    tabs = await chrome.tabs.query({ url: INDEED_TAB_URLS })
  } catch {
    return null
  }

  for (const tab of tabs) {
    if (!tab?.id) continue
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: async (fetchUrl) => {
          const res = await fetch(fetchUrl, {
            credentials: 'include',
            headers: { Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' },
          })
          return { ok: res.ok, status: res.status, html: await res.text() }
        },
        args: [url],
      })
      const html = String(result?.html || '')
      if (html.length > 500) return html
    } catch {
      /* tab may be restricted */
    }
  }
  return null
}

async function fetchSearchPageWithFallback(filters, start = 0) {
  const country = String(filters.country || 'IN').toUpperCase()
  const base = resolveIndeedBase(country)
  const count = Math.min(25, Math.max(5, Number(filters.count) || 20))

  // 1) Service-worker fetch — no tab (fast path)
  try {
    const out = await fetchSearchPage(filters, start)
    const usable = (out.jobs || []).filter(indeedJobHasListMeta)
    if (usable.length) return { ...out, jobs: usable }
  } catch (e) {
    if (e?.code === 'INDEED_NOT_LOGGED_IN' || e?.code === 'INDEED_CHALLENGE') throw e
  }

  // 2) In-page fetch from an open Indeed tab — no new tab, no focus
  const url = buildIndeedJobsSearchUrl({ ...filters, start })
  const html = await fetchIndeedSearchHtmlFromOpenTabs(url)
  if (html) {
    const page = analyzeIndeedPage(html, '', url)
    if (!page.isSecurity || page.hasJobs) {
      const jobs = parseJobsFromSearchHtml(html, base, count).filter(indeedJobHasListMeta)
      if (jobs.length) return { jobs, html, base, country }
    }
  }

  // 3) Hidden background tab — only shown if Indeed asks for verification
  const fromTab = await captureIndeedSearchViaBackgroundTab(filters, start)
  if (fromTab?.jobs?.length) return fromTab

  return { jobs: [], html: '', base, country }
}

async function fetchJobDetails(jobKey, opts = {}) {
  const country = String(opts.country || 'IN').toUpperCase()
  const base = resolveIndeedBase(country)
  const params = new URLSearchParams({
    jk: jobKey,
    viewtype: 'embedded',
    spa: '1',
    hidecmpheader: '0',
  })
  const url = `${base}/viewjob?${params.toString()}`
  const { res } = await indeedFetch(url, {
    country,
    referer: `${base}/jobs`,
    headers: { Accept: 'application/json' },
  })

  const text = await res.text()
  let data
  try {
    data = JSON.parse(text)
  } catch {
    return null
  }
  if (data?.status !== 'success' || !data?.body) return null

  const body = data.body
  const jiw = body.jobInfoWrapperModel || {}
  let jim = jiw.jobInfoModel || {}
  if (typeof jim === 'string') {
    try {
      jim = JSON.parse(jim)
    } catch {
      jim = {}
    }
  }

  const header = jim.jobInfoHeaderModel || {}
  const descHtml = jim.sanitizedJobDescription || jim.jobDescriptionSectionModel?.jobDescription || ''
  const description = capJobDescription(stripHtml(descHtml))
  const title = textFrom(body.jobTitle || header.jobTitle || jim.jobTitle)
  const company = textFrom(header.companyName || body.hiringCompanyName || body.companyName)
  const location = textFrom(body.jobLocation || header.formattedLocation || body.formattedLocation)
  const logoUrl = header.companyImagesModel?.logoUrl || null
  const salaryFields =
    extractIndeedSalary(body) ||
    mergeSalaryFields({
      salary: textFrom(
        body.salaryInfoModel?.salaryText || body.salaryGuideModel?.estimatedSalaryModel?.formattedSalary
      ),
    }) ||
    {}
  const isIndeedApply = Boolean(body.indeedApplyButtonContainer && !body.indeedApplyButtonContainer.disabled)
  const age = textFrom(body.jobMetadataFooterModel?.age)
  const meta = parseViewJobBody(body)
  const deadlineRaw =
    body.applicationDeadline ||
    body.jobMetadataHeaderModel?.applicationDeadline ||
    jim.applicationDeadline ||
    null
  const deadline = deadlineRaw ? new Date(deadlineRaw) : null

  return mergeIndeedJobMeta(
    {
      jobId: String(body.jobKey || jobKey).trim(),
      title,
      company,
      location: location || meta.location,
      description,
      salary: salaryFields.salaryText || null,
      salaryText: salaryFields.salaryText || null,
      salaryMin: salaryFields.salaryMin ?? null,
      salaryMax: salaryFields.salaryMax ?? null,
      salaryCurrency: salaryFields.salaryCurrency || null,
      salaryPeriod: salaryFields.salaryPeriod || null,
      deadline: deadline && !Number.isNaN(deadline.getTime()) ? deadline.toISOString() : null,
      jobUrl: `${base}/viewjob?jk=${jobKey}`,
      source: 'indeed',
      logoUrl,
      isIndeedApply,
      postedLabel: age,
      postedAt: new Date(),
      applyUrl: body.indeedApplyButtonContainer?.indeedApplyAttributes
        ? `${base}/viewjob?jk=${jobKey}`
        : null,
    },
    meta
  )
}

async function enrichIncompleteJobs(jobs, opts = {}) {
  const out = []
  for (const job of jobs) {
    if (isJobComplete(job)) {
      out.push(job)
      continue
    }
    try {
      const detail = await fetchJobDetails(job.jobId, opts)
      if (detail) {
        out.push({
          ...job,
          ...detail,
          title: detail.title || job.title,
          company: detail.company || job.company,
          location: detail.location || job.location,
          description: detail.description || job.description,
        })
      } else {
        out.push(job)
      }
    } catch {
      out.push(job)
    }
  }
  return out
}

async function collectIndeedJobsForQuery(filters, start, count, exclude) {
  const collected = []
  let offset = Math.max(0, parseInt(start, 10) || 0)
  const maxPages = 3

  for (let page = 0; page < maxPages && collected.length < count; page += 1) {
    const { jobs: batch } = await fetchSearchPageWithFallback(filters, offset)
    if (!batch.length) break

    const enriched = dedupeJobs(batch)

    for (const job of enriched) {
      const jid = String(job?.jobId || '').trim()
      if (!jid || exclude.has(jid)) continue
      if (!String(job.title || '').trim() || !String(job.company || '').trim()) continue
      exclude.add(jid)
      collected.push(job)
      if (collected.length >= count) break
    }

    offset += batch.length
    if (batch.length < 10) break
  }

  return collected
}

/**
 * @param {{ keywords?: string, querySets?: string[], location?: string, count?: number, start?: number, country?: string, fromage?: number, excludeJobIds?: string[], jobTitle?: string, targetRole?: string, skills?: string[], combinedKeywords?: string }} opts
 * @returns {Promise<{ jobs: object[] }>}
 */
export async function searchIndeedJobsInExtension(opts = {}) {
  const count = resolveJobSearchTarget(opts.count)
  const querySets =
    Array.isArray(opts.querySets) && opts.querySets.length
      ? opts.querySets
      : buildJobSearchQuerySets('indeed', {
          jobTitle: opts.targetRole || opts.jobTitle,
          targetRole: opts.targetRole,
          skills: mergeResumeSearchSkills(opts.skills, opts.skillsStr),
          skillsStr: opts.skillsStr,
          experienceTitles: opts.experienceTitles,
          keywords: opts.keywords,
          combinedKeywords: opts.combinedKeywords,
        })

  const days = resolvePostedWithinDays(opts.datePostedDays ?? opts.fromage, 1)
  const exclude = new Set((opts.excludeJobIds || []).map(String))
  const collected = []
  const perQueryBudget = resolvePerQueryJobBudget(count, querySets.length)

  for (const keywords of querySets) {
    if (collected.length >= count) break
    const perQuery = Math.min(resolveJobsPerApiRequest(opts.count), perQueryBudget + 2)
    const filters = {
      keywords,
      location: opts.location || '',
      count: perQuery,
      country: opts.country || 'IN',
      datePostedDays: String(days),
      fromage: days,
      jt: opts.jt,
      explvl: opts.explvl,
      radius: opts.radius,
    }
    let batch = []
    try {
      batch = await collectIndeedJobsForQuery(filters, 0, perQuery, exclude)
    } catch (e) {
      if (e?.code === 'INDEED_NOT_LOGGED_IN' || e?.code === 'INDEED_CHALLENGE') {
        if (!collected.length) throw e
        break
      }
      if (!collected.length) throw e
      break
    }
    let queryTaken = 0
    for (const job of batch) {
      if (queryTaken >= perQueryBudget) break
      collected.push(job)
      queryTaken += 1
    }
  }

  return {
    jobs: dedupeSearchJobs(
      collected
        .map(padIndeedJobForImport)
        .filter((j) => String(j?.jobId || '').trim() && String(j?.title || '').trim() && String(j?.company || '').trim()),
      'indeed'
    ).slice(0, count),
  }
}

function padIndeedJobForImport(job) {
  const jobId = String(job?.jobId || '').trim()
  const title = String(job?.title || '').trim()
  const company = String(job?.company || '').trim()
  const location = String(job?.location || '').trim()
  let description = String(job?.description || '').trim()
  const locPart = location ? ` in ${location}` : ''
  if (title && company) {
    const prefix = `${title} at ${company}${locPart}`
    description = description ? `${prefix}. ${description}` : prefix
  }
  if (description.length < 50) {
    description = `${description}. View the full posting on Indeed for requirements, responsibilities, and how to apply.`.trim()
  }
  const jobUrl =
    String(job?.jobUrl || '').trim() ||
    (jobId ? `https://in.indeed.com/viewjob?jk=${jobId}` : '')
  return { ...job, jobId, title, company, location, description: capJobDescription(description), jobUrl }
}

/** Enrich SERP cards + ensure every job is import/tracker-ready before POST to backend. */
export async function prepareIndeedJobsForImport(jobs, opts = {}) {
  const enriched = await enrichIncompleteJobs(Array.isArray(jobs) ? jobs : [], opts)
  return enriched.map(padIndeedJobForImport).filter((j) => j.jobId && j.title && j.company)
}

export { fetchJobDetails, isJobComplete, stripHtml, padIndeedJobForImport }
