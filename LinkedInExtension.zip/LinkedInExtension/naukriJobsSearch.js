/**
 * Naukri job discovery from the extension service worker — LinkedIn/Indeed pattern:
 * read browser cookies → call jobapi/v3/search with nkparam (no tabs opened).
 */

import {
  getNaukriSessionSnapshot,
  captureNkparamSilently,
  captureNkparamViaBackgroundTab,
  naukriFetch,
  buildNaukriHeaders,
  buildNaukriSearchReferer,
  NAUKRI_BASE,
} from './naukriClient.js'
import { resolvePostedWithinDays } from './jobSearchPrefs.js'
import {
  buildJobSearchQuerySets,
  mergeResumeSearchSkills,
  resolveJobSearchTarget,
  resolveJobsPerApiRequest,
  resolvePerQueryJobBudget,
} from './jobSearchQuerySets.js'
import { capJobDescription } from './jobDescriptionLimits.js'
import { buildNaukriJobUrl } from './naukriJobUrl.js'
import { dedupeSearchJobs, jobSearchDedupeKey, resolvePlatformJobId } from './jobDedupe.js'
import {
  isNaukriDescriptionComplete,
  parseNaukriDetailDescription,
  pickBestNaukriDescription,
  buildNaukriDetailApiUrls,
  extractDescriptionFromNaukriHtml,
} from './naukriJobDescription.js'

function computeSkillMatchPercent(skills, job = {}) {
  const list = (Array.isArray(skills) ? skills : String(skills || '').split(/[,;|]/))
    .map((s) => String(s).trim().toLowerCase())
    .filter((s) => s.length > 1)
  if (!list.length) return 0
  const hay = [job.title, job.skills, job.description, job.company].filter(Boolean).join(' ').toLowerCase()
  if (!hay) return 0
  let hits = 0
  for (const skill of list) {
    if (hay.includes(skill)) hits += 1
  }
  return hits ? Math.min(100, Math.round((hits / list.length) * 100)) : 0
}

function rankJobsByResumeSkills(jobs, skills) {
  if (!Array.isArray(skills) || !skills.length) return jobs
  return [...jobs]
    .map((job) => ({ ...job, matchPercent: job.matchPercent ?? computeSkillMatchPercent(skills, job) }))
    .sort((a, b) => (b.matchPercent || 0) - (a.matchPercent || 0))
}

function placeholderLabel(placeholders, type) {
  const list = Array.isArray(placeholders) ? placeholders : []
  const hit = list.find((p) => String(p?.type || '').toLowerCase() === String(type).toLowerCase())
  return hit?.label ? String(hit.label).trim() : ''
}

function parseRelativePostedLabel(label) {
  const s = String(label || '').trim().toLowerCase()
  if (!s) return null
  if (/just now|today|few hours|hour ago|hours ago|minute|minutes ago/.test(s)) return new Date()
  const daysMatch = s.match(/(\d+)\s*days?\s*ago/)
  if (daysMatch) {
    const d = new Date()
    d.setDate(d.getDate() - Number(daysMatch[1]))
    return d
  }
  return null
}

function parseNaukriJob(raw) {
  if (!raw?.jobId) return null
  const jobId = String(raw.jobId).trim()
  const jobUrl = buildNaukriJobUrl(jobId, raw.jdURL || raw.staticUrl || '')
  let postedAt = null
  if (raw.createdDate) {
    const d = new Date(raw.createdDate)
    if (!Number.isNaN(d.getTime())) postedAt = d
  }
  if (!postedAt) postedAt = parseRelativePostedLabel(raw.footerPlaceholderLabel)
  const location = placeholderLabel(raw.placeholders, 'location')
  const experience = String(raw.experienceText || placeholderLabel(raw.placeholders, 'experience') || '').trim()
  const skills = String(raw.tagsAndSkills || '').trim()
  const title = String(raw.title || '').trim()
  const company = String(raw.companyName || '').trim()
  let description = String(raw.jobDescription || '').replace(/<[^>]+>/g, ' ').trim()
  if (!description && title && company) {
    description = `${title} at ${company}${location ? ` in ${location}` : ''}.`
    if (skills) description += ` Skills: ${skills}.`
    if (experience) description += ` Experience: ${experience}.`
  }
  return {
    jobId,
    title,
    company,
    location,
    description: capJobDescription(description),
    skills,
    experience,
    jobUrl,
    logoUrl: raw.logoPathV3 || raw.logoPath || null,
    postedAt,
    source: 'naukri',
  }
}

function setIfPresent(params, key, val) {
  if (val == null || val === '') return
  params[key] = String(val)
}

function slugifySeoKey(keyword) {
  const slug = String(keyword || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
  return slug ? `${slug}-jobs` : ''
}

/** Build Naukri API query params — matches www.naukri.com.json HAR. */
export function buildNaukriSearchParams(filters = {}) {
  const f = filters && typeof filters === 'object' ? filters : {}
  const keyword = String(f.keywords || f.keyword || f.k || f.jobTitle || '').trim()
  const pageNo = Math.max(1, parseInt(f.pageNo || f.page, 10) || 1)
  const noOfResults = Math.min(20, Math.max(1, Number(f.count || f.noOfResults) || resolveJobsPerApiRequest()))
  const postedDays = resolvePostedWithinDays(f.datePostedDays ?? f.postedWithinDays, 0)

  const hasClusterFilters =
    (f.wfhType != null && f.wfhType !== '') ||
    (f.experience != null && f.experience !== '') ||
    (f.cityTypeGid != null && f.cityTypeGid !== '') ||
    (f.ctcFilter != null && f.ctcFilter !== '') ||
    (f.functionAreaIdGid != null && f.functionAreaIdGid !== '') ||
    (f.pgTypeGid != null && f.pgTypeGid !== '') ||
    (f.employement != null && f.employement !== '') ||
    (f.employment != null && f.employment !== '')

  const params = {
    noOfResults: String(noOfResults),
    urlType: 'search_by_keyword',
    searchType: 'adv',
    keyword,
    k: keyword,
    pageNo: String(pageNo),
    src: hasClusterFilters || postedDays >= 1 ? 'cluster' : 'jobsearchDesk',
    latLong: '',
    nignbevent_src: 'jobsearchDeskGNB',
  }
  const seoKey = f.seoKey || slugifySeoKey(keyword)
  if (seoKey) params.seoKey = seoKey
  if (f.sid) params.sid = String(f.sid)
  if (hasClusterFilters || postedDays >= 1) params.sort = 'p'

  setIfPresent(params, 'wfhType', f.wfhType)
  setIfPresent(params, 'experience', f.experience)
  setIfPresent(params, 'cityTypeGid', f.cityTypeGid)
  setIfPresent(params, 'ctcFilter', f.ctcFilter)
  setIfPresent(params, 'functionAreaIdGid', f.functionAreaIdGid)
  setIfPresent(params, 'pgTypeGid', f.pgTypeGid)
  setIfPresent(params, 'employement', f.employement ?? f.employment)

  return { params, keyword, count: noOfResults, postedDays }
}

function applyPostedDaysFilter(jobs, postedDays) {
  if (!(postedDays >= 1 && postedDays <= 7) || !jobs.length) return jobs
  const cutoff = Date.now() - postedDays * 86400 * 1000
  const filtered = jobs.filter((job) => {
    if (!job.postedAt) return true
    const ts = job.postedAt instanceof Date ? job.postedAt.getTime() : new Date(job.postedAt).getTime()
    return Number.isFinite(ts) ? ts >= cutoff : true
  })
  return filtered.length ? filtered : jobs
}

async function ensureNaukriSearchSession(opts = {}) {
  const keyword = String(opts.keyword || opts.keywords || opts.jobTitle || 'software engineer').trim()
  let snap = await getNaukriSessionSnapshot()
  if (!snap.loggedIn || !snap.cookieHeader) {
    const err = new Error('Log in on naukri.com and sync via the extension.')
    err.code = 'NAUKRI_NOT_LOGGED_IN'
    throw err
  }
  if (snap.nkparam) return snap

  await captureNkparamSilently()
  snap = await getNaukriSessionSnapshot()
  if (snap.nkparam) return snap

  const captured = await captureNkparamViaBackgroundTab({ keyword })
  snap = await getNaukriSessionSnapshot()
  if (!snap.nkparam && captured.nkparam) {
    snap = { ...snap, nkparam: captured.nkparam, hasNkparam: true }
  }
  if (!snap.nkparam) {
    const err = new Error('Could not refresh the Naukri session automatically. Sync Naukri and try again.')
    err.code = 'NAUKRI_NEEDS_NKPARAM'
    throw err
  }
  return {
    ...snap,
    _tabSearchData: captured.searchData || null,
    _tabSid: captured.sid || captured.searchData?.sid || null,
  }
}

function naukri406Error(body = {}, snap) {
  const detail = String(body.message || body.error || '').toLowerCase()
  if (/recaptcha|captcha|bot/.test(detail)) {
    const err = new Error('Naukri blocked the automated request. Try again in a minute.')
    err.code = 'NAUKRI_RECAPTCHA'
    return err
  }
  if (!snap?.nkparam) {
    const err = new Error('Naukri session could not be refreshed automatically. Sync Naukri and try again.')
    err.code = 'NAUKRI_NEEDS_NKPARAM'
    return err
  }
  const err = new Error('Naukri session expired. Sync Naukri in the extension and try again.')
  err.code = 'NAUKRI_NEEDS_NKPARAM'
  return err
}

function jobsFromSearchData(data, postedDays) {
  if (data?.isLoggedIn === false) {
    const err = new Error('Naukri session is not logged in. Sync cookies from an active naukri.com session.')
    err.code = 'NAUKRI_NOT_LOGGED_IN'
    throw err
  }
  const rawJobs = Array.isArray(data?.jobDetails) ? data.jobDetails : []
  const jobs = []
  for (const raw of rawJobs) {
    const parsed = parseNaukriJob(raw)
    if (parsed?.jobId && parsed?.title) jobs.push(parsed)
  }
  return applyPostedDaysFilter(jobs, postedDays)
}

async function fetchNaukriSearchPage(opts = {}, snap, state = {}, allowTabRetry = true) {
  const pageNo = Math.max(1, parseInt(opts.pageNo, 10) || 1)
  const { params, postedDays, keyword } = buildNaukriSearchParams({
    ...opts,
    pageNo,
    count: resolveJobsPerApiRequest(opts.count),
    sid: state.sid,
  })
  const referer = buildNaukriSearchReferer(keyword)
  const apiUrl = `${NAUKRI_BASE}/jobapi/v3/search?${new URLSearchParams(params).toString()}`

  const { res, data } = await naukriFetch(apiUrl, { referer, nkparam: snap.nkparam })

  if (res.status === 406) {
    if (allowTabRetry) {
      const captured = await captureNkparamViaBackgroundTab({ keyword })
      const freshSnap = await getNaukriSessionSnapshot()
      const useSnap =
        freshSnap.nkparam || captured.nkparam
          ? { ...freshSnap, nkparam: freshSnap.nkparam || captured.nkparam, hasNkparam: true }
          : snap

      if (pageNo === 1 && captured.searchData?.jobDetails?.length) {
        if (captured.searchData.sid || captured.sid) {
          state.sid = captured.searchData.sid || captured.sid
        }
        return jobsFromSearchData(captured.searchData, postedDays)
      }
      if (useSnap.nkparam) {
        return fetchNaukriSearchPage(opts, useSnap, state, false)
      }
    }
    throw naukri406Error(data, snap)
  }
  if (!res.ok) {
    const err = new Error(`Naukri search failed (HTTP ${res.status})`)
    err.code = 'SEARCH_FAILED'
    throw err
  }

  if (data?.sid && pageNo === 1) state.sid = data.sid
  return jobsFromSearchData(data, postedDays)
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

async function fetchNaukriDescriptionFromHtml(jobUrl, snap) {
  const url = String(jobUrl || '').trim()
  if (!url) return ''
  try {
    const built = await buildNaukriHeaders({ referer: url, nkparam: snap?.nkparam })
    const res = await fetch(url, {
      headers: { ...built.headers, Accept: 'text/html,application/xhtml+xml;q=0.9' },
      credentials: 'include',
    })
    if (!res.ok) return ''
    const html = await res.text()
    return extractDescriptionFromNaukriHtml(html)
  } catch {
    return ''
  }
}

async function fetchNaukriJobDetails(jobId, snap, seedJob = {}) {
  const id = String(jobId || '').trim()
  if (!id) return ''
  const referer =
    String(seedJob?.jobUrl || '').trim() ||
    `${NAUKRI_BASE}/job-listings-${id}`
  let best = ''

  for (const apiUrl of buildNaukriDetailApiUrls(id)) {
    try {
      const { res, data } = await naukriFetch(apiUrl, { referer, nkparam: snap.nkparam })
      if (!res.ok) continue
      const text = parseNaukriDetailDescription(data, seedJob)
      best = pickBestNaukriDescription(best, text)
      if (isNaukriDescriptionComplete(best)) break
    } catch {
      /* try next endpoint */
    }
  }

  if (!isNaukriDescriptionComplete(best)) {
    const htmlText = await fetchNaukriDescriptionFromHtml(referer, snap)
    best = pickBestNaukriDescription(best, htmlText)
  }

  return best
}

async function enrichNaukriJobDescriptions(jobs, snap, { maxEnrich = 20 } = {}) {
  const list = Array.isArray(jobs) ? [...jobs] : []
  const limit = Math.min(list.length, Math.max(1, Number(maxEnrich) || list.length))
  let session = snap
  if (!session?.nkparam) {
    await captureNkparamSilently()
    session = await getNaukriSessionSnapshot()
  }

  for (let i = 0; i < limit; i += 1) {
    const job = list[i]
    const current = String(job?.description || '').trim()
    if (isNaukriDescriptionComplete(current) && current.length >= 1500) continue
    const full = await fetchNaukriJobDetails(job.jobId, session, job)
    if (full) {
      list[i] = { ...job, description: pickBestNaukriDescription(current, full) }
    }
    if (i < limit - 1) await sleep(150)
  }
  return list
}

function padNaukriJobForImport(job) {
  const jobId = String(job?.jobId || '').trim()
  const title = String(job?.title || '').trim()
  const company = String(job?.company || '').trim()
  const location = String(job?.location || '').trim()
  let description = String(job?.description || '').trim()
  const hasStructuredJd =
    isNaukriDescriptionComplete(description) ||
    /^job title:/i.test(description) ||
    /role\s*(?:&|and)?\s*responsibilit/i.test(description)
  if (!hasStructuredJd) {
    const locPart = location ? ` in ${location}` : ''
    if (title && company && !description.toLowerCase().startsWith(title.toLowerCase())) {
      const prefix = `${title} at ${company}${locPart}`
      description = description ? `${prefix}.\n\n${description}` : prefix
    }
    if (description.length < 80) {
      description = `${description}. View the full posting on Naukri for requirements and how to apply.`.trim()
    }
  }
  const jobUrl = buildNaukriJobUrl(jobId, job?.jobUrl || job?.jdURL || '')
  return { ...job, jobId, title, company, location, description: capJobDescription(description), jobUrl }
}

export function prepareNaukriJobsForImport(jobs) {
  return (Array.isArray(jobs) ? jobs : [])
    .map(padNaukriJobForImport)
    .filter((j) => j.jobId && j.title && j.company)
}

/**
 * Search Naukri using browser cookies — teams-style combined query (role + top skill).
 */
export async function searchNaukriJobsInExtension(opts = {}) {
  const targetCount = resolveJobSearchTarget(opts.count)
  const querySets =
    Array.isArray(opts.querySets) && opts.querySets.length
      ? opts.querySets
      : buildJobSearchQuerySets('naukri', {
          jobTitle: opts.targetRole || opts.jobTitle,
          targetRole: opts.targetRole,
          skills: mergeResumeSearchSkills(opts.skills, opts.skillsStr),
          skillsStr: opts.skillsStr,
          experienceTitles: opts.experienceTitles,
          keywords: opts.keywords || opts.keyword || opts.k,
          combinedKeywords: opts.combinedKeywords,
        })

  if (!querySets.length) {
    const err = new Error('Job search keywords are required.')
    err.code = 'KEYWORDS_REQUIRED'
    throw err
  }

  const exclude = new Set((opts.excludeJobIds || []).map(String))
  const seenKeys = new Set()
  const seenFingerprints = new Set()
  const snap = await ensureNaukriSearchSession({ keyword: querySets[0], ...opts })
  const collected = []
  const perQueryBudget = resolvePerQueryJobBudget(targetCount, querySets.length)
  const resumeSkills = mergeResumeSearchSkills(opts.skills, opts.skillsStr)

  const collectFromBatch = (batch, keyword, queryTaken) => {
    let taken = queryTaken
    for (const job of batch) {
      if (taken >= perQueryBudget) break
      const jid = resolvePlatformJobId(job, 'naukri') || String(job.jobId || '').trim()
      const dedupeKey = jobSearchDedupeKey(job, 'naukri')
      const fpKey = `${String(job.title || '').trim().toLowerCase()}|${String(job.company || '').trim().toLowerCase()}|${String(job.location || '').trim().toLowerCase()}`
      if (!jid || exclude.has(jid) || (dedupeKey && seenKeys.has(dedupeKey))) continue
      if (fpKey !== '||' && seenFingerprints.has(fpKey)) continue
      if (!String(job.title || '').trim() || !String(job.company || '').trim()) continue
      exclude.add(jid)
      if (dedupeKey) seenKeys.add(dedupeKey)
      if (fpKey !== '||') seenFingerprints.add(fpKey)
      collected.push({ ...job, searchKeyword: keyword })
      taken += 1
    }
    return taken
  }

  for (const keyword of querySets) {
    if (collected.length >= targetCount) break
    const searchState = { sid: null }
    const perQuery = Math.min(resolveJobsPerApiRequest(opts.count), perQueryBudget + 2)
    let pageNo = 1
    const maxPages = 2
    let queryTaken = 0

    try {
      while (pageNo <= maxPages && queryTaken < perQueryBudget) {
        const batch = await fetchNaukriSearchPage(
          { ...opts, keywords: keyword, pageNo, count: perQuery },
          snap,
          searchState
        )
        if (!batch.length) break
        queryTaken = collectFromBatch(batch, keyword, queryTaken)
        if (queryTaken >= perQueryBudget || batch.length < 10) break
        pageNo += 1
      }
    } catch (e) {
      if (!collected.length) throw e
      break
    }
  }

  // JD enrichment + AI match run on import for new jobs only (backend) — skip here for speed.
  return {
    jobs: dedupeSearchJobs(
      rankJobsByResumeSkills(prepareNaukriJobsForImport(collected), resumeSkills),
      'naukri'
    ).slice(0, targetCount),
    keywords: querySets[0],
    querySets,
  }
}

export { padNaukriJobForImport, parseNaukriJob }
