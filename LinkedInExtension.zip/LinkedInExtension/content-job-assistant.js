/**
 * Universal job page detection + context extraction + form autofill.
 * No URL allowlists — uses page content, JSON-LD JobPosting, and heuristics.
 */

const JOB_SIGNAL_RE = [
  /\bjob description\b/i,
  /\bjob summary\b/i,
  /\babout the (role|job|position)\b/i,
  /\b(key )?responsibilities\b/i,
  /\b(requirements|qualifications)\b/i,
  /\byears of experience\b/i,
  /\bwhat you['']?ll (do|bring)\b/i,
  /\bapply now\b/i,
  /\bwe are (looking|seeking|hiring)\b/i,
  /\b(full[- ]?time|part[- ]?time|contract|remote|hybrid)\b/i,
  /\bskills required\b/i,
  /\bpreferred qualifications\b/i,
  /\brole overview\b/i,
  /\bposition overview\b/i
];

function textOf(el) {
  if (!el) return '';
  return String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
}

function stripHtml(html) {
  const d = document.createElement('div');
  d.innerHTML = String(html || '');
  return textOf(d);
}

function pickFirstText(selectors) {
  for (const sel of selectors) {
    try {
      const el = document.querySelector(sel);
      const t = textOf(el);
      if (t.length > 2) return t;
    } catch {
      /* invalid selector */
    }
  }
  return '';
}

function countJobSignals(text) {
  const hay = String(text || '').slice(0, 80_000);
  let n = 0;
  for (const re of JOB_SIGNAL_RE) {
    if (re.test(hay)) n += 1;
  }
  return n;
}

function readJsonLdJobPosting() {
  const scripts = document.querySelectorAll('script[type="application/ld+json"]');
  for (const s of scripts) {
    try {
      const raw = JSON.parse(s.textContent || '');
      const queue = Array.isArray(raw) ? [...raw] : [raw];
      while (queue.length) {
        const item = queue.shift();
        if (!item || typeof item !== 'object') continue;
        const type = item['@type'];
        const types = Array.isArray(type) ? type : [type];
        if (types.some((t) => String(t || '').includes('JobPosting'))) return item;
        if (item['@graph']) queue.push(...(Array.isArray(item['@graph']) ? item['@graph'] : [item['@graph']]));
      }
    } catch {
      /* ignore */
    }
  }
  return null;
}

function locationFromLd(ld) {
  if (!ld?.jobLocation) return '';
  const loc = ld.jobLocation;
  const one = Array.isArray(loc) ? loc[0] : loc;
  if (typeof one === 'string') return one;
  const addr = one?.address;
  if (typeof addr === 'string') return addr;
  if (addr && typeof addr === 'object') {
    return [addr.addressLocality, addr.addressRegion, addr.addressCountry]
      .filter(Boolean)
      .join(', ');
  }
  return String(one?.name || '').trim();
}

function findBestDescriptionBlock() {
  const selectors = [
    '[class*="job-description"]',
    '[id*="job-description"]',
    '[class*="jobdescription"]',
    '[data-automation-id*="jobPostingDescription"]',
    '[class*="description"]',
    '[id*="description"]',
    '[class*="posting"]',
    'article',
    'main',
    '[role="main"]',
    '#content',
    '.content'
  ];

  let best = '';
  let bestScore = 0;

  const seen = new Set();
  for (const sel of selectors) {
    let nodes = [];
    try {
      nodes = Array.from(document.querySelectorAll(sel));
    } catch {
      continue;
    }
    for (const node of nodes) {
      if (seen.has(node)) continue;
      seen.add(node);
      const t = textOf(node);
      if (t.length < 120) continue;
      const signals = countJobSignals(t);
      const score = signals * 200 + Math.min(t.length, 8000);
      if (score > bestScore) {
        bestScore = score;
        best = t;
      }
    }
  }
  return best;
}

function inferCompany(title, body, ldOrg) {
  if (ldOrg) return String(ldOrg).trim();
  const ogSite = document.querySelector('meta[property="og:site_name"]')?.getAttribute('content');
  if (ogSite && ogSite.length > 1 && ogSite.length < 120) return ogSite.trim();
  const t = String(title || '');
  const m = t.match(/^(.+?)\s+[-|–—]\s+/);
  if (m && m[1].length < 80) return m[1].trim();
  const host = window.location.hostname.replace(/^www\./, '');
  const brand = host.split('.').filter((p) => p !== 'com' && p !== 'in' && p !== 'en')[0];
  if (brand && brand.length > 2) {
    return brand.charAt(0).toUpperCase() + brand.slice(1);
  }
  return '';
}

const CAREERS_HOST_HINTS = /(greenhouse|lever\.co|workday|icims|smartrecruiters|ashbyhq|bamboohr|jobvite|taleo|myworkdayjobs)/i;

const JOB_PATH_RE = [
  /\/jobs?\//i,
  /\/careers?\//i,
  /\/positions?\//i,
  /\/openings?\//i,
  /\/opportunities?\//i,
  /\/requisition/i,
  /\/role\//i,
  /\/vacanc/i,
  /jobid=/i,
  /gh_jid=/i,
  /\/apply\//i
];

const ROLE_TITLE_RE =
  /\b(engineer|developer|architect|manager|analyst|designer|consultant|intern|lead|devops|backend|frontend|full[- ]?stack|data|cloud|java|node|python|react|aws)\b/i;

function scoreJobMatch(title, haystack, terms) {
  if (!terms?.length) return 0;
  const text = `${title} ${haystack}`.toLowerCase();
  let score = 0;
  for (const t of terms) {
    if (text.includes(t)) score += 1;
  }
  return score;
}

function extractCareersListingJobs(matchTerms = []) {
  const terms = (Array.isArray(matchTerms) ? matchTerms : [])
    .map((t) => String(t || '').toLowerCase().trim())
    .filter((t) => t.length > 2);
  const pageUrl = window.location.href;
  const pageHost = window.location.hostname;
  const company = inferCompany(document.title, '', '');
  const seen = new Set();
  const jobs = [];

  const anchors = document.querySelectorAll('a[href]');
  for (const a of anchors) {
    let href = a.getAttribute('href') || '';
    if (!href || href.startsWith('#') || /^javascript:/i.test(href)) continue;
    let abs;
    try {
      abs = new URL(href, pageUrl);
    } catch {
      continue;
    }
    if (abs.protocol !== 'http:' && abs.protocol !== 'https:') continue;

    const sameSite =
      abs.hostname === pageHost ||
      abs.hostname.endsWith(`.${pageHost.replace(/^www\./, '')}`) ||
      CAREERS_HOST_HINTS.test(abs.hostname);
    if (!sameSite) continue;

    const pathHay = `${abs.pathname} ${abs.search}`.toLowerCase();
    let title = textOf(a);
    if (title.length > 140) title = title.slice(0, 140);
    if (!title || title.length < 3) {
      title =
        a.getAttribute('aria-label') ||
        a.getAttribute('data-job-title') ||
        a.closest('[data-job-id], [class*="job"], [class*="opening"]')?.querySelector('h2,h3,h4')?.innerText ||
        '';
      title = String(title || '').replace(/\s+/g, ' ').trim().slice(0, 140);
    }

    const looksLikeJobLink = JOB_PATH_RE.some((re) => re.test(pathHay));
    const looksLikeRoleTitle = title.length >= 4 && ROLE_TITLE_RE.test(title);
    if (!looksLikeJobLink && !looksLikeRoleTitle) continue;
    if (title.length < 3) continue;

    const key = abs.origin + abs.pathname + abs.search;
    if (seen.has(key)) continue;
    seen.add(key);

    const parentText = textOf(a.closest('li, tr, article, [class*="job"], [class*="result"]') || a).slice(0, 400);
    const matchScore = scoreJobMatch(title, `${parentText} ${pathHay}`, terms);
    jobs.push({
      title,
      url: abs.href,
      company,
      location: '',
      matchScore
    });
  }

  jobs.sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0) || a.title.localeCompare(b.title));
  const isCareersListing =
    jobs.length >= 3 ||
    /\b(careers?|jobs?|openings?|vacancies)\b/i.test(`${document.title} ${pageUrl}`);

  return {
    pageUrl,
    pageTitle: document.title || '',
    company,
    isCareersListing,
    totalOnPage: jobs.length,
    jobs: jobs.slice(0, 50)
  };
}

function extractJobContext() {
  const url = window.location.href;
  const title = document.title || '';
  const ld = readJsonLdJobPosting();

  let jobTitle =
    (ld?.title && String(ld.title).trim()) ||
    pickFirstText([
      'h1',
      '[data-testid*="job-title"]',
      '[class*="job-title"]',
      '.job-title',
      '[role="heading"]'
    ]) ||
    title.split(/[|\-–—]/)[0].trim();

  let company = inferCompany(title, '', ld?.hiringOrganization?.name || ld?.hiringOrganization);
  let jobLocation = locationFromLd(ld) || pickFirstText(['[class*="location"]', '.location', '[data-testid*="location"]']);

  let jobDescription = '';
  if (ld?.description) {
    jobDescription = stripHtml(ld.description);
  }
  if (!jobDescription || jobDescription.length < 80) {
    jobDescription = findBestDescriptionBlock();
  }
  if (!jobDescription || jobDescription.length < 80) {
    jobDescription = pickFirstText(['#jobDescriptionText', '[class*="job-desc"]', 'article', 'main']);
  }
  if (!jobDescription || jobDescription.length < 80) {
    const root = document.querySelector('main, article, [role="main"], #content') || document.body;
    jobDescription = textOf(root);
  }

  jobDescription = String(jobDescription || '').slice(0, 50_000);
  const signalCount = countJobSignals(`${title}\n${jobDescription}`);
  const isJobPage =
    signalCount >= 2 ||
    !!ld ||
    (jobDescription.length >= 400 && signalCount >= 1) ||
    /\b(job|career|opening|vacancy|position)\b/i.test(`${title} ${url}`);

  return {
    url,
    title,
    site: 'auto',
    isJobPage,
    jobTitle: jobTitle || title.split('|')[0].trim(),
    company,
    location: jobLocation,
    jobDescription
  };
}

function setNativeValue(el, value) {
  if (!el || value == null) return false;
  const v = String(value);
  el.focus();
  el.value = v;
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
}

function matchField(el, keys) {
  const name = (el.name || '').toLowerCase();
  const id = (el.id || '').toLowerCase();
  const ph = (el.placeholder || '').toLowerCase();
  const label = el.labels?.[0]?.innerText?.toLowerCase() || '';
  const aria = (el.getAttribute('aria-label') || '').toLowerCase();
  const hay = `${name} ${id} ${ph} ${label} ${aria}`;
  return keys.some((k) => hay.includes(k));
}

function fillApplicationForm(profile) {
  const p = profile || {};
  const name = p.name || '';
  const parts = name.split(/\s+/).filter(Boolean);
  const first = p.firstName || parts[0] || '';
  const last = p.lastName || (parts.length > 1 ? parts.slice(1).join(' ') : '');
  const email = p.email || '';
  const mobile = p.mobile || p.phone || '';
  const city = p.city || p.location || '';

  const fields = Array.from(
    document.querySelectorAll(
      'input:not([type="hidden"]):not([type="submit"]):not([type="button"]), textarea, select'
    )
  );

  let filled = 0;
  for (const el of fields) {
    if (el.disabled || el.readOnly) continue;
    const type = (el.type || '').toLowerCase();
    if (type === 'checkbox' || type === 'radio' || type === 'file') continue;

    if (matchField(el, ['email', 'e-mail'])) {
      if (setNativeValue(el, email)) filled++;
    } else if (matchField(el, ['mobile', 'phone', 'contact', 'tel'])) {
      if (setNativeValue(el, mobile)) filled++;
    } else if (matchField(el, ['first name', 'firstname', 'fname', 'given'])) {
      if (setNativeValue(el, first)) filled++;
    } else if (matchField(el, ['last name', 'lastname', 'lname', 'surname', 'family'])) {
      if (setNativeValue(el, last)) filled++;
    } else if (matchField(el, ['full name', 'fullname', 'your name', 'candidate name']) && name) {
      if (setNativeValue(el, name)) filled++;
    } else if (matchField(el, ['city', 'location', 'current city'])) {
      if (city && setNativeValue(el, city)) filled++;
    } else if (matchField(el, ['linkedin', 'profile url']) && p.linkedinUrl) {
      if (setNativeValue(el, p.linkedinUrl)) filled++;
    }
  }

  return { filled, total: fields.length };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'GET_PAGE_JOB_CONTEXT') {
    try {
      sendResponse({ success: true, pageContext: extractJobContext() });
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }
  if (msg.type === 'SCAN_CAREERS_PAGE_JOBS') {
    try {
      const scan = extractCareersListingJobs(msg.matchTerms || [])
      if (!scan.jobs.length) {
        sendResponse({
          success: false,
          error:
            'No job links found on this page. Open a careers listing (multiple roles), not a single job detail page.'
        })
        return true
      }
      sendResponse({ success: true, ...scan })
    } catch (e) {
      sendResponse({ success: false, error: e.message })
    }
    return true
  }
  if (msg.type === 'FILL_APPLICATION_FORM') {
    try {
      const out = fillApplicationForm(msg.profile || {});
      sendResponse({ success: true, ...out });
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }
});
