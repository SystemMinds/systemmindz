/**
 * Monster HTTP/session helpers for the extension service worker.
 */

const MONSTER_ORIGINS = [
  'https://www.monster.com',
  'https://monster.com',
  'https://identity.monster.com',
  'https://appsapi.monster.io',
];

const DEFAULT_BASE = 'https://www.monster.com';
const MONSTER_TAB_URLS = ['https://www.monster.com/*', 'https://*.monster.com/*'];

export async function getAllMonsterCookies(baseUrl = DEFAULT_BASE) {
  const all = [];
  for (const origin of MONSTER_ORIGINS) {
    try {
      const batch = await chrome.cookies.getAll({ url: origin });
      if (Array.isArray(batch)) all.push(...batch);
    } catch {
      /* ignore */
    }
  }
  try {
    const batch = await chrome.cookies.getAll({ url: baseUrl });
    if (Array.isArray(batch)) all.push(...batch);
  } catch {
    /* ignore */
  }
  try {
    const batch = await chrome.cookies.getAll({ domain: '.monster.com' });
    if (Array.isArray(batch)) all.push(...batch);
  } catch {
    /* ignore */
  }
  const seen = new Set();
  const unique = [];
  for (const c of all) {
    const key = `${c.domain}|${c.name}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(c);
  }
  return unique;
}

export function cookieValue(cookies, name) {
  const hit = cookies.find((c) => String(c.name).toLowerCase() === String(name).toLowerCase());
  return hit?.value ? String(hit.value).trim() : '';
}

export function buildCookieHeader(cookies) {
  return cookies
    .filter((c) => c?.name && c?.value != null)
    .map((c) => `${c.name}=${c.value}`)
    .join('; ');
}

export function isLoggedIn(cookies, { profileId } = {}) {
  if (String(profileId || '').trim()) return true
  if (!Array.isArray(cookies) || !cookies.length) return false
  const names = cookies.map((c) => String(c.name || '').toLowerCase())
  if (
    names.some(
      (n) =>
        n !== 'datadome' &&
        (n.includes('session') ||
          n.includes('auth') ||
          n.includes('identity') ||
          n.includes('token') ||
          (n.includes('monster') && !n.includes('datadome')))
    )
  ) {
    return true
  }
  // Logged-in Monster sessions usually carry several cookies — datadome alone is bot protection.
  const nonDatadome = cookies.filter((c) => String(c.name || '').toLowerCase() !== 'datadome')
  return nonDatadome.length >= 2
}

export function isMonsterAuthCookie(name) {
  const n = String(name || '').toLowerCase();
  return n === 'datadome' || n.includes('monster') || n.includes('session');
}

function readMonsterSessionFromMainWorld() {
  const read = (key) => {
    try {
      return localStorage.getItem(key) || sessionStorage.getItem(key) || '';
    } catch {
      return '';
    }
  };

  let datadomeClientId = String(window.__kgMonsterDatadomeClientId || '').trim();
  let profileId = String(window.__kgMonsterProfileId || '').trim();
  let fingerprintId = String(window.__kgMonsterFingerprintId || '').trim();

  if (!datadomeClientId) {
    datadomeClientId =
      read('datadome-clientid') ||
      read('x-datadome-clientid') ||
      read('datadomeClientId') ||
      '';
  }
  if (!profileId) {
    profileId = read('profileId') || read('monster-profile-id') || read('profile-id') || '';
  }
  if (!fingerprintId) {
    fingerprintId = read('fingerprintId') || read('monster-fingerprint-id') || '';
  }

  try {
    if (!datadomeClientId && window.DD?.clientId) {
      datadomeClientId = String(window.DD.clientId).trim();
    }
  } catch {
    /* ignore */
  }

  const scanStore = (store) => {
    if (!store) return;
    try {
      for (let i = 0; i < store.length; i += 1) {
        const key = String(store.key(i) || '');
        const val = String(store.getItem(key) || '').trim();
        if (!val) continue;
        const kl = key.toLowerCase();
        if (!profileId && kl.includes('profile') && /^[0-9a-f-]{36}$/i.test(val)) profileId = val;
        if (!fingerprintId && kl.includes('fingerprint') && val.length >= 16 && val.length <= 64) {
          fingerprintId = val;
        }
        if (!datadomeClientId && kl.includes('datadome') && val.length >= 20) datadomeClientId = val;
      }
    } catch {
      /* ignore */
    }
  };
  scanStore(window.localStorage);
  scanStore(window.sessionStorage);

  return {
    datadomeClientId: String(datadomeClientId || '').trim(),
    profileId: String(profileId || '').trim(),
    fingerprintId: String(fingerprintId || '').trim(),
  };
}

async function injectMonsterHooksIntoTab(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      world: 'MAIN',
      files: ['content-monster-page-hook.js'],
    });
  } catch {
    /* tab may be restricted */
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      files: ['content-monster-bridge.js'],
    });
  } catch {
    /* ignore */
  }
}

/** Pull DataDome client id + profile/fingerprint from open monster.com tabs (MAIN world). */
export async function pullMonsterSessionFromOpenTabs({ injectHooks = true } = {}) {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: MONSTER_TAB_URLS });
  } catch {
    return null;
  }

  let best = null;

  for (const tab of tabs) {
    if (!tab?.id) continue;

    if (injectHooks) {
      await injectMonsterHooksIntoTab(tab.id);
    }

    let result = null;
    try {
      const [{ result: snap }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: readMonsterSessionFromMainWorld,
      });
      result = snap;
    } catch {
      /* ignore */
    }

    if (result?.datadomeClientId) {
      await persistMonsterSessionMeta(result);
      return result;
    }
    if (result?.profileId && !best?.datadomeClientId) {
      best = result;
    }

    // Ask the page hook to re-scan storage and reply via bridge → storage
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: () => {
          window.postMessage({ source: 'kg-monster-bridge', type: 'REQUEST_MONSTER_SESSION' }, window.location.origin);
        },
      });
      await new Promise((r) => setTimeout(r, 250));
      const stored = await chrome.storage.local.get([
        'monsterDatadomeClientId',
        'monsterProfileId',
        'monsterFingerprintId',
      ]);
      if (stored.monsterDatadomeClientId) {
        const captured = {
          datadomeClientId: String(stored.monsterDatadomeClientId || '').trim(),
          profileId: String(stored.monsterProfileId || '').trim(),
          fingerprintId: String(stored.monsterFingerprintId || '').trim(),
        };
        await persistMonsterSessionMeta(captured);
        return captured;
      }
      if (stored.monsterProfileId && !best?.datadomeClientId) {
        best = {
          datadomeClientId: '',
          profileId: String(stored.monsterProfileId || '').trim(),
          fingerprintId: String(stored.monsterFingerprintId || '').trim(),
        };
      }
    } catch {
      /* ignore */
    }
  }

  if (best?.profileId || best?.datadomeClientId) {
    await persistMonsterSessionMeta(best);
    return best;
  }
  return null;
}

/** Passive session capture before sync/search — never calls Monster APIs from the browser. */
export async function captureMonsterSessionForSync() {
  await pullMonsterSessionFromOpenTabs({ injectHooks: true });
  return getMonsterSessionSnapshot();
}

/** Cookie/session presence check only — Monster API calls go through backend proxy. */
export async function probeMonsterCookieSession() {
  await pullMonsterSessionFromOpenTabs({ injectHooks: false });
  const snap = await getMonsterSessionSnapshot();
  const hasCookies = Boolean(String(snap.cookieHeader || '').trim().length >= 10);
  if (!hasCookies && !snap.loggedIn) {
    return { ok: false, reason: 'MONSTER_NOT_LOGGED_IN' };
  }
  return {
    ok: true,
    hasDatadome: snap.hasDatadome,
    cookieCount: snap.cookieCount || 0,
    backendOnly: true,
  };
}

export async function getMonsterSessionSnapshot() {
  const cookies = await getAllMonsterCookies()
  const cookieHeader = buildCookieHeader(cookies)
  const stored = await chrome.storage.local.get([
    'monsterDatadomeClientId',
    'monsterProfileId',
    'monsterFingerprintId',
    'monsterDatadomeAt',
  ])
  const datadomeClientId = String(stored.monsterDatadomeClientId || '').trim()
  const profileId = String(stored.monsterProfileId || '').trim()
  const fingerprintId = String(stored.monsterFingerprintId || '').trim()

  return {
    loggedIn: isLoggedIn(cookies, { profileId }) || Boolean(profileId),
    cookieHeader,
    datadomeClientId,
    profileId,
    fingerprintId,
    hasDatadome: Boolean(datadomeClientId),
    cookieCount: cookies.length,
    authCookies: cookies.filter((c) => isMonsterAuthCookie(c.name)).map((c) => c.name),
  }
}

export async function persistMonsterSessionMeta({ datadomeClientId, profileId, fingerprintId } = {}) {
  const patch = {};
  if (datadomeClientId) {
    patch.monsterDatadomeClientId = String(datadomeClientId).trim();
    patch.monsterDatadomeAt = new Date().toISOString();
  }
  if (profileId) patch.monsterProfileId = String(profileId).trim();
  if (fingerprintId) patch.monsterFingerprintId = String(fingerprintId).trim();
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
}
