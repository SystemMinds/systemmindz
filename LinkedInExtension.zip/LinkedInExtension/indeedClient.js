/**
 * Indeed HTTP client for the extension service worker (browser session + cookies).
 * Mirrors backend/src/career/services/indeed/indeed.client.js pattern.
 */

const INDEED_ORIGINS = [
  'https://in.indeed.com',
  'https://www.indeed.com',
  'https://indeed.com',
  'https://secure.indeed.com',
]

const DEFAULT_COUNTRY = 'IN'
const DEFAULT_LOCALE = 'en-IN'
const DEFAULT_BASE = 'https://in.indeed.com'

/** Public graphql keys observed in Indeed web clients (operation-specific; fallback only). */
const GRAPHQL_API_KEYS = {
  default: '4478d7e8947a5d00ef519267aceb40da79a62388a57366b00e5a0c090533c6fd',
  profile: '176bee76fee13e7dd476a8eb31278b2e9bc1363a0f620338c7d7e65162af0ed4',
}

export function resolveIndeedBase(country = DEFAULT_COUNTRY) {
  const co = String(country || DEFAULT_COUNTRY).toUpperCase()
  if (co === 'IN') return 'https://in.indeed.com'
  if (co === 'US') return 'https://www.indeed.com'
  return `https://${co.toLowerCase()}.indeed.com`
}

async function getAllIndeedCookies(baseUrl = DEFAULT_BASE) {
  const all = []
  for (const origin of INDEED_ORIGINS) {
    try {
      const batch = await chrome.cookies.getAll({ url: origin })
      if (Array.isArray(batch)) all.push(...batch)
    } catch {
      /* ignore per-origin failures */
    }
  }
  try {
    const batch = await chrome.cookies.getAll({ url: baseUrl })
    if (Array.isArray(batch)) all.push(...batch)
  } catch {
    /* ignore */
  }
  const seen = new Set()
  const unique = []
  for (const c of all) {
    const key = `${c.domain}|${c.name}`
    if (seen.has(key)) continue
    seen.add(key)
    unique.push(c)
  }
  return unique
}

function cookieValue(cookies, name) {
  const hit = cookies.find((c) => String(c.name).toLowerCase() === String(name).toLowerCase())
  return hit?.value ? String(hit.value).trim() : ''
}

function buildCookieHeader(cookies) {
  return cookies.map((c) => `${c.name}=${c.value}`).join('; ')
}

/** Cookies that indicate a signed-in Indeed account (not anonymous tracking). */
export const INDEED_AUTH_COOKIE_NAMES = new Set([
  'PPID',
  'ppid',
  'SOCK',
  'sock',
  'INDEED_CSRF_TOKEN',
  'SHOE',
  'SHOE_STRING',
  'INDEED_RCC',
])

export function isIndeedAuthCookie(name) {
  return INDEED_AUTH_COOKIE_NAMES.has(String(name || ''))
}

function isLoggedIn(cookies) {
  if (!Array.isArray(cookies) || !cookies.length) return false
  const hasPpid = Boolean(cookieValue(cookies, 'PPID') || cookieValue(cookies, 'ppid'))
  const hasSock = Boolean(cookieValue(cookies, 'SOCK') || cookieValue(cookies, 'sock'))
  const hasCsrf = Boolean(cookieValue(cookies, 'INDEED_CSRF_TOKEN') || cookieValue(cookies, 'CSRF'))
  // CTK / device_id exist for anonymous visitors — require an auth session cookie.
  return hasPpid || (hasSock && hasCsrf)
}

/**
 * Build headers for Indeed API calls from browser cookies.
 * @param {{ country?: string, locale?: string, referer?: string, graphql?: boolean }} opts
 */
export async function buildIndeedHeaders(opts = {}) {
  const country = String(opts.country || DEFAULT_COUNTRY).toUpperCase()
  const locale = String(opts.locale || DEFAULT_LOCALE)
  const base = resolveIndeedBase(country)
  const cookies = await getAllIndeedCookies(base)
  const ctk = cookieValue(cookies, 'CTK') || cookieValue(cookies, 'INDEED_CTK')
  const csrf = cookieValue(cookies, 'INDEED_CSRF_TOKEN') || cookieValue(cookies, 'CSRF')

  if (!cookies.length) {
    const err = new Error('Not logged into Indeed (no cookies found). Open indeed.com and sign in.')
    err.code = 'NOT_LOGGED_IN'
    throw err
  }

  const headers = {
    Accept: opts.graphql ? '*/*' : 'application/json, text/html, */*',
    'Accept-Language': 'en-US,en;q=0.9',
    Origin: base,
    Referer: opts.referer || `${base}/`,
    'Cache-Control': 'no-cache',
    Pragma: 'no-cache',
  }

  const cookieHeader = buildCookieHeader(cookies)
  if (cookieHeader) headers.Cookie = cookieHeader
  if (ctk) headers['indeed-ctk'] = ctk
  if (csrf) headers.indeedcsrftoken = csrf
  if (country) headers['indeed-co'] = country
  if (locale) headers['indeed-locale'] = locale
  if (opts.graphql) {
    headers['Content-Type'] = 'application/json'
    headers['indeed-api-key'] = GRAPHQL_API_KEYS[opts.graphqlKey || 'default'] || GRAPHQL_API_KEYS.default
  }

  return { headers, cookies, cookieHeader: buildCookieHeader(cookies), base, ctk, csrf, country, locale }
}

/**
 * GET/POST against Indeed with browser credentials.
 */
export async function indeedFetch(url, options = {}) {
  const country = options.country || DEFAULT_COUNTRY
  const built = await buildIndeedHeaders({
    country,
    locale: options.locale,
    referer: options.referer,
    graphql: options.graphql,
    graphqlKey: options.graphqlKey,
  })

  const res = await fetch(url, {
    method: options.method || 'GET',
    headers: { ...built.headers, ...(options.headers || {}) },
    credentials: 'include',
    body: options.body,
  })

  if (res.status === 401 || res.status === 403) {
    const snippet = await res.clone().text().catch(() => '')
    if (/Security Check|bot-detection|challenge-platform/i.test(snippet)) {
      const err = new Error('Indeed security check required.')
      err.code = 'INDEED_CHALLENGE'
      err.status = res.status
      throw err
    }
    const err = new Error('Indeed session expired or blocked. Log in on indeed.com and sync again.')
    err.code = 'COOKIE_EXPIRED'
    err.status = res.status
    throw err
  }
  if (res.status === 429) {
    const err = new Error('Indeed rate limited this request. Wait and retry.')
    err.code = 'RATE_LIMITED'
    err.status = res.status
    throw err
  }

  return { res, built }
}

export async function getIndeedSessionSnapshot() {
  const cookies = await getAllIndeedCookies()
  const cookieHeader = buildCookieHeader(cookies)
  if (!cookies.length) {
    return {
      cookieHeader: '',
      ctk: '',
      csrf: '',
      country: DEFAULT_COUNTRY,
      loggedIn: false,
      cookieCount: 0,
    }
  }
  const country = DEFAULT_COUNTRY
  return {
    cookieHeader,
    ctk: cookieValue(cookies, 'CTK') || cookieValue(cookies, 'INDEED_CTK'),
    csrf: cookieValue(cookies, 'INDEED_CSRF_TOKEN') || cookieValue(cookies, 'CSRF'),
    country,
    loggedIn: isLoggedIn(cookies),
    cookieCount: cookies.length,
  }
}

/** Verify Indeed cookies work from the browser (not backend proxy). */
export async function probeIndeedCookieSession(country = DEFAULT_COUNTRY) {
  const snap = await getIndeedSessionSnapshot()
  if (!snap.loggedIn || !snap.cookieHeader) {
    return { ok: false, reason: 'INDEED_NOT_LOGGED_IN' }
  }

  const base = resolveIndeedBase(country)
  const url = `${base}/jobs?q=software+developer&fromage=7`
  try {
    const { res } = await indeedFetch(url, {
      country,
      referer: `${base}/`,
      headers: { Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' },
    })
    const html = await res.text()
    if (res.status === 401 || res.status === 403) {
      return { ok: false, reason: 'COOKIE_EXPIRED' }
    }
    const hasJobs =
      html.includes('mosaic-provider-jobcards') ||
      html.includes('data-jk="') ||
      /data-jk="[a-f0-9]{16}"/i.test(html)
    if (!hasJobs && /account\/login/i.test(html)) {
      return { ok: false, reason: 'INDEED_CHALLENGE' }
    }
    return { ok: true, hasJobs }
  } catch (e) {
    return { ok: false, reason: e?.code || 'NETWORK', message: e?.message || String(e) }
  }
}
