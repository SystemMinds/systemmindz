/**
 * Stable extension device identity + dynamic LinkedIn fingerprint metadata.
 */

const DEVICE_ID_KEY = 'extensionDeviceId'
const SCREEN_CACHE_KEY = 'deviceScreen'

export async function getExtensionDeviceId() {
  const stored = await chrome.storage.local.get(DEVICE_ID_KEY)
  if (stored[DEVICE_ID_KEY]) return stored[DEVICE_ID_KEY]
  const id = crypto.randomUUID()
  await chrome.storage.local.set({ [DEVICE_ID_KEY]: id })
  return id
}

/** Call from popup on load so the service worker has real screen dimensions. */
export async function cacheDeviceScreenFromWindow() {
  try {
    if (typeof screen === 'undefined') return
    await chrome.storage.local.set({
      [SCREEN_CACHE_KEY]: {
        width: screen.width,
        height: screen.height,
        pixelRatio: typeof devicePixelRatio === 'number' ? devicePixelRatio : 1,
      },
    })
  } catch {
    /* ignore */
  }
}

async function resolveScreenMeta() {
  try {
    if (typeof screen !== 'undefined' && screen.width) {
      return {
        width: screen.width,
        height: screen.height,
        pixelRatio: typeof devicePixelRatio === 'number' ? devicePixelRatio : 1,
      }
    }
  } catch {
    /* service worker may not expose screen */
  }
  const stored = await chrome.storage.local.get(SCREEN_CACHE_KEY)
  if (stored[SCREEN_CACHE_KEY]) return stored[SCREEN_CACHE_KEY]
  return { width: 1920, height: 1080, pixelRatio: 1 }
}

export async function collectDeviceMeta() {
  const userAgent = typeof navigator !== 'undefined' ? navigator.userAgent : ''
  let timezone = 'UTC'
  let timezoneOffset = 0
  try {
    const opts = Intl.DateTimeFormat().resolvedOptions()
    timezone = opts.timeZone || timezone
    timezoneOffset = -new Date().getTimezoneOffset() / 60
  } catch {
    /* ignore */
  }
  const screenMeta = await resolveScreenMeta()
  return {
    userAgent,
    timezone,
    timezoneOffset,
    screen: screenMeta,
  }
}

export async function buildLinkedInVoyagerFingerprint() {
  const meta = await collectDeviceMeta()
  const pixelRatio = Number(meta.screen?.pixelRatio) || 1
  return {
    userAgent: meta.userAgent,
    timezone: meta.timezone,
    timezoneOffset: meta.timezoneOffset,
    displayWidth: meta.screen?.width || 1920,
    displayHeight: meta.screen?.height || 1080,
    displayDensity: pixelRatio >= 2 ? 2 : 1,
    pixelRatio,
  }
}

export async function buildLinkedInVoyagerHeaders(extra = {}) {
  const { liAtCookie, jsessionCookie } = await import('./linkedinCookies.js').then((m) =>
    m.getLinkedInAuthCookies()
  )
  if (!jsessionCookie || !liAtCookie) {
    const err = new Error('Not logged into LinkedIn (missing li_at or JSESSIONID)')
    err.code = 'NOT_LOGGED_IN'
    throw err
  }
  const fp = await buildLinkedInVoyagerFingerprint()
  const csrfToken = jsessionCookie.value.replace(/^"(.*)"$/, '$1')
  const clientVer = '1.13.43955'
  return {
    Accept: 'application/vnd.linkedin.normalized+json+2.1',
    'Accept-Language': 'en-US,en;q=0.9',
    'Csrf-Token': csrfToken,
    Origin: 'https://www.linkedin.com',
    Referer: 'https://www.linkedin.com/',
    'User-Agent': fp.userAgent,
    'X-Li-Lang': 'en_US',
    'X-RestLi-Protocol-Version': '2.0.0',
    'X-Li-Track': JSON.stringify({
      clientVersion: clientVer,
      mpVersion: clientVer,
      osName: 'web',
      timezoneOffset: fp.timezoneOffset,
      timezone: fp.timezone,
      deviceFormFactor: 'DESKTOP',
      mpName: 'voyager-web',
      displayDensity: fp.displayDensity,
      displayWidth: fp.displayWidth,
      displayHeight: fp.displayHeight,
    }),
    ...extra,
  }
}

export function formatDeviceSyncTime(iso) {
  if (!iso) return 'Unknown time'
  try {
    return new Date(iso).toLocaleString(undefined, {
      dateStyle: 'medium',
      timeStyle: 'short',
    })
  } catch {
    return String(iso)
  }
}
