/**
 * SuperadminBackend auth — same contract as CandidateFrontend (authAxiosInstance).
 * Career API (CandidateBackend) is separate; only login/refresh use auth API.
 */

export const DEFAULT_AUTH_API_BASE = 'https://192.168.1.65:8441'
export const DEFAULT_CAREER_API_BASE = 'https://192.168.1.65:8443/api'
export const DEFAULT_AI_CHAT_API_BASE = 'https://192.168.1.65:9000/api'
export const DEFAULT_DASHBOARD_URL = 'https://192.168.1.65:4003'

export function stripTrailingSlashes(s) {
  return (s && String(s).trim().replace(/\/+$/, '')) || ''
}

/** Auth base is origin only (routes are /auth-session/...). */
export function normalizeAuthApiBase(input, fallback = DEFAULT_AUTH_API_BASE) {
  let raw = String(input || '').trim().replace(/\/+$/, '')
  if (!raw) return stripTrailingSlashes(fallback)
  if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`
  try {
    const u = new URL(raw)
    return u.origin
  } catch {
    return stripTrailingSlashes(fallback)
  }
}

export function normalizeVppoApiBase(input, fallbackBase) {
  const fallback = String(fallbackBase || '').trim().replace(/\/+$/, '')
  let raw = String(input || '').trim().replace(/\/+$/, '')
  if (!raw) return fallback
  if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`
  try {
    const u = new URL(raw)
    let path = u.pathname || '/'
    path = path.replace(/\/+$/, '') || '/'
    const lower = path.toLowerCase()
    if (path === '/' || path === '') {
      path = '/api'
    } else if (!lower.endsWith('/api')) {
      path = `${path}/api`
    }
    let out = `${u.origin}${path}`.replace(/\/+$/, '')
    while (/\/api\/api$/i.test(out)) out = out.replace(/\/api\/api$/i, '/api')
    return out || fallback
  } catch {
    return fallback
  }
}

export async function getAuthApiBase() {
  const { authApiBase } = await chrome.storage.local.get('authApiBase')
  return normalizeAuthApiBase(authApiBase, DEFAULT_AUTH_API_BASE)
}

export async function getCareerApiBase() {
  const { careerApiBase } = await chrome.storage.local.get('careerApiBase')
  return normalizeVppoApiBase(careerApiBase, DEFAULT_CAREER_API_BASE)
}

export async function getAiChatApiBase() {
  const { aiChatApiBase } = await chrome.storage.local.get('aiChatApiBase')
  return normalizeVppoApiBase(aiChatApiBase, DEFAULT_AI_CHAT_API_BASE)
}

/** Parse SuperadminBackend envelope { success, data: { accessToken, refreshToken, xsrfToken } }. */
export function parseAuthTokens(json) {
  const d = json?.data ?? json
  const accessToken = d?.accessToken || d?.access_token
  const refreshToken = d?.refreshToken || d?.refresh_token
  const xsrfToken = d?.xsrfToken || d?.xsrf_token
  if (!accessToken) return null
  return { accessToken, refreshToken, xsrfToken }
}
