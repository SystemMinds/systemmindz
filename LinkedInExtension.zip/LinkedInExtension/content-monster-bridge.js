/**
 * Isolated-world bridge for Monster page hook → extension background.
 */
(function () {
  if (window.__kgMonsterBridgeInstalled) return;
  window.__kgMonsterBridgeInstalled = true;

  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || event.data.source !== 'kg-monster-page-hook') return;
    if (event.data.type !== 'MONSTER_SESSION_SNAPSHOT') return;
    chrome.runtime.sendMessage({
      type: 'MONSTER_SESSION_CAPTURED',
      payload: event.data.payload || {},
    });
  });

  try {
    window.postMessage({ source: 'kg-monster-bridge', type: 'REQUEST_MONSTER_SESSION' }, window.location.origin);
  } catch {
    /* ignore */
  }
})();
