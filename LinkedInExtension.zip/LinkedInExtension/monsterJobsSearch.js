/**
 * Monster job discovery — background tab scrape (Naukri/Indeed pattern).
 * API hook capture + DOM fallback; empty query continues to next search.
 */

import { capJobDescription } from './jobDescriptionLimits.js'
import { dedupeSearchJobs, jobSearchDedupeKey, resolvePlatformJobId } from './jobDedupe.js'
import { mergeSalaryFields } from './jobSalary.js'
import { resolvePostedWithinDays } from './jobSearchPrefs.js'
import {
  buildJobSearchQuerySets,
  mergeResumeSearchSkills,
  resolveJobSearchTarget,
  resolvePerQueryJobBudget,
} from './jobSearchQuerySets.js'

const MONSTER_WEB = 'https://www.monster.com'

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function waitForTabLoad(tabId, timeoutMs = 28000) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => resolve(false), timeoutMs)
    const listener = (updatedTabId, info) => {
      if (updatedTabId === tabId && info.status === 'complete') {
        clearTimeout(timeout)
        chrome.tabs.onUpdated.removeListener(listener)
        resolve(true)
      }
    }
    chrome.tabs.onUpdated.addListener(listener)
    chrome.tabs
      .get(tabId)
      .then((t) => {
        if (t?.status === 'complete') {
          clearTimeout(timeout)
          chrome.tabs.onUpdated.removeListener(listener)
          resolve(true)
        }
      })
      .catch(() => {})
  })
}

function stripHtml(html) {
  if (!html) return ''
  return String(html)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ')
    .trim()
}

function monsterJobHasListMeta(job) {
  return Boolean(String(job?.jobId || '').trim() && String(job?.title || '').trim())
}

function locationFromJob(raw) {
  const enrich = raw?.enrichments?.normalizedJobLocations?.[0]?.postalAddress?.address
  if (enrich) {
    const parts = [enrich.addressLocality, enrich.addressRegion, enrich.addressCountry].filter(Boolean)
    if (parts.length) return parts.join(', ')
  }
  const locs = raw?.jobPosting?.jobLocation || raw?.normalizedJobPosting?.jobLocation || []
  const list = Array.isArray(locs) ? locs : [locs]
  for (const loc of list) {
    const addr = loc?.address || loc
    if (!addr) continue
    const parts = [addr.addressLocality, addr.addressRegion, addr.addressCountry].filter(Boolean)
    if (parts.length) return parts.join(', ')
  }
  return ''
}

function salaryFromJob(raw) {
  const salary = raw?.jobPosting?.baseSalary || raw?.normalizedJobPosting?.baseSalary
  if (!salary) return mergeSalaryFields({})
  const min = Number(salary.value?.minValue ?? salary.minValue)
  const max = Number(salary.value?.maxValue ?? salary.maxValue)
  const currency = salary.currency || salary.value?.currency || 'USD'
  if (Number.isFinite(min) && min > 0 && Number.isFinite(max) && max > 0) {
    return mergeSalaryFields({
      salary: `${currency} ${min} - ${max}`,
      salaryMin: min,
      salaryMax: max,
      salaryCurrency: currency,
      salaryPeriod: salary.unitText || 'yearly',
    })
  }
  if (Number.isFinite(min) && min > 0) {
    return mergeSalaryFields({
      salary: `${currency} ${min}`,
      salaryMin: min,
      salaryMax: max || min,
      salaryCurrency: currency,
      salaryPeriod: salary.unitText || 'yearly',
    })
  }
  return mergeSalaryFields({})
}

function parseMonsterJob(raw) {
  if (!raw?.jobId) return null
  const jobId = String(raw.jobId).trim()
  const jp = raw.jobPosting || {}
  const njp = raw.normalizedJobPosting || {}
  const title = String(jp.title || njp.title || raw.title || '').trim()
  const company = String(jp.hiringOrganization?.name || njp.hiringOrganization?.name || raw.company || '').trim()
  const description = capJobDescription(stripHtml(jp.description || njp.description || raw.description || ''))
  const jobUrl = String(raw.canonicalUrl || raw.altUrl || raw.apply?.applyUrl || raw.jobUrl || '').trim()
  const salaryFields = salaryFromJob(raw)
  let postedAt = null
  const dateStr = raw.createdDate || jp.datePosted || njp.datePosted
  if (dateStr) {
    const d = new Date(dateStr)
    if (!Number.isNaN(d.getTime())) postedAt = d
  }

  return {
    jobId,
    title,
    company: company || String(raw.company || '').trim() || 'Company not listed',
    location: locationFromJob(raw) || String(raw.location || '').trim(),
    description,
    salary: salaryFields.salaryText || null,
    salaryText: salaryFields.salaryText || null,
    salaryMin: salaryFields.salaryMin ?? null,
    salaryMax: salaryFields.salaryMax ?? null,
    salaryCurrency: salaryFields.salaryCurrency || null,
    salaryPeriod: salaryFields.salaryPeriod || null,
    jobUrl: jobUrl || `https://www.monster.com/job-openings/${jobId}`,
    postedAt,
    source: 'monster',
  }
}

function applyPostedDaysFilter(jobs, postedDays) {
  if (!(postedDays >= 1 && postedDays <= 7) || !jobs.length) return jobs
  const cutoff = Date.now() - postedDays * 86400 * 1000
  const filtered = jobs.filter((job) => {
    if (!job.postedAt) return true
    const ts = job.postedAt instanceof Date ? job.postedAt.getTime() : new Date(job.postedAt).getTime()
    return Number.isFinite(ts) ? ts >= cutoff : true
  })
  return filtered.length ? filtered : jobs
}

function buildMonsterSearchUrl(keyword, location) {
  const q = encodeURIComponent(String(keyword || '').trim() || 'software engineer').replace(/%20/g, '+')
  const loc = String(location || '').trim()
  if (!loc) return `${MONSTER_WEB}/jobs/search?q=${q}&so=m.s.sh`
  const w = encodeURIComponent(loc).replace(/%20/g, '+')
  return `${MONSTER_WEB}/jobs/search?q=${q}&where=${w}&so=m.s.sh`
}

const MONSTER_TAB_URLS = ['https://www.monster.com/*', 'https://*.monster.com/*']

async function ensureMonsterPageHook(tabId) {
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: () => Boolean(window.__kgMonsterPageHookInstalled),
    })
    if (result) return
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content-monster-page-hook.js'],
      world: 'MAIN',
    })
  } catch {
    /* manifest content script may already be active */
  }
}

async function readMonsterPageFromTab(tabId) {
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: () => {
        try {
          window.scrollTo(0, Math.min(1200, document.body?.scrollHeight || 1200))
        } catch {
          /* ignore */
        }

        const pickText = (el) => (el?.innerText || el?.textContent || '').replace(/\s+/g, ' ').trim()
        const domJobs = []
        const seen = new Set()

        const extractId = (href) => {
          const url = String(href || '').trim()
          if (!url) return ''
          const openings = url.match(/job-openings\/([^/?#]+)/i)
          if (openings) return openings[1]
          const tail = url.match(/-(\d{6,})(?:\/?$|[?#])/i)
          if (tail) return tail[1]
          return ''
        }

        const addDomJob = (job) => {
          const id = String(job?.jobId || '').trim()
          const title = String(job?.title || '').trim()
          if (!id || !title || seen.has(id)) return
          seen.add(id)
          domJobs.push({
            jobId: id,
            title,
            company: String(job?.company || '').trim() || 'Company not listed',
            location: String(job?.location || '').trim(),
            jobUrl: job?.jobUrl || `https://www.monster.com/job-openings/${id}`,
            source: 'monster',
          })
        }

        const addCard = (card, jobId, jobUrl) => {
          const titleEl =
            card?.querySelector?.('[data-testid="job-title"]') ||
            card?.querySelector?.('h2 a') ||
            card?.querySelector?.('h2') ||
            card?.querySelector?.('h3') ||
            card?.querySelector?.('[class*="JobTitle"]') ||
            card?.querySelector?.('a[href*="job-openings"]')
          const companyEl =
            card?.querySelector?.('[data-testid="company-name"]') ||
            card?.querySelector?.('[class*="CompanyName"]') ||
            card?.querySelector?.('[class*="company"]')
          const locEl =
            card?.querySelector?.('[data-testid="job-location"]') ||
            card?.querySelector?.('[class*="Location"]') ||
            card?.querySelector?.('[class*="location"]')
          addDomJob({
            jobId,
            title: titleEl?.getAttribute?.('title') || pickText(titleEl),
            company: pickText(companyEl),
            location: pickText(locEl),
            jobUrl,
          })
        }

        document.querySelectorAll('a[href*="job-openings"], a[href*="/jobs/"]').forEach((a) => {
          const href = a.href || a.getAttribute?.('href') || ''
          const id = extractId(href)
          if (!id) return
          const card =
            a.closest('article, li, [data-testid], [class*="JobCard"], [class*="job-card"], section') ||
            a.parentElement?.parentElement ||
            a.parentElement
          addCard(card || a, id, href.startsWith('http') ? href : `https://www.monster.com${href}`)
        })

        const rail =
          document.querySelector('aside') ||
          document.querySelector('[class*="ResultsList"]') ||
          document.querySelector('[class*="results-list"]') ||
          document.querySelector('[class*="SearchResults"]')
        if (!domJobs.length) {
          document
            .querySelectorAll(
              '[class*="JobCard"], [class*="job-card"], [data-testid*="job-card"], [data-testid*="JobCard"]'
            )
            .forEach((card) => {
              const link = card.querySelector('a[href*="job-openings"], a[href*="/jobs/"]')
              const href = link?.href || link?.getAttribute?.('href') || ''
              const id = href ? extractId(href) : ''
              const title = pickText(
                card.querySelector('h2, h3, h4, [data-testid*="title"], [class*="Title"], strong, a')
              )
              if (!title) return
              const slug =
                id ||
                title
                  .toLowerCase()
                  .replace(/[^a-z0-9]+/g, '-')
                  .replace(/^-+|-+$/g, '')
                  .slice(0, 64)
              if (!slug) return
              addDomJob({
                jobId: slug,
                title,
                company:
                  pickText(
                    card.querySelector('[data-testid*="company"], [class*="Company"], [class*="employer"]')
                  ) || 'Company not listed',
                location: pickText(card.querySelector('[class*="location"], [class*="Location"]')),
                jobUrl: href.startsWith('http') ? href : href ? `https://www.monster.com${href}` : '',
              })
            })
        }

        if (rail) {
          rail.querySelectorAll('li, article, [role="listitem"], [data-testid*="job"]').forEach((row) => {
            const link = row.querySelector('a[href*="job-openings"], a[href*="/jobs/"]')
            const href = link?.href || link?.getAttribute?.('href') || ''
            let id = href ? extractId(href) : ''
            const title = pickText(
              row.querySelector('h2, h3, h4, [data-testid*="title"], [class*="Title"], strong')
            )
            const company = pickText(
              row.querySelector('[data-testid*="company"], [class*="Company"], [class*="employer"]')
            )
            if (!title) return
            if (!id) {
              id = title
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '')
                .slice(0, 64)
            }
            if (!id) return
            addDomJob({
              jobId: id,
              title,
              company: company || 'Company not listed',
              location: pickText(row.querySelector('[class*="location"], [class*="Location"]')),
              jobUrl: href.startsWith('http') ? href : href ? `https://www.monster.com${href}` : '',
            })
          })
        }

        let embeddedSearch = window.__kgLastMonsterSearchData || null
        try {
          const nextEl = document.getElementById('__NEXT_DATA__')
          if (nextEl?.textContent) {
            const walk = (node) => {
              if (!node || typeof node !== 'object') return null
              if (Array.isArray(node.jobResults) && node.jobResults.length) return node
              for (const val of Object.values(node)) {
                const hit = walk(val)
                if (hit) return hit
              }
              return null
            }
            const hit = walk(JSON.parse(nextEl.textContent))
            if (hit?.jobResults?.length) embeddedSearch = hit
          }
        } catch {
          /* ignore */
        }

        return {
          searchData: embeddedSearch,
          searchAt: Number(window.__kgLastMonsterSearchAt || 0),
          domJobs,
          onLogin:
            /\/(login|signin|sign-in)\b/i.test(location.pathname) ||
            /sign in/i.test(document.title || ''),
        }
      },
    })
    return result || null
  } catch {
    return null
  }
}

/** Poll until API hook or DOM scrape returns job cards. */
async function waitForMonsterJobsOnTab(tabId, { timeoutMs = 22000, pollMs = 700 } = {}) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const snap = await readMonsterPageFromTab(tabId)
    if (!snap) {
      await sleep(pollMs)
      continue
    }
    if (snap.onLogin) {
      const err = new Error('Log in on monster.com in Chrome, then search again.')
      err.code = 'MONSTER_NOT_LOGGED_IN'
      throw err
    }
    const jobs = jobsFromCapture(snap, 0)
    if (jobs.length) return snap
    await sleep(pollMs)
  }
  return null
}

async function scrapeMonsterSearchOnTab(tabId, { timeoutMs = 22000, closeWhenDone = false, ownTab = null } = {}) {
  await ensureMonsterPageHook(tabId)
  await sleep(400)
  const snap = await waitForMonsterJobsOnTab(tabId, { timeoutMs })
  if (closeWhenDone && ownTab?.id) chrome.tabs.remove(ownTab.id).catch(() => {})
  if (!snap) return { searchData: null, domJobs: [] }
  return { searchData: snap.searchData, domJobs: snap.domJobs || [] }
}

/** Read jobs from Monster tabs already showing search results — never navigate away. */
async function scrapeMonsterTabsInPlace({ timeoutMs = 10000 } = {}) {
  let tabs = []
  try {
    tabs = await chrome.tabs.query({ url: MONSTER_TAB_URLS })
  } catch {
    return null
  }

  const searchTabs = tabs.filter((t) => /\/jobs\/search/i.test(String(t?.url || '')))
  const ordered = [...searchTabs, ...tabs.filter((t) => !searchTabs.includes(t))]

  for (const tab of ordered) {
    if (!tab?.id) continue
    if (!/\/jobs\/search/i.test(String(tab.url || ''))) continue
    await ensureMonsterPageHook(tab.id)
    const deadline = Date.now() + timeoutMs
    while (Date.now() < deadline) {
      const snap = await readMonsterPageFromTab(tab.id)
      if (snap && jobsFromCapture(snap, 0).length) {
        return { searchData: snap.searchData, domJobs: snap.domJobs || [] }
      }
      await sleep(500)
    }
  }
  return null
}

async function captureMonsterSearchViaBackgroundTab({
  keyword,
  location,
  timeoutMs = 28000,
  skipInPlace = false,
} = {}) {
  if (!skipInPlace) {
    const inPlace = await scrapeMonsterTabsInPlace({ timeoutMs: 8000 })
    if (inPlace && jobsFromCapture(inPlace, 0).length) return inPlace
  }

  const searchUrl = buildMonsterSearchUrl(keyword, location)
  let tab = null
  try {
    tab = await chrome.tabs.create({ url: 'about:blank', active: false })
    const tabId = tab?.id
    if (!tabId) return { searchData: null, domJobs: [] }

    await ensureMonsterPageHook(tabId)
    await chrome.tabs.update(tabId, { url: searchUrl })
    await waitForTabLoad(tabId, Math.min(timeoutMs, 22000))
    return await scrapeMonsterSearchOnTab(tabId, { timeoutMs, closeWhenDone: true, ownTab: tab })
  } catch {
    return { searchData: null, domJobs: [] }
  } finally {
    if (tab?.id) chrome.tabs.remove(tab.id).catch(() => {})
  }
}

function jobsFromCapture(capture, postedDays) {
  const jobs = []
  const seen = new Set()
  const push = (job) => {
    const parsed = parseMonsterJob(job)
    if (!parsed?.jobId || !monsterJobHasListMeta(parsed)) return
    const key = String(parsed.jobId)
    if (seen.has(key)) return
    seen.add(key)
    jobs.push(parsed)
  }

  const rawJobs = Array.isArray(capture?.searchData?.jobResults) ? capture.searchData.jobResults : []
  for (const raw of rawJobs) push(raw)

  for (const dom of capture?.domJobs || []) push(dom)

  return applyPostedDaysFilter(jobs, postedDays)
}

function jobsFromSearchData(data, postedDays) {
  return jobsFromCapture({ searchData: data, domJobs: [] }, postedDays)
}

function padMonsterJobForImport(job) {
  const jobId = String(job?.jobId || '').trim()
  const title = String(job?.title || '').trim()
  const company = String(job?.company || '').trim()
  const location = String(job?.location || '').trim()
  let description = String(job?.description || '').trim()
  if (title && company) {
    const prefix = `${title} at ${company}${location ? ` in ${location}` : ''}`
    description = description ? `${prefix}. ${description}` : prefix
  }
  if (description.length < 50) {
    description = `${description}. View the full posting on Monster for requirements and how to apply.`.trim()
  }
  const jobUrl =
    String(job?.jobUrl || '').trim() || (jobId ? `https://www.monster.com/job-openings/${jobId}` : '')
  return { ...job, jobId, title, company, location, description: capJobDescription(description), jobUrl }
}

/**
 * Search Monster — background tab scrape; skip empty queries and try the next search.
 */
export async function searchMonsterJobsInExtension(opts = {}) {
  const targetCount = resolveJobSearchTarget(opts.count)
  const querySets =
    Array.isArray(opts.querySets) && opts.querySets.length
      ? opts.querySets
      : buildJobSearchQuerySets('monster', {
          jobTitle: opts.targetRole || opts.jobTitle,
          targetRole: opts.targetRole,
          skills: mergeResumeSearchSkills(opts.skills, opts.skillsStr),
          skillsStr: opts.skillsStr,
          experienceTitles: opts.experienceTitles,
          keywords: opts.keywords,
          combinedKeywords: opts.combinedKeywords,
        })

  if (!querySets.length) {
    const err = new Error('Job search keywords are required.')
    err.code = 'KEYWORDS_REQUIRED'
    throw err
  }

  const postedDays = resolvePostedWithinDays(opts.datePostedDays, 1)
  const location = String(opts.location || '').trim()
  const exclude = new Set((opts.excludeJobIds || []).map(String))
  const seenKeys = new Set()
  const seenFingerprints = new Set()
  const collected = []
  const perQueryBudget = resolvePerQueryJobBudget(targetCount, querySets.length)
  let lastError = null

  const collectFromBatch = (batch, keyword, maxTake) => {
    let taken = 0
    for (const job of batch) {
      if (taken >= maxTake || collected.length >= targetCount) break
      const jid = resolvePlatformJobId(job, 'monster') || String(job.jobId || '').trim()
      const dedupeKey = jobSearchDedupeKey(job, 'monster')
      const fpKey = `${String(job.title || '').trim().toLowerCase()}|${String(job.company || '').trim().toLowerCase()}|${String(job.location || '').trim().toLowerCase()}`
      if (!jid || exclude.has(jid) || (dedupeKey && seenKeys.has(dedupeKey))) continue
      if (fpKey !== '||' && seenFingerprints.has(fpKey)) continue
      if (!monsterJobHasListMeta(job)) continue
      exclude.add(jid)
      if (dedupeKey) seenKeys.add(dedupeKey)
      if (fpKey !== '||') seenFingerprints.add(fpKey)
      collected.push({ ...job, searchKeyword: keyword })
      taken += 1
    }
    return taken
  }

  let scrapedInPlace = false
  const quickInPlace = await scrapeMonsterTabsInPlace({ timeoutMs: 12000 })
  if (quickInPlace) {
    const quickBatch = jobsFromCapture(quickInPlace, postedDays)
    if (quickBatch.length) {
      scrapedInPlace = true
      collectFromBatch(quickBatch, querySets[0], perQueryBudget + 2)
    }
  }

  for (const keyword of querySets) {
    if (collected.length >= targetCount) break

    try {
      const capture = await captureMonsterSearchViaBackgroundTab({
        keyword,
        location,
        skipInPlace: scrapedInPlace,
      })
      const batch = jobsFromCapture(capture, postedDays)
      if (!batch.length) continue

      const perQueryLimit = Math.min(perQueryBudget + 2, targetCount - collected.length)
      collectFromBatch(batch, keyword, perQueryLimit)
    } catch (e) {
      lastError = e
      if (e?.code === 'MONSTER_NOT_LOGGED_IN') throw e
      continue
    }
  }

  if (!collected.length && lastError) throw lastError

  return {
    jobs: dedupeSearchJobs(collected.map(padMonsterJobForImport), 'monster').slice(0, targetCount),
    keywords: querySets[0],
    querySets,
  }
}

export { jobsFromSearchData, padMonsterJobForImport, parseMonsterJob }
