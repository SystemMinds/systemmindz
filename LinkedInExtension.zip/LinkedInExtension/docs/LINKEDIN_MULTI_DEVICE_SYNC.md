# LinkedIn Multi-Device Sync — Implementation Task

## Goal
LinkedIn sync must work on **Windows, macOS, and any Chrome browser** without session logout. Only **one device** may own the active LinkedIn sync per user. Switching devices requires explicit user confirmation.

## Root causes addressed
1. Hardcoded Mac User-Agent and fingerprint caused Windows logout after repeat sync.
2. No device registry — second device overwrote cookies silently and triggered LinkedIn anti-abuse.
3. Auto-sync loop (`chrome.cookies.onChanged`) amplified server-side cookie use.

---

## Phase 1 — Dynamic fingerprint (Extension + Backend)

| # | Task | File(s) | Status |
|---|------|---------|--------|
| 1.1 | Multi-origin LinkedIn cookie read + dedupe | `linkedinCookies.js`, `background.js` | Done |
| 1.2 | Generate stable `extensionDeviceId` per browser profile | `linkedinDevice.js` | Done |
| 1.3 | Collect dynamic UA, timezone, screen at sync time | `linkedinDevice.js`, `background.js` | Done |
| 1.4 | Replace hardcoded Mac UA in Voyager calls | `linkedinPeopleSearch.js`, `linkedinDevice.js` | Done |
| 1.5 | Backend stores UA + fingerprint JSON on sync | `linkedinDeviceSync.service.js` | Done |
| 1.6 | Voyager client uses stored UA/fingerprint (not Mac default) | `linkedinVoyager.client.js` | Done |

---

## Phase 2 — Device registry (Backend)

| # | Task | File(s) | Status |
|---|------|---------|--------|
| 2.1 | Create `candidate_linkedin_sync_devices` table | `initMysql.js`, `linkedinDeviceSync.service.js` | Done |
| 2.2 | Add columns: `linkedin_active_device_id`, `linkedin_session_user_agent`, `linkedin_session_fingerprint` | `linkedinDeviceSync.service.js` | Done |
| 2.3 | Parse UA → dynamic `platformLabel` (no hardcoded strings) | `linkedinUserAgent.js` | Done |
| 2.4 | `GET /candidates/career/linkedin/device-status` | controller + routes | Done |
| 2.5 | Sync conflict: 409 when other device active | `careerSync` controller | Done |
| 2.6 | Sync takeover: `takeover: true` supersedes old device | `linkedinDeviceSync.service.js` | Done |
| 2.7 | `POST /candidates/career/linkedin/disconnect` | controller + routes | Done |

---

## Phase 3 — Extension UX

| # | Task | File(s) | Status |
|---|------|---------|--------|
| 3.1 | Conflict modal with dynamic previous device details | `popup.html`, `popup.js` | Done |
| 3.2 | "Continue on this device" → sync with `takeover: true` | `popup.js`, `background.js` | Done |
| 3.3 | Superseded device banner (`disconnected_other_device`) | `popup.js` | Done |
| 3.4 | Guard auto-sync / alarm when device is superseded | `background.js` | Done |
| 3.5 | Cache screen dimensions from popup for service worker | `popup.js`, `linkedinDevice.js` | Done |
| 3.6 | `GET_LINKEDIN_DEVICE_STATUS` message handler | `background.js` | Done |

---

## API contract

### GET `/candidates/career/linkedin/device-status?extensionDeviceId=...`

```json
{
  "success": true,
  "hasActiveDevice": true,
  "isThisDeviceActive": false,
  "activeDevice": {
    "id": "uuid",
    "platformLabel": "Chrome 131 on Windows 11",
    "osName": "Windows",
    "browserName": "Chrome",
    "lastSyncAt": "2026-06-14T10:30:00.000Z"
  }
}
```

### POST `/candidates/career/sync` (extended body)

```json
{
  "liAt": "...",
  "jsessionId": "...",
  "cookieHeader": "...",
  "source": "extension",
  "extensionDeviceId": "uuid",
  "userAgent": "...",
  "timezone": "Asia/Kolkata",
  "timezoneOffset": 5.5,
  "screen": { "width": 1920, "height": 1080, "pixelRatio": 1 },
  "takeover": false
}
```

**409 response** when another device is active and `takeover !== true`:

```json
{
  "success": false,
  "reason": "LINKEDIN_SYNC_ACTIVE_ON_OTHER_DEVICE",
  "activeDevice": { "platformLabel": "...", "lastSyncAt": "..." }
}
```

---

## Testing checklist

- [ ] Windows: sync twice on same machine — no LinkedIn logout
- [ ] Mac synced → Windows sync → conflict modal with Mac details
- [ ] Windows takeover → works; Mac shows superseded banner
- [ ] Mac takeover back → symmetric behavior
- [ ] Auto-sync (30 min alarm) skipped when device superseded
- [ ] Network tab: no hardcoded Mac UA on Windows after sync
- [ ] Backend Voyager calls use stored Windows UA after Windows takeover

---

## Env notes

- `LINKEDIN_VALIDATE_ON_CONNECT=true` still validates on sync; uses stored device UA when available.
- Set `LINKEDIN_VOYAGER_USER_AGENT` only as fallback for legacy rows without stored UA.
