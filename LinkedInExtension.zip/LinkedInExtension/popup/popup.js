function getContentEl() {
  return document.getElementById('content')
}

async function cacheDeviceScreenForSync() {
  try {
    await chrome.storage.local.set({
      deviceScreen: {
        width: screen.width,
        height: screen.height,
        pixelRatio: typeof devicePixelRatio === 'number' ? devicePixelRatio : 1,
      },
    })
  } catch {
    /* ignore */
  }
}

void cacheDeviceScreenForSync()

function formatDeviceSyncTime(iso) {
  if (!iso) return 'Unknown time'
  try {
    return new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
  } catch {
    return String(iso)
  }
}

let deviceSyncModalResolver = null

function hideDeviceSyncModal() {
  const modal = document.getElementById('deviceSyncModal')
  if (modal) modal.hidden = true
  deviceSyncModalResolver = null
}

function showDeviceConflictModal(activeDevice) {
  return new Promise((resolve) => {
    const modal = document.getElementById('deviceSyncModal')
    const detail = document.getElementById('deviceSyncDetail')
    const cancelBtn = document.getElementById('deviceSyncCancelBtn')
    const continueBtn = document.getElementById('deviceSyncContinueBtn')
    if (!modal || !detail || !cancelBtn || !continueBtn) {
      resolve(false)
      return
    }
    const label = activeDevice?.platformLabel || 'Another device'
    const when = formatDeviceSyncTime(activeDevice?.lastSyncAt)
    detail.innerHTML = `<strong>${String(label).replace(/</g, '&lt;')}</strong>Last synced: ${String(when).replace(/</g, '&lt;')}`
    modal.hidden = false
    deviceSyncModalResolver = resolve

    const onCancel = () => {
      cleanup()
      resolve(false)
    }
    const onContinue = () => {
      cleanup()
      resolve(true)
    }
    const cleanup = () => {
      cancelBtn.removeEventListener('click', onCancel)
      continueBtn.removeEventListener('click', onContinue)
      hideDeviceSyncModal()
    }
    cancelBtn.addEventListener('click', onCancel)
    continueBtn.addEventListener('click', onContinue)
  })
}

async function runLinkedInSync({ takeover = false } = {}) {
  return sendRuntimeMessage({ type: 'SYNC_NOW', takeover })
}

async function runLinkedInSyncWithConflictFlow() {
  let out = await runLinkedInSync({ takeover: false })
  if (out?.conflict || out?.error === 'LINKEDIN_SYNC_ACTIVE_ON_OTHER_DEVICE') {
    const proceed = await showDeviceConflictModal(out.activeDevice)
    if (!proceed) return out
    out = await runLinkedInSync({ takeover: true })
  }
  return out
}

const content = getContentEl()
const footerHint = document.getElementById('footerHint')

function showLoadingContent(message = 'Loading KareerGrowth…') {
  const el = getContentEl()
  if (!el) return
  el.innerHTML = `
    <div class="popup-loading">
      <div class="popup-loading-spinner" aria-hidden="true"></div>
      <p class="popup-loading-text">${message.replace(/</g, '&lt;')}</p>
    </div>
  `
}

function showErrorContent(message, { retry = true, keepHeader = false } = {}) {
  const el = getContentEl()
  if (!el) return
  if (!keepHeader) setLoggedInChrome(false)
  el.innerHTML = `
    <div class="popup-error">
      <p>${String(message || 'Something went wrong.').replace(/</g, '&lt;')}</p>
      ${retry ? '<button type="button" id="popupRetryBtn">Try again</button>' : ''}
    </div>
  `
  document.getElementById('popupRetryBtn')?.addEventListener('click', () => {
    void render()
  })
}

function sendRuntimeMessage(message, timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    let settled = false
    const timer = window.setTimeout(() => {
      if (settled) return
      settled = true
      reject(new Error('Extension background did not respond. Reload the extension and try again.'))
    }, timeoutMs)

    try {
      chrome.runtime.sendMessage(message, (response) => {
        if (settled) return
        settled = true
        window.clearTimeout(timer)
        const err = chrome.runtime.lastError
        if (err) {
          reject(new Error(err.message || 'Extension unavailable'))
          return
        }
        resolve(response)
      })
    } catch (e) {
      if (settled) return
      settled = true
      window.clearTimeout(timer)
      reject(e)
    }
  })
}

const EXTENSION_VERSION = '1.1.2'
const BRAND_NAME = 'KareerGrowth'
const DEFAULT_AUTH_API_BASE = 'https://192.168.1.65:8441'
const DEFAULT_CAREER_API_BASE = 'https://192.168.1.65:8443/api'
const DEFAULT_AI_CHAT_API_BASE = 'https://192.168.1.65:9000/api'
const DEFAULT_DASHBOARD_URL = 'https://192.168.1.65:4003'
const DEFAULT_VPPO_APP_BASE = DEFAULT_DASHBOARD_URL

function normalizeAuthApiBase(input, fallback = DEFAULT_AUTH_API_BASE) {
  let raw = String(input || '').trim().replace(/\/+$/, '')
  if (!raw) return String(fallback).replace(/\/+$/, '')
  if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`
  try {
    return new URL(raw).origin
  } catch {
    return String(fallback).replace(/\/+$/, '')
  }
}

function parseAuthTokens(json) {
  const d = json?.data ?? json
  const accessToken = d?.accessToken || d?.access_token
  const refreshToken = d?.refreshToken || d?.refresh_token
  const xsrfToken = d?.xsrfToken || d?.xsrf_token
  if (!accessToken) return null
  return { accessToken, refreshToken, xsrfToken }
}

function extractLoginUser(json) {
  const d = json?.data ?? json
  return d?.user || d?.data?.user || json?.user || null
}
const CHAT_HISTORY_KEY = 'candidateChatHistory'
const PENDING_QUICK_ACTION_KEY = 'pendingQuickAction'
const TASK_DRAFT_KEY = 'candidateTaskDraft'

async function openSidePanelWithAction(action) {
  if (action) {
    await chrome.storage.local.set({ [PENDING_QUICK_ACTION_KEY]: action })
  }
  chrome.windows.getCurrent((win) => {
    if (win?.id) chrome.sidePanel.open({ windowId: win.id })
  })
}

let activeView = 'chat'

let mainSession = {
  linkedinStatus: '',
  lastSync: '',
  linkedinActiveDevice: null,
  careerApiBase: '',
  aiChatApiBase: '',
  dashboardUrl: DEFAULT_DASHBOARD_URL
}

/** Main backend serves routes under /api. VITE_API_URL is often only the origin; we append /api when missing. */
function normalizeVppoApiBase(input, fallbackBase) {
  const fallback = String(fallbackBase || '').trim().replace(/\/+$/, '')
  let raw = String(input || '').trim().replace(/\/+$/, '')
  if (!raw) return fallback
  if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`
  try {
    const u = new URL(raw)
    let path = u.pathname || '/'
    path = path.replace(/\/+$/, '') || '/'
    const lower = path.toLowerCase()
    if (path === '/' || path === '') {
      path = '/api'
    } else if (!lower.endsWith('/api')) {
      path = `${path}/api`
    }
    let out = `${u.origin}${path}`.replace(/\/+$/, '')
    while (/\/api\/api$/i.test(out)) out = out.replace(/\/api\/api$/i, '/api')
    return out || fallback
  } catch {
    return fallback
  }
}
/** Shown in popup scroll — local only, cheap to render */
const MAX_UI_MESSAGES = 40
/** Sent to backend-ai per request — keeps LLM fast */
const MAX_AGENT_MESSAGES = 12
/** Cap per bubble in chrome.storage.local */
const MAX_MESSAGE_CHARS = 8_000
/** Full JD from job pages — sent to tailor / ATS (not clipped for accuracy) */
const MAX_PAGE_JD_CHARS = 50_000

const SYSTEM_PROMPT =
  'You are Shree, the KareerGrowth career assistant. Use tools to fetch resumes, score ATS, tailor resumes, search jobs/connections, and fill forms — never say you lack access to user data. If the user sends only a greeting such as hi, hello, hey, yo, namaste, or similar, reply as a warm greeting: say Hi, I\'m Shree, use the provided candidate name when available, welcome them to KareerGrowth, then ask how you can assist with career growth, job searching, networking, or interview prep.'

/** One-click chat prompts — must trigger the matching agent tool. */
const QUICK_ACTIONS = [
  {
    id: 'add-tracker',
    label: 'Add to tracker',
    primary: true,
    directAddTracker: true
  },
  {
    id: 'ats',
    label: 'ATS score',
    primary: true,
    directAts: true,
    message:
      'Calculate my ATS score for the job posting on my current browser tab. Use the calculate_ats_score tool with the page job description.'
  },
  {
    id: 'resumes',
    label: 'My resumes',
    directResumes: true,
    message: 'Fetch and list my uploaded resumes with file names and skill counts. Use fetch_my_resumes.'
  },
  {
    id: 'tailor-download',
    label: 'AI Resume & Download',
    primary: true,
    directDownload: true,
    message:
      'Generate an AI-optimized resume file for the job on my current tab using generate_tailored_resume_download.'
  },
  {
    id: 'cover-letter',
    label: 'Cover letter',
    primary: true,
    directCoverLetter: true,
    message: 'Generate a cover letter for the job on my current tab using my primary resume.'
  },
  {
    id: 'fill',
    label: 'Fill form',
    directFill: true,
    message:
      'Fill the job application form on my current tab with my profile. Use fill_job_application_form with an empty args object.'
  },
  {
    id: 'jobs',
    label: 'LinkedIn Jobs',
    primary: true,
    directJobs: true,
    message:
      'Search LinkedIn jobs using my resume skills via search_linkedin_jobs_in_browser. Include apply links and how many were saved.'
  },
  {
    id: 'indeedJobs',
    label: 'Indeed Jobs',
    primary: true,
    directIndeedJobs: true,
    message:
      'Search Indeed jobs using my resume skills via search_indeed_jobs_in_browser. Include apply links and how many were saved.'
  },
  {
    id: 'naukriJobs',
    label: 'Naukri Jobs',
    primary: true,
    directNaukriJobs: true,
    message:
      'Search Naukri jobs using my resume skills via search_naukri_jobs_via_backend. Include apply links and how many were saved.'
  },
  {
    id: 'monsterJobs',
    label: 'Monster Jobs',
    primary: true,
    directMonsterJobs: true,
    message:
      'Search Monster jobs using my resume skills via search_monster_jobs_via_backend. Include apply links and how many were saved.'
  },
  {
    id: 'people',
    label: 'Find people',
    directPeople: true,
    message:
      'Search LinkedIn people to connect with via search_linkedin_people_in_browser. Include profile links and save count.'
  },
  {
    id: 'pageJobs',
    label: 'Jobs on page',
    directPageJobs: true,
    message:
      'Scan the current careers page for job links that match my resume skills using find_jobs_on_careers_page.'
  },
  {
    id: 'mock-interview',
    label: 'Mock Interview',
    primary: true,
    directMockInterview: true
  }
]

function parseClientToolUi(results) {
  if (!Array.isArray(results)) return null
  for (const r of results) {
    const data = typeof r.result === 'object' ? r.result : null
    if (!data?.success) continue
    if (r.name === 'search_linkedin_jobs_in_browser' && Array.isArray(data.jobs)) {
      return { type: 'jobs', data }
    }
    if (r.name === 'search_indeed_jobs_in_browser' && Array.isArray(data.jobs)) {
      return { type: 'indeedJobs', data }
    }
    if (r.name === 'search_naukri_jobs_in_browser' && Array.isArray(data.jobs)) {
      return { type: 'naukriJobs', data }
    }
    if (r.name === 'search_monster_jobs_via_backend' && Array.isArray(data.jobs)) {
      return { type: 'monsterJobs', data }
    }
    if (r.name === 'search_linkedin_people_in_browser' && Array.isArray(data.profiles)) {
      return { type: 'people', data }
    }
    if (r.name === 'find_jobs_on_careers_page' && Array.isArray(data.jobs)) {
      return { type: 'pageJobs', data }
    }
  }
  return null
}

function summaryTextForClientSearch(data, kind) {
  if (kind === 'jobs') {
    return (
      `Found ${data.totalFetched ?? 0} LinkedIn job(s). ` +
      `${data.savedToLibrary ?? 0} saved to your library. ` +
      `${data.savedToTracker ?? 0} saved to Application Tracker. ` +
      `${data.searchesRemaining ?? '—'} searches remaining today. ` +
      `Use the buttons below to apply on LinkedIn.`
    )
  }
  if (kind === 'indeedJobs') {
    return (
      `Found ${data.totalFetched ?? 0} Indeed job(s). ` +
      `${data.savedToLibrary ?? 0} saved to your library. ` +
      `${data.savedToTracker ?? 0} saved to Application Tracker. ` +
      `${data.searchesRemaining ?? '—'} searches remaining today. ` +
      `Use the buttons below to apply on Indeed.`
    )
  }
  if (kind === 'naukriJobs') {
    return (
      `Found ${data.totalFetched ?? 0} Naukri job(s). ` +
      `${data.savedToLibrary ?? 0} saved to your library. ` +
      `${data.savedToTracker ?? 0} saved to Application Tracker. ` +
      `${data.searchesRemaining ?? '—'} searches remaining today. ` +
      `Use the buttons below to apply on Naukri.`
    )
  }
  if (kind === 'monsterJobs') {
    return (
      `Found ${data.totalFetched ?? 0} Monster job(s). ` +
      `${data.savedToLibrary ?? 0} saved to your library. ` +
      `${data.savedToTracker ?? 0} saved to Application Tracker. ` +
      `${data.searchesRemaining ?? '—'} searches remaining today. ` +
      `Use the buttons below to apply on Monster.`
    )
  }
  if (data.warning) return data.warning
  return (
    `Found ${data.totalFetched ?? 0} people. ` +
    `${data.savedToLibrary ?? 0} added to Connections. ` +
    `${data.searchesRemaining ?? '—'} searches left · ` +
    `${data.connectionsRemaining ?? '—'} invites left today. ` +
    `AI invite notes generate automatically — review, then Connect.`
  )
}

function summaryTextForPageJobs(data) {
  return (
    `Found ${data.totalFetched ?? 0} role link(s) on this page` +
    (data.matchedCount != null ? ` (${data.matchedCount} match your skills).` : '.') +
    ' Open links below to apply.'
  )
}

if (typeof window !== 'undefined' && window.location.search.includes('context=sidepanel')) {
  document.body.classList.add('sidepanel')
}

async function getAiChatApiBase() {
  const { aiChatApiBase } = await chrome.storage.local.get('aiChatApiBase')
  const raw = (aiChatApiBase && String(aiChatApiBase).trim()) || DEFAULT_AI_CHAT_API_BASE
  return normalizeVppoApiBase(raw, DEFAULT_AI_CHAT_API_BASE)
}

function clipText(str, max = MAX_MESSAGE_CHARS) {
  const s = String(str || '')
  if (s.length <= max) return s
  return `${s.slice(0, max)}…`
}

function normalizeHistoryMessage(m) {
  if (!m || (!m.content && !m.ui)) return null
  const role = m.role === 'assistant' ? 'assistant' : 'user'
  const out = {
    role,
    content: clipText(m.content || ''),
    display: m.display ? clipText(m.display, 200) : undefined,
    t: m.t || Date.now()
  }
  if (m.ui?.type && m.ui.data) {
    out.ui = { type: m.ui.type, data: m.ui.data }
  }
  return out
}

async function loadChatHistory() {
  const { [CHAT_HISTORY_KEY]: raw } = await chrome.storage.local.get(CHAT_HISTORY_KEY)
  if (!Array.isArray(raw)) return []
  return raw
    .map(normalizeHistoryMessage)
    .filter(Boolean)
    .slice(-MAX_UI_MESSAGES)
}

async function saveChatHistory(messages) {
  const trimmed = messages
    .map(normalizeHistoryMessage)
    .filter(Boolean)
    .slice(-MAX_UI_MESSAGES)
  await chrome.storage.local.set({ [CHAT_HISTORY_KEY]: trimmed })
}

/** Only recent turns go to the agent — full UI history stays local */
function buildAgentMessages(history, candidateName = '') {
  const nameHint = String(candidateName || '').trim()
  const out = [
    {
      role: 'system',
      content: nameHint
        ? `${SYSTEM_PROMPT}\n\nCandidate name for personalization: ${nameHint}.`
        : SYSTEM_PROMPT
    }
  ]
  const recent = history.slice(-MAX_AGENT_MESSAGES)
  for (const m of recent) {
    const content = String(m.content || '').trim()
    if (!content) continue
    out.push({ role: m.role, content })
  }
  return out
}

function decodeJwtPayload(token) {
  try {
    const part = String(token || '').split('.')[1]
    if (!part) return null
    const normalized = part.replace(/-/g, '+').replace(/_/g, '/')
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=')
    return JSON.parse(decodeURIComponent(escape(atob(padded))))
  } catch {
    return null
  }
}

function firstUsableName(...values) {
  for (const value of values) {
    const raw = String(value || '').trim()
    if (!raw) continue
    const withoutEmailDomain = raw.includes('@') ? raw.split('@')[0] : raw
    const cleaned = withoutEmailDomain
      .replace(/[._-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
    if (!cleaned) continue
    return cleaned.split(' ')[0]
  }
  return ''
}

async function getCandidateGreetingName(authToken) {
  const stored = await chrome.storage.local.get(['candidateName', 'candidateUser'])
  const payload = decodeJwtPayload(authToken) || {}
  const storedUser = stored.candidateUser || {}
  let name = firstUsableName(
    stored.candidateName,
    storedUser.name,
    storedUser.fullName,
    storedUser.full_name,
    payload.name,
    payload.fullName,
    payload.full_name
  )
  if (name) return name

  try {
    const { res, data } = await careerApiFetch('/candidates/auth/me')
    if (res?.ok) {
      const user = data?.user || data?.data?.user || data?.data || data
      name = firstUsableName(user?.name, user?.fullName, user?.full_name, user?.candidateName)
      if (name) {
        await chrome.storage.local.set({ candidateName: name, candidateUser: user })
        return name
      }
    }
  } catch {
    /* ignore profile lookup fallback */
  }

  return ''
}

function slimPageContext(pageContext) {
  if (!pageContext || typeof pageContext !== 'object') return null
  const jd = pageContext.jobDescription
    ? clipText(pageContext.jobDescription, MAX_PAGE_JD_CHARS)
    : undefined
  return {
    url: pageContext.url ? String(pageContext.url).slice(0, 4000) : undefined,
    title: pageContext.title ? String(pageContext.title).slice(0, 500) : undefined,
    site: pageContext.site,
    isJobPage: pageContext.isJobPage,
    jobTitle: pageContext.jobTitle,
    company: pageContext.company,
    location: pageContext.location,
    jobDescription: jd
  }
}

function pageLooksLikeJob(pc) {
  if (!pc) return false
  if (pc.isJobPage === true) return true
  return Boolean(pc.jobDescription && String(pc.jobDescription).trim().length >= 80)
}

/** Map Mongo extractedJson → Resume Editor store shape (dashboard useResumeStore). */
function extractionToResumeData(extracted) {
  if (!extracted || extracted.extraction_status === 'empty') return null

  // Two formats come from the backend:
  // Format A (Groq/StreamingAI): { candidate_info: { full_name, email, phone, location, profession }, original_resume: { summary, skills[], tools[], experience[], education[], projects[] } }
  // Format B (legacy): { name, contact_details: { email, phone, location }, summary: { professional_title, summary_text }, experience: [{ company_name, job_title, achievements[] }], skills: [{ skill_name, skill_type }] }
  const isFormatA = !!(extracted.candidate_info || extracted.original_resume)
  const ci = extracted.candidate_info || {}
  const or = extracted.original_resume || {}

  const data = {
    name: isFormatA ? (ci.full_name || ci.name || extracted.name || '') : (extracted.name || ''),
    title: isFormatA ? (ci.profession || ci.job_title || '') : (extracted.summary?.professional_title || ''),
    email: isFormatA ? (ci.email || '') : (extracted.contact_details?.email || ''),
    phone: isFormatA ? (ci.phone || '') : (extracted.contact_details?.phone || ''),
    location: isFormatA ? (ci.location || '') : (extracted.contact_details?.location || ''),
    linkedin: ci.linkedin || extracted.contact_details?.linkedin || extracted.links?.linkedin || '',
    github: ci.github || extracted.contact_details?.github || extracted.links?.github || '',
    summary: isFormatA
      ? (typeof or.summary === 'string' ? or.summary : (extracted.summary || ''))
      : (extracted.summary?.summary_text || ''),
    experience: [],
    education: [],
    skills: [],
    projects: [],
    certifications: [],
    languages: [],
    hobbies: []
  }

  // Experience
  const expArr = isFormatA ? (or.experience || extracted.experience || []) : (extracted.experience || [])
  if (expArr.length) {
    data.experience = expArr.map((e, i) => ({
      id: `exp-${i}`,
      company: e.company || e.company_name || '',
      role: e.position || e.role || e.job_title || '',
      dates: [e.start_date, e.is_current ? 'Present' : e.end_date].filter(Boolean).join(' – '),
      location: e.location || '',
      description: e.description || '',
      bullets: Array.isArray(e.bullets) ? e.bullets.filter(Boolean)
        : Array.isArray(e.achievements) ? e.achievements.filter(Boolean) : []
    }))
  }

  // Education
  const eduArr = isFormatA ? (or.education || extracted.education || []) : (extracted.education || [])
  if (eduArr.length) {
    data.education = eduArr.map((e, i) => ({
      id: `edu-${i}`,
      degree: isFormatA
        ? [e.degree, e.field].filter(Boolean).join(' in ')
        : [e.degree, e.specialization].filter(Boolean).join(' in '),
      institution: e.institution || e.institution_name || '',
      year: e.graduation_date || [e.start_year, e.end_year].filter(Boolean).join(' – ') || '',
      grade: e.grade || ''
    }))
  }

  // Skills — Format A: string[] (and optional tools[]); Format B: { skill_name, skill_type }[]
  if (isFormatA) {
    const rawSkills = Array.isArray(or.skills) ? or.skills : []
    const rawTools = Array.isArray(or.tools) ? or.tools : []
    const combined = [...rawSkills, ...rawTools]
    data.skills = combined
      .map((s, i) => ({
        id: `sk-${i}`,
        name: typeof s === 'string' ? s : (s.skill_name || s.name || ''),
        type: (s.skill_type === 'soft' || s.type === 'soft') ? 'soft' : 'technical'
      }))
      .filter(s => s.name)
  } else if (extracted.skills?.length) {
    data.skills = extracted.skills
      .map((s, i) => ({
        id: `sk-${i}`,
        name: typeof s === 'string' ? s : (s.skill_name || ''),
        type: s.skill_type === 'soft' ? 'soft' : 'technical'
      }))
      .filter(s => s.name)
  }

  // Projects
  const projArr = isFormatA ? (or.projects || extracted.projects || []) : (extracted.projects || [])
  if (projArr.length) {
    data.projects = projArr.map((p, i) => ({
      id: `proj-${i}`,
      title: p.title || p.project_title || '',
      tech: Array.isArray(p.technologies) ? p.technologies.join(', ') : (p.technologies || p.tech || ''),
      description: p.description || '',
      link: p.project_link || p.link || ''
    }))
  }

  // Certifications (usually Format B)
  if (extracted.certificates?.length) {
    data.certifications = extracted.certificates.map((c, i) => ({
      id: `cert-${i}`,
      name: c.certificate_name || c.name || '',
      issuer: c.issuer || '',
      date: c.issued_date || c.date || ''
    }))
  }

  if (extracted.languages?.length) data.languages = extracted.languages.filter(Boolean)
  if (extracted.hobbies?.length) data.hobbies = extracted.hobbies.filter(Boolean)
  return data
}

function resumeDataToExtractedJson(data) {
  return {
    name: data.name || '',
    contact_details: {
      email: data.email || '',
      phone: data.phone || '',
      location: data.location || '',
      linkedin: data.linkedin || '',
      github: data.github || ''
    },
    summary: {
      professional_title: data.title || '',
      summary_text: data.summary || ''
    },
    experience: (data.experience || []).map((e) => ({
      company_name: e.company || '',
      job_title: e.role || '',
      start_date: e.dates ? (e.dates.split(' – ')[0] || e.dates) : '',
      end_date: e.dates ? (e.dates.split(' – ')[1] || '') : '',
      is_current: e.dates ? e.dates.includes('Present') : false,
      location: e.location || '',
      description: e.description || '',
      achievements: e.bullets || []
    })),
    education: (data.education || []).map((e) => ({
      degree: e.degree ? (e.degree.split(' in ')[0] || e.degree) : '',
      specialization: e.degree ? (e.degree.split(' in ')[1] || '') : '',
      institution_name: e.institution || '',
      start_year: e.year ? (e.year.split(' – ')[0] || e.year) : '',
      end_year: e.year ? (e.year.split(' – ')[1] || '') : '',
      grade: e.grade || ''
    })),
    skills: (data.skills || []).map((s) => ({
      skill_name: s.name || '',
      skill_type: s.type || 'technical'
    })),
    projects: (data.projects || []).map((p) => ({
      project_title: p.title || '',
      technologies: p.tech ? p.tech.split(',').map((x) => x.trim()) : [],
      description: p.description || '',
      project_link: p.link || ''
    })),
    certificates: (data.certifications || []).map((c) => ({
      certificate_name: c.name || '',
      issuer: c.issuer || '',
      date: c.date || ''
    })),
    languages: data.languages || [],
    hobbies: data.hobbies || []
  }
}

function applyOptimizeToResumeData(baseData, optimized) {
  const updated = JSON.parse(JSON.stringify(baseData))
  if (optimized.title) updated.title = optimized.title
  if (optimized.summary) updated.summary = optimized.summary
  if (optimized.skills && Array.isArray(optimized.skills)) {
    updated.skills = optimized.skills.map((s, idx) => ({
      id: s.id || `sk-${Date.now()}-${idx}`,
      name: s.name,
      type: s.type || 'technical'
    }))
  }
  if (optimized.education && Array.isArray(optimized.education)) {
    updated.education = updated.education.map((edu, idx) => {
      const matched =
        optimized.education.find((e) => String(e.id) === String(edu.id)) || optimized.education[idx]
      if (!matched) return edu
      return {
        ...edu,
        institution: matched.institution || edu.institution,
        degree: matched.degree || edu.degree,
        year: matched.year || edu.year,
        grade: matched.grade || edu.grade
      }
    })
  }
  if (optimized.experience && Array.isArray(optimized.experience)) {
    updated.experience = updated.experience.map((exp, idx) => {
      const matched =
        optimized.experience.find((e) => String(e.id) === String(exp.id)) || optimized.experience[idx]
      if (!matched) return exp
      return {
        ...exp,
        role: matched.role || exp.role,
        description: matched.description || exp.description,
        bullets: Array.isArray(matched.bullets) ? matched.bullets : exp.bullets
      }
    })
  }
  if (optimized.projects && Array.isArray(optimized.projects)) {
    updated.projects = updated.projects.map((proj, idx) => {
      const matched =
        optimized.projects.find((p) => String(p.id) === String(proj.id)) || optimized.projects[idx]
      if (!matched) return proj
      return {
        ...proj,
        title: matched.title || proj.title,
        tech: matched.tech || proj.tech,
        description: matched.description || proj.description
      }
    })
  }
  return updated
}

async function fetchPageContext() {
  const pageCtx = await chrome.runtime.sendMessage({ type: 'GET_ACTIVE_PAGE_CONTEXT' })
  return slimPageContext(pageCtx?.pageContext) || null
}

async function careerApiFetch(path, options = {}) {
  const ensure = await chrome.runtime.sendMessage({ type: 'ENSURE_PLATFORM_AUTH' })
  if (!ensure?.ok) {
    return {
      res: { ok: false, status: 401 },
      data: { success: false, message: ensure?.message || 'Sign in to the candidate portal first.' }
    }
  }
  const base = await getCareerApiBaseFromStorage()
  const post = async (token) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
      Authorization: `Bearer ${token}`
    }
    return fetch(`${base}${path}`, { ...options, headers })
  }
  const { authToken } = await chrome.storage.local.get('authToken')
  if (!authToken) {
    return {
      res: { ok: false, status: 401 },
      data: { success: false, message: 'Sign in to the candidate portal first.' }
    }
  }
  let res = await post(authToken)
  if (res.status === 401) {
    const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
    if (refreshed?.success) {
      const t2 = await chrome.storage.local.get('authToken')
      if (t2.authToken) res = await post(t2.authToken)
    }
    if (res.status === 401) {
      await handleUnauthorizedError()
    }
  }
  const data = await res.json().catch(() => ({}))
  return { res, data }
}

async function pushAssistantMessage(content, ui) {
  const history = await loadChatHistory()
  history.push({ role: 'assistant', content: clipText(content || ''), ui, t: Date.now() })
  await saveChatHistory(history)
  const chatScroll = document.getElementById('chatScroll')
  if (chatScroll && window.ChatUi) {
    chatScroll.innerHTML = ''
    for (const m of await loadChatHistory()) window.ChatUi.appendMessageBubble(m, chatScroll)
    chatScroll.scrollTop = chatScroll.scrollHeight
  } else if (footerHint && content) {
    footerHint.textContent = content
  }
}

function setAuthInlineMessage(message, { tone = 'error' } = {}) {
  const el = document.getElementById('authInlineMessage')
  if (!el) return
  const text = String(message || '').trim()
  el.textContent = text
  el.style.display = text ? 'block' : 'none'
  if (tone === 'success') {
    el.style.background = '#ecfdf5'
    el.style.color = '#065f46'
    el.style.borderColor = '#a7f3d0'
  } else {
    el.style.background = '#fef2f2'
    el.style.color = '#991b1b'
    el.style.borderColor = '#fecaca'
  }
}

async function notifyExtensionUser(message, ui) {
  const text = String(message || '').trim()
  if (!text) return
  const { authToken } = await chrome.storage.local.get('authToken')
  if (authToken && document.getElementById('chatScroll')) {
    await pushAssistantMessage(text, ui)
    return
  }
  setAuthInlineMessage(text)
}

function normalizePriority(value) {
  const v = String(value || '').toLowerCase()
  if (/\bhigh|urgent|important\b/.test(v)) return 'High'
  if (/\blow\b/.test(v)) return 'Low'
  return 'Medium'
}

function parseTaskDate(text) {
  const raw = String(text || '').toLowerCase()
  const iso = raw.match(/\b(20\d{2}-\d{2}-\d{2})\b/)
  if (iso) return iso[1]
  const dmy = raw.match(/\b(\d{1,2})[\/.-](\d{1,2})[\/.-](20\d{2})\b/)
  if (dmy) return `${dmy[3]}-${String(dmy[2]).padStart(2, '0')}-${String(dmy[1]).padStart(2, '0')}`
  const date = new Date()
  if (/\btoday\b/.test(raw)) return date.toISOString().slice(0, 10)
  if (/\btomorrow\b/.test(raw)) {
    date.setDate(date.getDate() + 1)
    return date.toISOString().slice(0, 10)
  }
  return ''
}

function parseTaskTitle(text) {
  const raw = String(text || '').trim()
  const quoted = raw.match(/["“']([^"”']{3,})["”']/)
  if (quoted) return quoted[1].trim()
  const after = raw.match(/\b(?:create|add|make)\s+(?:a\s+)?(?:new\s+)?task\s+(?:to\s+)?(.+?)(?:\s+(?:by|before|on|due)\b|$)/i)
  if (after) return after[1].replace(/^called\s+/i, '').trim()
  return ''
}

function wantsTaskCreate(text) {
  return /\b(create|add|make|new)\b/i.test(text) && /\b(task|todo|to-do|follow[- ]?up|reminder)\b/i.test(text)
}

function wantsPageTask(text) {
  return (
    /(add|save|create|make)\s+(this\s+)?(page|link|url|article|course|doc(ument)?|video|post)\s+(as\s+a?\s+)?(task|todo)/i.test(text) ||
    /add\s+(this|it)\s+to\s+(my\s+)?tasks?/i.test(text) ||
    /(save|bookmark)\s+this\s+as\s+(a\s+)?task/i.test(text) ||
    /task\s+(from|for)\s+this\s+page/i.test(text) ||
    /add\s+this\s+page\s+(to|as)\s+(my\s+)?tasks?/i.test(text)
  )
}

function wantsTaskList(text) {
  const lower = text.toLowerCase().trim()
  const hasTaskWord = /\b(tasks?|todos?|to-dos?|follow[- ]?ups?|reminders?)\b/.test(lower)
  const hasListIntent = /\b(show|list|what|get|fetch|all|my|today|tomorrow|pending|completed|done|overdue|due|remaining|incomplete|in progress|for the day|for tomorrow|this week)\b/.test(lower)
  const isQuestion = /\?$/.test(lower) || /^(what|show|list|get|fetch|any|are|is there|do i have)/.test(lower)
  return hasTaskWord && (hasListIntent || isQuestion)
}

function wantsTrackerJobs(text) {
  const lower = text.toLowerCase().trim()
  return (
    (/\b(tracker|application tracker|track)\b/.test(lower) && /\b(jobs?|roles?|applications?|status|list|counts?)\b/.test(lower)) ||
    lower.includes('tracker list') ||
    lower.includes('tracker counts') ||
    lower.includes('track list')
  )
}
function wantsDirectTrackerSearch(text) {
  const lower = text.toLowerCase().trim()
  const hasJob = /\b(jobs?|roles?|positions?|applications?)\b/.test(lower)
  const hasCompany = /\b(microsoft|google|amazon|meta|apple|netflix)\b/.test(lower)
  const hasTracker = /\b(tracker|track)\b/.test(lower)
  
  // If the query is generic like "what are the jobs in the tracker" or "are there jobs in the tracker" without a specific company name,
  // we do NOT treat it as a direct tracker search.
  const isGeneric = /^(what are|what|show|list|get|fetch|are there|is there|do i have) (the )?jobs?/i.test(lower) && !hasCompany;
  if (isGeneric) {
    return false;
  }
  
  return (hasJob && hasCompany) || (hasTracker && hasCompany) || (lower.includes('in the tracker') && hasCompany) || (lower.includes('in tracker') && hasCompany);
}
const extractSearchQuery = (text) => {
  let cleaned = text.replace(/cound u find any job regarding the/i, '')
  cleaned = cleaned.replace(/find any job regarding/i, '')
  cleaned = cleaned.replace(/is there any job regarding/i, '')
  cleaned = cleaned.replace(/any job regarding/i, '')
  cleaned = cleaned.replace(/regarding/i, '')
  cleaned = cleaned.replace(/job in/i, '')
  cleaned = cleaned.replace(/jobs in/i, '')
  cleaned = cleaned.replace(/job/i, '')
  cleaned = cleaned.replace(/jobs/i, '')
  cleaned = cleaned.replace(/location/i, '')
  cleaned = cleaned.replace(/india/i, '')
  cleaned = cleaned.replace(/in tracker/i, '')
  cleaned = cleaned.replace(/in the tracker/i, '')
  cleaned = cleaned.replace(/is it there/i, '')
  cleaned = cleaned.replace(/\?/g, '')
  cleaned = cleaned.trim()
  
  if (cleaned.includes(' ')) {
    cleaned = cleaned.split(' ')[0]
  }
  
  return cleaned || 'Microsoft'
}

function wantsCredits(text) {
  const lower = text.toLowerCase().trim()
  return /\b(credits?|usage|balance)\b/.test(lower) && /\b(what|show|my|how many)\b/.test(lower)
}

/** Extract API filter params from the user's task-query text */
function parseTaskFilters(text) {
  const lower = text.toLowerCase()
  const params = {}

  // Date
  if (/\btoday\b|\bfor the day\b/.test(lower)) {
    params.date = 'today'
  } else if (/\btomorrow\b/.test(lower)) {
    const d = new Date()
    d.setDate(d.getDate() + 1)
    params.date = d.toISOString().slice(0, 10)
  } else if (/\boverdue\b/.test(lower)) {
    params.overdue = '1'
  } else {
    // Explicit YYYY-MM-DD
    const iso = text.match(/\b(\d{4}-\d{2}-\d{2})\b/)
    if (iso) { params.date = iso[1] }
    // DD/MM/YYYY or DD-MM-YYYY
    const dmy = text.match(/\b(\d{1,2})[\/\-](\d{1,2})[\/\-](20\d{2})\b/)
    if (dmy && !params.date) {
      params.date = `${dmy[3]}-${String(dmy[2]).padStart(2, '0')}-${String(dmy[1]).padStart(2, '0')}`
    }
  }

  // Status — only when not already a date-specific query
  if (/\bnot completed\b|\bincomplete\b|\bpending\b|\bopen\b|\bremaining\b/.test(lower)) {
    params.exclude_completed = '1'
  } else if (/\bcompleted\b|\bdone\b|\bfinished\b/.test(lower)) {
    params.status = 'Completed'
  } else if (/\bin.?progress\b/.test(lower)) {
    params.status = 'In Progress'
  }

  return params
}

/** Human-readable description of the active filters */
function taskFilterLabel(filters) {
  if (filters.date === 'today') return ' for today'
  if (filters.date) return ` for ${filters.date}`
  if (filters.overdue === '1') return ' (overdue)'
  if (filters.exclude_completed === '1') return ' (not completed)'
  if (filters.status) return ` (${filters.status})`
  return ''
}

function wantsCredits(text) {
  return /\b(credit|credits|limit|usage|remaining|used)\b/i.test(text)
}

function wantsMockFromJob(text) {
  return /\b(mock|interview|assessment)\b/i.test(text) && /\b(start|begin|open|practice)\b/i.test(text)
}

const RESUME_TECH_KEYWORDS = [
  'JavaScript','TypeScript','Python','Java','Go','Rust','Ruby','PHP','Swift','Kotlin','Scala','C#','C++',
  'React','Next.js','Angular','Vue','Node.js','Django','Flask','Spring Boot','FastAPI','Laravel','Express',
  'SQL','MySQL','PostgreSQL','MongoDB','Redis','Elasticsearch','Kafka','RabbitMQ','DynamoDB','Cassandra',
  'AWS','GCP','Azure','Docker','Kubernetes','Terraform','CI/CD','GitHub Actions','Jenkins','GitLab',
  'GraphQL','REST','gRPC','HTML','CSS','Tailwind','Bootstrap','Git','Linux','Agile','Scrum',
  'Machine Learning','Deep Learning','TensorFlow','PyTorch','Pandas','NumPy','Scikit-learn',
  'Microservices','DevOps','Serverless','WebSocket','OAuth','JWT','OpenAI','LangChain'
]

function extractJdTechSkills(jdText) {
  if (!jdText) return []
  return RESUME_TECH_KEYWORDS.filter(k =>
    new RegExp(`\\b${k.replace(/[.+\-]/g, '\\$&')}\\b`, 'i').test(jdText)
  )
}

function extractResumeSkillNames(extractedJson) {
  if (!extractedJson) return []
  // Support both root-level skills and original_resume.skills (Format A)
  const rootSkills = extractedJson.skills || extractedJson.original_resume?.skills || []
  const toolSkills = extractedJson.original_resume?.tools || []
  const skills = [...(Array.isArray(rootSkills) ? rootSkills : []), ...(Array.isArray(toolSkills) ? toolSkills : [])]
  const named = skills.map(s => (typeof s === 'string' ? s : s.name || s.skill_name || s.skill || s.title || '')).filter(Boolean)
  const fullText = JSON.stringify(extractedJson)
  const fromText = RESUME_TECH_KEYWORDS.filter(k =>
    new RegExp(`\\b${k.replace(/[.+\-]/g, '\\$&')}\\b`, 'i').test(fullText)
  )
  return [...new Set([...named, ...fromText])]
}

function findMissingSkills(jdSkills, resumeSkills) {
  const resumeLower = resumeSkills.map(s => s.toLowerCase())
  return jdSkills
    .filter(skill => {
      const sl = skill.toLowerCase()
      return !resumeLower.some(rs => rs.includes(sl) || sl.includes(rs))
    })
    .slice(0, 8)
}

function extractResumeJobTitles(extractedJson) {
  if (!extractedJson) return []
  const exp = extractedJson.experience || extractedJson.original_resume?.experience || []
  return (Array.isArray(exp) ? exp : [])
    .map((e) => String(e?.role || e?.job_title || e?.title || '').trim())
    .filter(Boolean)
}

function extractJdFocusPhrases(jdText) {
  const text = String(jdText || '')
  const phrases = []
  const patterns = [
    /(?:responsible for|experience with|proficiency in|knowledge of|expertise in)\s+([^.\n;]{8,80})/gi,
    /(?:must have|required:?|looking for)\s+([^.\n;]{8,80})/gi,
  ]
  for (const re of patterns) {
    let m
    while ((m = re.exec(text)) && phrases.length < 6) {
      const p = String(m[1] || '').replace(/\s+/g, ' ').trim()
      if (p.length >= 8) phrases.push(p)
    }
  }
  return [...new Set(phrases)].slice(0, 4)
}

function extractJdExperienceRequirement(jdText) {
  const text = String(jdText || '')
  const patterns = [
    /(\d+)\s*\+\s*(?:years?|yrs?)/i,
    /(\d+)\s*(?:[-–to]+)\s*(\d+)\s*(?:years?|yrs?)/i,
    /(?:minimum|at least|min\.?)\s*(\d+)\s*(?:years?|yrs?)/i,
    /(\d+)\s*(?:years?|yrs?)\s+(?:of\s+)?(?:experience|exp)/i,
  ]
  for (const re of patterns) {
    const m = text.match(re)
    if (m) {
      if (m[2]) return `${m[1]}–${m[2]} years`
      return `${m[1]}+ years`
    }
  }
  return ''
}

function extractResumeExperienceSummary(extractedJson) {
  if (!extractedJson) return ''
  const direct =
    extractedJson.totalExperience ||
    extractedJson.total_experience ||
    extractedJson.original_resume?.totalExperience ||
    extractedJson.candidate_info?.total_experience
  if (direct) return String(direct).trim()

  const exp = extractedJson.experience || extractedJson.original_resume?.experience || []
  if (!Array.isArray(exp) || !exp.length) return ''

  let totalMonths = 0
  for (const row of exp) {
    const dur = String(row?.duration || row?.dates || '').trim()
    const range = dur.match(/(\d+)\s*(?:[-–to]+)\s*(\d+)/)
    const plus = dur.match(/(\d+)\s*\+/)
    const single = dur.match(/(\d+)\s*(?:years?|yrs?)/i)
    if (range) totalMonths += Math.max(Number(range[2]), Number(range[1])) * 12
    else if (plus) totalMonths += Number(plus[1]) * 12
    else if (single) totalMonths += Number(single[1]) * 12
    else totalMonths += 12
  }
  const years = Math.max(1, Math.round(totalMonths / 12))
  return `${years} years (from resume roles)`
}

function parseExperienceYearsMin(text) {
  const s = String(text || '')
  const range = s.match(/(\d+)\s*(?:[-–to]+)\s*(\d+)/)
  if (range) return Number(range[1])
  const plus = s.match(/(\d+)\s*\+/)
  if (plus) return Number(plus[1])
  const single = s.match(/(\d+)\s*(?:years?|yrs?)/i)
  if (single) return Number(single[1])
  return 0
}

function buildTailorGapQuestions({ pageContext, resumeContext, skillsData }) {
  const jdText = String(pageContext?.jobDescription || '')
  const jobTitle = String(pageContext?.jobTitle || 'this role').trim()
  const resumeSkills = extractResumeSkillNames(resumeContext)
  const answers = skillsData?.answers || []

  // Skills + "where used" are collected in the quick check — do NOT repeat here.
  const confirmedYes = answers.filter((a) => a.hasIt).map((a) => a.skill)

  const questions = []

  const expGapNote = String(skillsData?.experienceGapNote || '').trim()
  if (!expGapNote) {
    const jdExp = extractJdExperienceRequirement(jdText)
    const resumeExp = extractResumeExperienceSummary(resumeContext)
    if (jdExp && resumeExp) {
      questions.push(
        `Experience check: the JD asks for **${jdExp}** and your resume shows **${resumeExp}**. Describe your total relevant experience for this role (domains, seniority, team size).`
      )
    }
  }

  const focusPhrases = extractJdFocusPhrases(jdText)
  for (const phrase of focusPhrases) {
    if (questions.length >= 5) break
    const covered = resumeSkills.some((s) => phrase.toLowerCase().includes(s.toLowerCase()))
    if (!covered) {
      questions.push(
        `The JD emphasizes: "${phrase}". Give one concrete example from your work (company, scope, result) — not skills already confirmed above.`
      )
    }
  }

  if (questions.length < 5) {
    questions.push(
      `For **${jobTitle}**, what is your strongest achievement with measurable impact (%, time saved, revenue, users, etc.)?`
    )
  }

  if (questions.length < 5) {
    questions.push(
      `Which project or role best proves you can deliver what this JD describes? Summarize problem → your action → outcome.`
    )
  }

  if (questions.length < 5 && confirmedYes.length) {
    questions.push(
      `Beyond the skills you confirmed (${confirmedYes.slice(0, 3).join(', ')}), what leadership, collaboration, or client-facing work should we highlight for this role?`
    )
  }

  if (questions.length < 4) {
    questions.push(
      `Is there any certification, domain knowledge, or industry context (e.g. finance, healthcare) we should add for this application?`
    )
  }

  return [...new Set(questions)].slice(0, 5)
}

function formatCreditsText(data, text) {
  const lim = data?.limits || {}
  const usage = data?.usage || {}
  const remaining = data?.remaining || {}
  const lower = String(text || '').toLowerCase()
  const rows = []
  const add = (label, used, limit, rem, period) => rows.push(`${label}: ${used}/${limit} used ${period}${rem != null ? `, ${rem} remaining` : ''}.`)
  if (/cover/.test(lower)) {
    add('Cover letters', usage.usedCoverLetter ?? 0, lim.coverLetterPerDay ?? 0, remaining.coverLetterRemaining, 'today')
  } else if (/mock|interview|assessment/.test(lower)) {
    add('Mock interviews', usage.usedMockInterview ?? 0, lim.mockInterviewPerDay ?? 0, remaining.mockInterviewRemaining, 'today')
  } else if (/resume/.test(lower)) {
    add('Resume uploads', usage.usedResume ?? 0, lim.resumePerMonth ?? 0, remaining.resumeRemaining, 'this month')
  } else {
    add('Cover letters', usage.usedCoverLetter ?? 0, lim.coverLetterPerDay ?? 0, remaining.coverLetterRemaining, 'today')
    add('Mock interviews', usage.usedMockInterview ?? 0, lim.mockInterviewPerDay ?? 0, remaining.mockInterviewRemaining, 'today')
    add('LinkedIn jobs', usage.usedLinkedinJobs ?? 0, lim.dailyLinkedinJobs ?? 0, remaining.linkedinJobsRemaining, 'today')
    add('Indeed jobs', usage.usedIndeedJobs ?? 0, lim.dailyIndeedJobs ?? 0, remaining.indeedJobsRemaining, 'today')
    add('Naukri jobs', usage.usedNaukriJobs ?? 0, lim.dailyNaukriJobs ?? lim.dailyIndeedJobs ?? 0, remaining.naukriJobsRemaining, 'today')
    add('Monster jobs', usage.usedMonsterJobs ?? 0, lim.dailyMonsterJobs ?? lim.dailyNaukriJobs ?? lim.dailyIndeedJobs ?? 0, remaining.monsterJobsRemaining, 'today')
    add('Connections', usage.usedConnections ?? 0, lim.dailyConnections ?? 0, remaining.connectionsRemaining, 'today')
    add('Resume uploads', usage.usedResume ?? 0, lim.resumePerMonth ?? 0, remaining.resumeRemaining, 'this month')
  }
  return rows.join('\n')
}

async function runAddToTrackerDirect() {
  const pageContext = (await fetchPageContext()) || {}
  let tab = null
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true })
    tab = tabs[0] || null
  } catch {
    /* ignore */
  }
  const tabUrl =
    tab?.url && /^https?:\/\//i.test(tab.url) && !/^(chrome|edge|about|chrome-extension):/i.test(tab.url)
      ? tab.url
      : ''
  const sourceUrl = String(pageContext.url || tabUrl || '').trim()
  if (!sourceUrl) {
    await pushAssistantMessage('Open a job posting page in your browser tab first, then try Add to tracker.')
    return
  }

  let title = String(pageContext.jobTitle || pageContext.title || '').trim()
  let company = String(pageContext.company || '').trim()
  if ((!title || !company) && tab?.title) {
    const parts = tab.title.split(/[|\-–—·]/).map((s) => s.trim()).filter(Boolean)
    if (!title && parts[0]) title = parts[0]
    if (!company && parts.length > 1) company = parts[parts.length - 1]
  }
  if (!title && !company) {
    await pushAssistantMessage('Could not detect job title or company on this page.')
    return
  }

  try {
    const { res, data } = await careerApiFetch('/candidates/tracker', {
      method: 'POST',
      body: JSON.stringify({
        sourceUrl,
        title: title || 'Untitled role',
        company: company || '',
        location: pageContext.location || '',
        description: pageContext.jobDescription || '',
        source: 'extension'
      })
    })
    if (data?.success) {
      await pushAssistantMessage(data.duplicate ? 'Present already in your tracker.' : 'Added to tracker.', {
        type: 'status',
        data: {
          title: data.duplicate ? 'Present already' : 'Added',
          message: `${title || 'This role'}${company ? ` at ${company}` : ''}`,
          tone: data.duplicate ? 'warn' : 'success'
        }
      })
      return
    }
    const msg =
      data?.message ||
      data?.error ||
      (res.status === 403 ? 'Session expired — sign in again in the extension.' : '') ||
      `Could not add to tracker (HTTP ${res.status || 'error'}).`
    await pushAssistantMessage(msg)
  } catch (e) {
    await pushAssistantMessage(e?.message || 'Could not add to tracker.')
  }
}

async function downloadCandidateResumeFile(resume) {
  const { authToken } = await chrome.storage.local.get('authToken')
  if (!authToken) {
    await pushAssistantMessage('Not signed in.')
    return
  }
  const careerBase = normalizeVppoApiBase(
    mainSession.careerApiBase || (await chrome.storage.local.get('careerApiBase')).careerApiBase,
    DEFAULT_CAREER_API_BASE
  )
  let url = String(resume?.fileUrl || '').trim()
  if (!url && resume?.id) {
    url = `${careerBase}/candidates/profile/resume/${resume.id}/view`
  }
  if (!url) {
    await pushAssistantMessage('No download URL for this resume.')
    return
  }
  if (url.startsWith('/')) url = `${careerBase.replace(/\/api\/?$/i, '')}${url}`
  if (!/^https?:\/\//i.test(url)) {
    url = `${careerBase.replace(/\/api\/?$/i, '')}/${url.replace(/^\/+/, '')}`
  }

  let res = await fetch(url, { headers: { Authorization: `Bearer ${authToken}` } })
  if (res.status === 401) {
    const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
    if (refreshed?.success) {
      const stored = await chrome.storage.local.get('authToken')
      if (stored.authToken) {
        res = await fetch(url, { headers: { Authorization: `Bearer ${stored.authToken}` } })
      }
    }
    if (res.status === 401) {
      await handleUnauthorizedError()
    }
  }
  if (!res.ok) {
    await pushAssistantMessage(`Could not download resume (${res.status}).`)
    return
  }
  const blob = await res.blob()
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = resume.fileName || 'resume.pdf'
  a.click()
  URL.revokeObjectURL(a.href)
}

async function downloadTailoredResumeFile(aiBase, downloadToken, fileName, authToken) {
  const res = await fetch(`${aiBase}/ai/tools/tailored-resume-download/${downloadToken}`, {
    headers: { Authorization: `Bearer ${authToken}` }
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.message || `Download failed (${res.status})`)
  }
  const contentType = res.headers.get('content-type') || ''
  const isPdf = contentType.includes('application/pdf') || (fileName || '').endsWith('.pdf')
  const arrayBuffer = await res.arrayBuffer()
  const blob = new Blob([arrayBuffer], { type: isPdf ? 'application/pdf' : 'text/html;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = fileName || 'Resume-Tailored.pdf'
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

function setLoggedInChrome(loggedIn) {
  document.getElementById('appHeader')?.toggleAttribute('hidden', !loggedIn)
  document.getElementById('headerProfileBtn')?.toggleAttribute('hidden', !loggedIn)
  document.getElementById('headerSyncBtn')?.toggleAttribute('hidden', !loggedIn)
  document.getElementById('headerNewChatBtn')?.toggleAttribute('hidden', !loggedIn)
  
  const footerHint = document.getElementById('footerHint')
  if (footerHint) {
    footerHint.textContent = `KareerGrowth v${EXTENSION_VERSION}`
  }
  document.getElementById('appFooter')?.classList.toggle('hidden', false)
  
  const isSp = document.body.classList.contains('sidepanel')
  if (isSp) {
    document.body.style.minHeight = '100vh'
    document.body.style.height = '100vh'
  } else {
    const height = loggedIn ? '500px' : '370px'
    document.body.style.minHeight = height
    document.body.style.height = height
  }
}

async function handleUnauthorizedError() {
  await chrome.storage.local.remove(['authToken', 'refreshToken', 'xsrfToken'])
  await render()
}

function updateHeaderSyncButton(linkedinStatus) {
  const btn = document.getElementById('headerSyncBtn')
  if (!btn) return
  btn.classList.remove('connected', 'disconnected')
  if (linkedinStatus === 'connected') {
    btn.classList.add('connected')
    btn.title = 'LinkedIn connected — click to sync'
  } else if (linkedinStatus === 'disconnected_other_device') {
    btn.classList.add('disconnected')
    btn.title = 'LinkedIn synced on another device — click to switch'
  } else {
    btn.classList.add('disconnected')
    btn.title =
      linkedinStatus === 'not_logged_in'
        ? 'Log in on LinkedIn, then sync'
        : 'LinkedIn disconnected — click to sync'
  }
}

function linkedinBadgeHtml(status) {
  if (status === 'connected') return '<span id="liStatusBadge" class="badge ok">LinkedIn OK</span>'
  if (status === 'disconnected_other_device') {
    return '<span id="liStatusBadge" class="badge warn" title="Synced on another device">Other device</span>'
  }
  if (status === 'not_logged_in') {
    return '<span id="liStatusBadge" class="badge warn li-login-badge" style="cursor:pointer" title="Log in on linkedin.com">Log in</span>'
  }
  return '<span id="liStatusBadge" class="badge err">LinkedIn</span>'
}

function deviceSupersededBannerHtml(activeDevice) {
  const label = activeDevice?.platformLabel || 'another device'
  const when = formatDeviceSyncTime(activeDevice?.lastSyncAt)
  return `
    <div class="device-superseded-banner" id="deviceSupersededBanner">
      LinkedIn sync is active on <strong>${String(label).replace(/</g, '&lt;')}</strong>
      ${when ? `(last synced ${String(when).replace(/</g, '&lt;')})` : ''}.
      <button type="button" id="deviceTakeoverBtn">Sync on this device</button>
    </div>
  `
}

async function openLinkedInLoginPage() {
  await chrome.tabs.create({ url: 'https://www.linkedin.com/login', active: true })
}

function bindProfilerLoginBadges() {
  document.getElementById('liStatusBadge')?.addEventListener('click', () => {
    if (mainSession.linkedinStatus === 'not_logged_in') void openLinkedInLoginPage()
  })
}

async function render() {
  showLoadingContent()
  let loggedIn = false
  try {
    const data = await sendRuntimeMessage({ type: 'GET_STATUS' })
    if (!data || typeof data !== 'object') {
      throw new Error('Could not read extension status.')
    }

    const { linkedinStatus, lastSync, authToken, careerApiBase, aiChatApiBase, linkedinActiveDevice } = data
    const stored = await chrome.storage.local.get(['dashboardUrl'])
    const contentEl = getContentEl()

    if (!authToken) {
      activeView = 'login'
      setLoggedInChrome(false)
      contentEl?.classList.add('auth-page-active')
      await renderLogin(careerApiBase, aiChatApiBase)
      return
    }

    loggedIn = true
    contentEl?.classList.remove('auth-page-active')

    setLoggedInChrome(true)
    mainSession = {
      linkedinStatus: linkedinStatus || '',
      lastSync: lastSync || '',
      linkedinActiveDevice: linkedinActiveDevice || null,
      careerApiBase: careerApiBase || DEFAULT_CAREER_API_BASE,
      aiChatApiBase: aiChatApiBase || DEFAULT_AI_CHAT_API_BASE,
      dashboardUrl: stored.dashboardUrl || DEFAULT_DASHBOARD_URL
    }
    updateHeaderSyncButton(linkedinStatus)

    if (activeView === 'profile') {
      await renderProfile()
      return
    }
    activeView = 'chat'
    renderMain()
  } catch (err) {
    console.error('[KareerGrowth popup]', err)
    showErrorContent(err?.message || 'Failed to load extension.', { keepHeader: loggedIn })
  }
}

async function renderLogin(savedCareerBase, savedAiBase) {
  const el = getContentEl()
  if (!el) return
  const careerHint = normalizeVppoApiBase(savedCareerBase, DEFAULT_CAREER_API_BASE)
  const aiHint = normalizeVppoApiBase(savedAiBase, DEFAULT_AI_CHAT_API_BASE)
  const careerOrigin = careerHint.replace(/\/api\/?$/i, '')
  const aiOrigin = aiHint.replace(/\/api\/?$/i, '')
  const stored = await chrome.storage.local.get(['dashboardUrl', 'authApiBase', 'rememberedIdentifier', 'authFlashMessage'])
  const rawAuthBase = stored.authApiBase
  const authOrigin = normalizeAuthApiBase(rawAuthBase, DEFAULT_AUTH_API_BASE)
  const dashboardHint = stored.dashboardUrl || DEFAULT_DASHBOARD_URL
  const rememberedIdentifier = stored.rememberedIdentifier || ''

  el.innerHTML = `
    <div class="auth-wrap" style="padding: 10px 24px 10px;">
      <div style="text-align: center; margin-bottom: 16px; margin-top: 6px;">
        <h2 style="font-size: 22px; font-weight: 800; color: var(--vp-text); margin-bottom: 2px; letter-spacing: -0.02em;">KareerGrowth</h2>
      </div>
      
      <label class="field-label" for="identifier">Email or mobile</label>
      <input class="login-input" type="text" id="identifier" placeholder="you@example.com" autocomplete="username" value="${rememberedIdentifier.replace(/"/g, '&quot;')}" />
      
      <label class="field-label" for="password">Password</label>
      <div style="position: relative; margin-bottom: 12px;">
        <input class="login-input" type="password" id="password" placeholder="Password" autocomplete="current-password" style="padding-right: 40px; margin-bottom: 0;" />
        <button type="button" id="togglePasswordBtn" style="position: absolute; right: 8px; top: 50%; transform: translateY(-50%); background: none; border: none; color: var(--vp-dim); cursor: pointer; padding: 6px; display: flex; align-items: center; justify-content: center; z-index: 10;">
          <svg id="eyeIcon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/>
            <circle cx="12" cy="12" r="3"/>
          </svg>
        </button>
      </div>

      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; font-size: 12px;">
        <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; color: var(--vp-muted); font-weight: 500; user-select: none;">
          <input type="checkbox" id="rememberMe" ${rememberedIdentifier ? 'checked' : ''} style="width: 15px; height: 15px; border-radius: 4px; border: 1px solid var(--vp-border); cursor: pointer; accent-color: var(--vp-blue);" />
          Remember me
        </label>
        <button type="button" class="link-btn" id="forgotPasswordBtn" style="font-size: 12px; font-weight: 600; text-decoration: none;">Forgot password?</button>
      </div>

      <div id="authInlineMessage" style="display:none;margin-bottom:12px;padding:10px 12px;border-radius:8px;font-size:12px;line-height:1.45;background:#fef2f2;color:#991b1b;border:1px solid #fecaca;"></div>
      <button class="btn btn-primary" id="loginBtn" style="display:flex;align-items:center;justify-content:center;gap:6px;">Sign in</button>
      <button type="button" class="link-btn" id="toggleServerLogin" style="display:block;margin:12px auto 0">Advanced: server URLs</button>
      <div id="serverLoginFields" style="display:none;margin-top:10px">
        <label class="field-label">Auth API (SuperadminBackend)</label>
        <input class="login-input" type="text" id="apiBaseAuth" value="${String(authOrigin).replace(/"/g, '&quot;')}" placeholder="https://192.168.1.65:8441" />
        <label class="field-label">Career API (CandidateBackend)</label>
        <input class="login-input" type="text" id="apiBaseCareer" value="${String(careerOrigin).replace(/"/g, '&quot;')}" placeholder="https://192.168.1.65:8443/api" />
        <label class="field-label">AI API (StreamingAi)</label>
        <input class="login-input" type="text" id="apiBaseAi" value="${String(aiOrigin).replace(/"/g, '&quot;')}" placeholder="https://192.168.1.65:9000/api" />
        <label class="field-label">Candidate dashboard</label>
        <input class="login-input" type="text" id="dashboardUrlLogin" value="${String(dashboardHint).replace(/"/g, '&quot;')}" placeholder="https://192.168.1.65:4003" />
      </div>
    </div>
  `

  if (stored.authFlashMessage) {
    setAuthInlineMessage(stored.authFlashMessage, { tone: 'success' })
    await chrome.storage.local.remove('authFlashMessage')
  }

  document.getElementById('toggleServerLogin')?.addEventListener('click', () => {
    const el = document.getElementById('serverLoginFields')
    if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none'
  })

  // Password visibility toggle
  const passwordInput = document.getElementById('password')
  const togglePasswordBtn = document.getElementById('togglePasswordBtn')
  const eyeIcon = document.getElementById('eyeIcon')

  togglePasswordBtn?.addEventListener('click', () => {
    const isPrivate = passwordInput.type === 'password'
    passwordInput.type = isPrivate ? 'text' : 'password'
    eyeIcon.innerHTML = isPrivate
      ? `<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.52 13.52 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/>`
      : `<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>`
  })

  // Forgot password click trigger
  document.getElementById('forgotPasswordBtn')?.addEventListener('click', () => {
    const authApi = normalizeAuthApiBase(
      document.getElementById('apiBaseAuth')?.value?.trim() || DEFAULT_AUTH_API_BASE,
      DEFAULT_AUTH_API_BASE
    )
    renderForgotPassword(authApi)
  })

  document.getElementById('loginBtn').addEventListener('click', async () => {
    const loginBtn = document.getElementById('loginBtn')
    const identifier = document.getElementById('identifier').value.trim()
    const password = document.getElementById('password').value
    const authApi = normalizeAuthApiBase(
      document.getElementById('apiBaseAuth')?.value?.trim() || DEFAULT_AUTH_API_BASE,
      DEFAULT_AUTH_API_BASE
    )
    const careerApi = normalizeVppoApiBase(
      document.getElementById('apiBaseCareer')?.value?.trim() || DEFAULT_CAREER_API_BASE,
      DEFAULT_CAREER_API_BASE
    )
    const aiApi = normalizeVppoApiBase(
      document.getElementById('apiBaseAi')?.value?.trim() || DEFAULT_AI_CHAT_API_BASE,
      DEFAULT_AI_CHAT_API_BASE
    )
    const dashboardUrl =
      document.getElementById('dashboardUrlLogin')?.value?.trim() || DEFAULT_DASHBOARD_URL

    if (!identifier || !password) {
      setAuthInlineMessage('Enter identifier and password.')
      return
    }

    const setLoading = (loading) => {
      if (!loginBtn) return
      loginBtn.disabled = loading
      loginBtn.innerHTML = loading
        ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="animation:spin 0.8s linear infinite;flex-shrink:0"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>Signing in…`
        : 'Sign in'
    }
    setLoading(true)

    await chrome.storage.local.set({
      authApiBase: authApi,
      careerApiBase: careerApi,
      aiChatApiBase: aiApi,
      dashboardUrl,
    })

    const emailOrPhone = identifier.includes('@') ? identifier.toLowerCase() : identifier

    // Process rememberMe checkbox state
    const rememberMeChecked = document.getElementById('rememberMe')?.checked
    if (rememberMeChecked) {
      await chrome.storage.local.set({ rememberedIdentifier: emailOrPhone })
    } else {
      await chrome.storage.local.remove('rememberedIdentifier')
    }

    const loginUrl = `${authApi}/auth-session/candidate/login`
    let res
    let data = {}
    let isCandidateLoginSuccessful = false

    try {
      res = await fetch(loginUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ emailOrPhone, password }),
      })
      const rawText = await res.text()
      try {
        data = rawText ? JSON.parse(rawText) : {}
      } catch {
        data = { message: rawText ? rawText.slice(0, 240) : `HTTP ${res.status}` }
      }
      
      const tokens = parseAuthTokens(data)
      if (res.ok && tokens?.accessToken) {
        isCandidateLoginSuccessful = true
      }
    } catch (e) {
      console.warn('Candidate login failed or encountered error', e)
    }

    // Fallback strategy: If candidate login failed, try standard/admin login endpoint
    if (!isCandidateLoginSuccessful) {
      const adminLoginUrl = `${authApi}/auth-session/login`
      try {
        res = await fetch(adminLoginUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ emailOrPhone, password }),
        })
        const rawText = await res.text()
        try {
          data = rawText ? JSON.parse(rawText) : {}
        } catch {
          data = { message: rawText ? rawText.slice(0, 240) : `HTTP ${res.status}` }
        }
      } catch (e) {
        setLoading(false)
        setAuthInlineMessage(
          `Network error calling SuperadminBackend: ${e.message}. Check the Auth API URL (SuperadminBackend) is running.`
        )
        return
      }
    }

    const tokens = parseAuthTokens(data)
    if (res.ok && tokens?.accessToken) {
      const loginUser = extractLoginUser(data)
      const loginName = firstUsableName(
        loginUser?.name,
        loginUser?.fullName,
        loginUser?.full_name,
        loginUser?.candidateName
      )
      await chrome.storage.local.set({
        refreshToken: tokens.refreshToken,
        xsrfToken: tokens.xsrfToken,
        ...(loginUser ? { candidateUser: loginUser } : {}),
        ...(loginName ? { candidateName: loginName } : {}),
      })
      await chrome.runtime.sendMessage({
        type: 'SET_AUTH_TOKEN',
        token: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        xsrfToken: tokens.xsrfToken,
      })
      render()
      return
    }

    setLoading(false)
    const serverMsg =
      data.message ||
      data.error ||
      (res.status === 0 ? 'No response (often wrong URL or server down).' : `HTTP ${res.status}`)

    let tip = ''
    if (res.status === 404) {
      tip =
        '\n\nTip: Auth API must be SuperadminBackend (e.g. https://192.168.1.56:8441), not the candidate Vite app.'
    } else if (res.status === 403 && String(serverMsg).toLowerCase().includes('csrf')) {
      tip = '\n\nTip: Session expired — sign out and sign in again.'
    } else if (res.status === 403) {
      tip =
        '\n\nTip: If this is about subscription or account status, resolve it in the candidate dashboard first.'
    }

    setAuthInlineMessage(`${serverMsg}${tip}`.replace(/\n\n/g, ' '))
  })
}

function renderForgotPassword(authApi) {
  const contentEl = document.getElementById('content')
  contentEl.innerHTML = `
    <div class="auth-wrap" style="padding: 10px 24px 10px;">
      <button type="button" class="profile-back" id="backToLoginBtn" style="font-size: 12px; margin-bottom: 16px; display: inline-flex; align-items: center; gap: 4px; background: none; border: none; color: var(--vp-blue); cursor: pointer; font-weight: 600;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
        Back to sign in
      </button>
      
      <div style="text-align: center; margin-bottom: 20px;">
        <h2 style="font-size: 20px; font-weight: 800; color: var(--vp-text); margin-bottom: 4px; letter-spacing: -0.02em;" id="resetTitle">Reset Password</h2>
        <p style="font-size: 12px; color: var(--vp-muted); line-height: 1.45;" id="resetSubtitle">Enter your email or phone to receive a verification code.</p>
      </div>

      <div id="authInlineMessage" style="display:none;margin-bottom:12px;padding:10px 12px;border-radius:8px;font-size:12px;line-height:1.45;background:#fef2f2;color:#991b1b;border:1px solid #fecaca;"></div>

      <div id="resetStep1">
        <label class="field-label" for="resetIdentifier">Email or mobile</label>
        <input class="login-input" type="text" id="resetIdentifier" placeholder="you@example.com" style="margin-bottom: 16px;" />
        <button class="btn btn-primary" id="sendResetCodeBtn">Send Code</button>
      </div>

      <div id="resetStep2" style="display: none;">
        <label class="field-label" for="resetOtp">Verification Code</label>
        <input class="login-input" type="text" id="resetOtp" placeholder="Enter 6-digit code" style="margin-bottom: 16px;" />
        <button class="btn btn-primary" id="verifyResetOtpBtn">Verify Code</button>
        <button type="button" id="resendResetOtpBtn" style="width:100%; text-align:center; font-size:12px; font-weight:600; color:var(--vp-muted); background:none; border:none; cursor:pointer; margin-top:12px; text-decoration:underline;">Resend Code</button>
      </div>

      <div id="resetStep3" style="display: none;">
        <label class="field-label" for="resetNewPassword">New Password</label>
        <div style="position: relative; margin-bottom: 12px;">
          <input class="login-input" type="password" id="resetNewPassword" placeholder="Minimum 6 characters" style="padding-right: 40px; margin-bottom: 0;" />
          <button type="button" id="toggleResetPasswordBtn" style="position: absolute; right: 8px; top: 50%; transform: translateY(-50%); background: none; border: none; color: var(--vp-dim); cursor: pointer; padding: 6px; display: flex; align-items: center; justify-content: center; z-index: 10;">
            <svg id="eyeIconReset" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/>
              <circle cx="12" cy="12" r="3"/>
            </svg>
          </button>
        </div>

        <label class="field-label" for="resetConfirmPassword">Confirm Password</label>
        <input class="login-input" type="password" id="resetConfirmPassword" placeholder="Repeat new password" style="margin-bottom: 16px;" />
        
        <button class="btn btn-primary" id="submitResetBtn">Reset Password</button>
      </div>
    </div>
  `

  document.getElementById('backToLoginBtn').addEventListener('click', () => {
    render()
  })

  const resetIdentifierInput = document.getElementById('resetIdentifier')
  const resetOtpInput = document.getElementById('resetOtp')
  const resetNewPasswordInput = document.getElementById('resetNewPassword')
  const resetConfirmPasswordInput = document.getElementById('resetConfirmPassword')
  
  const sendResetCodeBtn = document.getElementById('sendResetCodeBtn')
  const verifyResetOtpBtn = document.getElementById('verifyResetOtpBtn')
  const resendResetOtpBtn = document.getElementById('resendResetOtpBtn')
  const submitResetBtn = document.getElementById('submitResetBtn')

  const toggleResetPasswordBtn = document.getElementById('toggleResetPasswordBtn')
  const eyeIconReset = document.getElementById('eyeIconReset')
  
  toggleResetPasswordBtn?.addEventListener('click', () => {
    const isPrivate = resetNewPasswordInput.type === 'password'
    resetNewPasswordInput.type = isPrivate ? 'text' : 'password'
    eyeIconReset.innerHTML = isPrivate
      ? `<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.52 13.52 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/>`
      : `<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>`
  })

  let emailOrPhone = ''

  sendResetCodeBtn.addEventListener('click', async () => {
    emailOrPhone = resetIdentifierInput.value.trim()
    if (!emailOrPhone) {
      setAuthInlineMessage('Please enter your email or mobile.')
      return
    }
    sendResetCodeBtn.disabled = true
    sendResetCodeBtn.textContent = 'Sending...'

    try {
      const res = await fetch(`${authApi}/auth-session/candidate/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailOrPhone }),
      })
      const text = await res.text()
      let data = {}
      try { data = text ? JSON.parse(text) : {} } catch {}

      if (res.ok && data.success) {
        document.getElementById('resetStep1').style.display = 'none'
        document.getElementById('resetStep2').style.display = 'block'
        
        document.getElementById('resetTitle').textContent = 'Verify OTP'
        document.getElementById('resetSubtitle').innerHTML = `Enter the code sent to <span style="font-weight:700; color:var(--vp-blue);">${emailOrPhone}</span>.`
        
        let msg = 'Verification code sent successfully! Please check your email or phone.'
        if (data.otp) {
          msg += ` (Dev Mode OTP: ${data.otp})`
        }
        setAuthInlineMessage(msg, { tone: 'success' })
      } else {
        setAuthInlineMessage(data.message || data.error || 'Failed to send verification code.')
      }
    } catch (e) {
      setAuthInlineMessage(`Error sending verification code: ${e.message}`)
    } finally {
      sendResetCodeBtn.disabled = false
      sendResetCodeBtn.textContent = 'Send Code'
    }
  })

  verifyResetOtpBtn.addEventListener('click', async () => {
    const otp = resetOtpInput.value.trim()
    if (!otp) {
      setAuthInlineMessage('Please enter the verification code.')
      return
    }
    verifyResetOtpBtn.disabled = true
    verifyResetOtpBtn.textContent = 'Verifying...'

    try {
      const res = await fetch(`${authApi}/auth-session/candidate/verify-otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailOrPhone, otp }),
      })
      const text = await res.text()
      let data = {}
      try { data = text ? JSON.parse(text) : {} } catch {}

      if (res.ok && data.success) {
        document.getElementById('resetStep2').style.display = 'none'
        document.getElementById('resetStep3').style.display = 'block'
        
        document.getElementById('resetTitle').textContent = 'New Password'
        document.getElementById('resetSubtitle').innerHTML = `Set your new password for <span style="font-weight:700; color:var(--vp-blue);">${emailOrPhone}</span>.`
        setAuthInlineMessage('OTP verified successfully! Now please enter your new password.', { tone: 'success' })
      } else {
        setAuthInlineMessage(data.message || data.error || 'Verification failed. Please enter a valid OTP.')
      }
    } catch (e) {
      setAuthInlineMessage(`Error verifying OTP: ${e.message}`)
    } finally {
      verifyResetOtpBtn.disabled = false
      verifyResetOtpBtn.textContent = 'Verify Code'
    }
  })

  resendResetOtpBtn.addEventListener('click', () => {
    document.getElementById('resetStep2').style.display = 'none'
    document.getElementById('resetStep1').style.display = 'block'
    document.getElementById('resetTitle').textContent = 'Reset Password'
    document.getElementById('resetSubtitle').textContent = 'Enter your email or phone to receive a verification code.'
  })

  submitResetBtn.addEventListener('click', async () => {
    const otp = resetOtpInput.value.trim()
    const newPassword = resetNewPasswordInput.value
    const confirmPassword = resetConfirmPasswordInput.value
    
    if (!newPassword || newPassword.length < 6) {
      setAuthInlineMessage('Password must be at least 6 characters.')
      return
    }
    if (newPassword !== confirmPassword) {
      setAuthInlineMessage('Passwords do not match.')
      return
    }
    
    submitResetBtn.disabled = true
    submitResetBtn.textContent = 'Resetting...'

    try {
      const res = await fetch(`${authApi}/auth-session/candidate/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailOrPhone, otp, newPassword }),
      })
      const text = await res.text()
      let data = {}
      try { data = text ? JSON.parse(text) : {} } catch {}

      if (res.ok && data.success) {
        await chrome.storage.local.set({
          authFlashMessage: 'Password reset successfully! You can now sign in with your new password.',
        })
        render()
      } else {
        setAuthInlineMessage(data.message || data.error || 'Failed to reset password.')
      }
    } catch (e) {
      setAuthInlineMessage(`Error resetting password: ${e.message}`)
    } finally {
      submitResetBtn.disabled = false
      submitResetBtn.textContent = 'Reset Password'
    }
  })
}

async function renderProfile() {
  const el = getContentEl()
  if (!el) return
  const { careerApiBase, aiChatApiBase, dashboardUrl } = mainSession
  const careerOrigin = normalizeVppoApiBase(careerApiBase, DEFAULT_CAREER_API_BASE).replace(/\/api\/?$/i, '')
  const aiOrigin = normalizeVppoApiBase(aiChatApiBase, DEFAULT_AI_CHAT_API_BASE).replace(/\/api\/?$/i, '')
  const stored = await chrome.storage.local.get('authApiBase')
  const rawAuthBase = stored.authApiBase
  const authOrigin = normalizeAuthApiBase(rawAuthBase, DEFAULT_AUTH_API_BASE)

  el.innerHTML = `
    <div class="profile-view">
      <button type="button" class="profile-back" id="profileBackBtn">← Back to copilot</button>
      <div class="profile-header">
        <img src="../assets/logo.png" alt="${BRAND_NAME}" />
        <h2>Settings</h2>
      </div>
      <p class="profile-hint">API endpoints and dashboard link for this browser. Saved on this device only.</p>
      <div class="profile-section-title">Servers</div>
      <label class="field-label">Auth API (SuperadminBackend)</label>
      <input class="login-input" type="text" id="profileAuthApi" value="${String(authOrigin).replace(/"/g, '&quot;')}" />
      <label class="field-label">Career API (CandidateBackend)</label>
      <input class="login-input" type="text" id="profileCareerApi" value="${String(careerOrigin).replace(/"/g, '&quot;')}" />
      <label class="field-label">AI API (StreamingAi)</label>
      <input class="login-input" type="text" id="profileAiApi" value="${String(aiOrigin).replace(/"/g, '&quot;')}" />
      <label class="field-label">Candidate dashboard</label>
      <input class="login-input" type="text" id="profileDashboardUrl" value="${String(dashboardUrl).replace(/"/g, '&quot;')}" />
      <div class="profile-actions">
        <button type="button" class="btn btn-primary" id="saveProfileBtn">Save settings</button>
        <button type="button" class="btn-outline" id="openDashboardBtn">Open dashboard</button>
        <button type="button" class="btn-danger" id="logoutBtn">Sign out</button>
      </div>
      <p class="app-version">${BRAND_NAME} extension v${EXTENSION_VERSION}</p>
    </div>
  `

  document.getElementById('profileBackBtn')?.addEventListener('click', () => {
    activeView = 'chat'
    void render()
  })

  document.getElementById('saveProfileBtn')?.addEventListener('click', async () => {
    const authApi = normalizeAuthApiBase(
      document.getElementById('profileAuthApi')?.value?.trim() || DEFAULT_AUTH_API_BASE,
      DEFAULT_AUTH_API_BASE
    )
    const careerApi = normalizeVppoApiBase(
      document.getElementById('profileCareerApi')?.value?.trim() || DEFAULT_CAREER_API_BASE,
      DEFAULT_CAREER_API_BASE
    )
    const aiApi = normalizeVppoApiBase(
      document.getElementById('profileAiApi')?.value?.trim() || DEFAULT_AI_CHAT_API_BASE,
      DEFAULT_AI_CHAT_API_BASE
    )
    const dashUrl =
      document.getElementById('profileDashboardUrl')?.value?.trim() || DEFAULT_DASHBOARD_URL
    await chrome.storage.local.set({
      authApiBase: authApi,
      careerApiBase: careerApi,
      aiChatApiBase: aiApi,
      dashboardUrl: dashUrl,
    })
    mainSession.careerApiBase = careerApi
    mainSession.aiChatApiBase = aiApi
    mainSession.dashboardUrl = dashUrl
    const btn = document.getElementById('saveProfileBtn')
    const prev = btn.textContent
    btn.textContent = 'Saved'
    setTimeout(() => { btn.textContent = prev }, 1500)
  })

  document.getElementById('openDashboardBtn')?.addEventListener('click', () => {
    const url = document.getElementById('profileDashboardUrl')?.value?.trim() || mainSession.dashboardUrl
    chrome.tabs.create({ url })
  })

  document.getElementById('logoutBtn')?.addEventListener('click', async () => {
    await chrome.storage.local.remove([
      'authToken',
      'refreshToken',
      'xsrfToken',
      'linkedinStatus',
      'indeedStatus',
      'naukriStatus',
      'monsterStatus',
      'lastSync',
      'lastIndeedSync',
      'lastNaukriSync',
      'lastMonsterSync',
      CHAT_HISTORY_KEY
    ])
    activeView = 'login'
    render()
  })
}

async function refreshSyncToolbar() {
  try {
    const d = await sendRuntimeMessage({ type: 'GET_STATUS' })
    if (!d || typeof d !== 'object') return
    mainSession.linkedinStatus = d.linkedinStatus || ''
    mainSession.lastSync = d.lastSync || ''
    mainSession.linkedinActiveDevice = d.linkedinActiveDevice || null
    const liWrap = document.getElementById('liStatusBadge')
    if (liWrap) liWrap.outerHTML = linkedinBadgeHtml(mainSession.linkedinStatus)
    updateHeaderSyncButton(mainSession.linkedinStatus)
    bindProfilerLoginBadges()
  } catch (err) {
    console.warn('[KareerGrowth popup] refreshSyncToolbar', err)
  }
}

async function refreshLinkedInToolbar() {
  return refreshSyncToolbar()
}

function creditPill(label, used, limit, color) {
  const remaining = Math.max(0, limit - used)
  const isEmpty = remaining === 0
  const isLow = !isEmpty && used >= limit - Math.max(1, Math.floor(limit * 0.2))
  const bg = isEmpty ? '#fee2e2' : isLow ? '#fef3c7' : color.bg
  const text = isEmpty ? '#991b1b' : isLow ? '#78350f' : color.text
  const border = isEmpty ? '#fecaca' : isLow ? '#fde68a' : color.border
  return `<span title="${label}: ${used}/${limit} used today" style="display:inline-flex;align-items:center;gap:4px;padding:3px 7px;border-radius:99px;font-size:9.5px;font-weight:700;background:${bg};color:${text};border:1px solid ${border};white-space:nowrap">${label} ${used}/${limit}</span>`
}

async function loadCreditsSection() {
  const wrap = document.getElementById('creditsSection')
  if (!wrap) return
  try {
    const base = await getCareerApiBaseFromStorage()
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) { wrap.innerHTML = ''; return }

    const get = (tok) => fetch(`${base}/candidates/limits`, { headers: { Authorization: `Bearer ${tok}` } })
    let res = await get(authToken)
    if (res.status === 401) {
      const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
      if (refreshed?.success) {
        const stored = await chrome.storage.local.get('authToken')
        if (stored.authToken) res = await get(stored.authToken)
      }
    }
    if (!res.ok) { wrap.innerHTML = ''; return }
    const data = await res.json().catch(() => ({}))
    if (!data?.success) { wrap.innerHTML = ''; return }

    const lim = data.limits || {}
    const usage = data.usage || {}

    const pills = [
      creditPill('ATS Score',    usage.usedAtsScore   ?? 0, lim.atsScorePerDay    ?? 0,  { bg:'#eff6ff', text:'#1e3a8a', border:'#bfdbfe' }),
      creditPill('LI Jobs',      usage.usedLinkedinJobs ?? 0, lim.dailyLinkedinJobs ?? 0, { bg:'#eef2ff', text:'#312e81', border:'#c7d2fe' }),
      creditPill('Indeed Jobs', usage.usedIndeedJobs ?? 0, lim.dailyIndeedJobs ?? 0, { bg:'#eff6ff', text:'#1e3a8a', border:'#bfdbfe' }),
      creditPill('Naukri Jobs', usage.usedNaukriJobs ?? 0, lim.dailyNaukriJobs ?? lim.dailyIndeedJobs ?? 0, { bg:'#fff7ed', text:'#7c2d12', border:'#fed7aa' }),
      creditPill('Monster Jobs', usage.usedMonsterJobs ?? 0, lim.dailyMonsterJobs ?? lim.dailyNaukriJobs ?? lim.dailyIndeedJobs ?? 0, { bg:'#faf5ff', text:'#581c87', border:'#e9d5ff' }),
      creditPill('Connections',  usage.usedConnections  ?? 0, lim.dailyConnections  ?? 20, { bg:'#f0fdf4', text:'#14532d', border:'#bbf7d0' }),
      creditPill('Cover Letter', usage.usedCoverLetter  ?? 0, lim.coverLetterPerDay  ?? 5,  { bg:'#f0fdf4', text:'#14532d', border:'#bbf7d0' }),
      creditPill('Win',          usage.usedWin          ?? 0, lim.winPerDay          ?? 5,  { bg:'#f0fdfa', text:'#134e4a', border:'#99f6e4' }),
      creditPill('CAR',          usage.usedCar          ?? 0, lim.carPerDay          ?? 5,  { bg:'#faf5ff', text:'#3b0764', border:'#e9d5ff' }),
      creditPill('Negotiator',   usage.usedNegotiator   ?? 0, lim.negotiatorPerDay   ?? 10, { bg:'#f0f9ff', text:'#0c4a6e', border:'#bae6fd' }),
      creditPill('Resume',       usage.usedResume       ?? 0, lim.resumePerMonth     ?? 10, { bg:'#fefce8', text:'#713f12', border:'#fde68a' }),
      creditPill('Influencer',   usage.usedInfluencer   ?? 0, lim.influencerPerMonth ?? 15, { bg:'#fdf2f8', text:'#831843', border:'#fbcfe8' }),
    ]
    wrap.innerHTML = pills.join('')
  } catch {
    if (wrap) wrap.innerHTML = ''
  }
}

function renderMain() {
  try {
    renderMainBody()
  } catch (err) {
    console.error('[KareerGrowth popup renderMain]', err)
    showErrorContent(err?.message || 'Failed to load extension UI.', { keepHeader: true })
  }
}

function renderMainBody() {
  const el = getContentEl()
  if (!el) return
  const isSp = document.body.classList.contains('sidepanel')
  const { linkedinStatus, linkedinActiveDevice } = mainSession
  const supersededBanner =
    linkedinStatus === 'disconnected_other_device' && linkedinActiveDevice
      ? deviceSupersededBannerHtml(linkedinActiveDevice)
      : ''

  el.innerHTML = isSp
    ? `
    <div class="chat-scroll" id="chatScroll"></div>
    <div class="quick-actions" id="quickActions">
      <div class="quick-actions-label">Quick actions</div>
      <div class="quick-actions-row" id="quickActionsRow"></div>
    </div>
    <div class="chat-compose">
      <div class="chat-row">
        <textarea class="chat-input" id="chatInput" rows="2" placeholder="Ask or tap a quick action…"></textarea>
        <button class="send-btn" type="button" id="sendBtn" title="Send">➤</button>
      </div>
    </div>
  `
    : `
    ${supersededBanner}
    <!-- LinkedIn Connection Card -->
    <div style="background: var(--vp-surface); border: 1px solid var(--vp-border); border-radius: 12px; padding: 10px 14px; margin: 12px 14px 10px; display: flex; align-items: center; justify-content: space-between; gap: 12px;">
      <div style="display: flex; align-items: center; gap: 10px; min-width: 0;">
        <div style="width: 30px; height: 30px; border-radius: 8px; background: rgba(37,99,235,0.08); display: flex; align-items: center; justify-content: center; color: var(--vp-blue); flex-shrink: 0;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
        </div>
        <div style="min-width: 0;">
          <div style="font-size: 13px; font-weight: 800; color: var(--vp-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">LinkedIn Profiler</div>
          <div style="font-size: 10px; color: var(--vp-dim); margin-top: 1px;">Sync status to pull job data</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 8px; flex-shrink: 0;">
        ${linkedinBadgeHtml(linkedinStatus)}
        <button type="button" class="link-btn" id="syncAgainBtn" style="width: 28px; height: 28px; border-radius: 6px; background: rgba(37, 99, 235, 0.08); color: var(--vp-blue); border: none; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: background 0.15s; flex-shrink: 0;" title="Sync LinkedIn">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
        </button>
      </div>
    </div>

    <!-- Promotional AI Copilot Hero Card -->
    <div style="background: linear-gradient(135deg, rgba(37, 99, 235, 0.03) 0%, rgba(30, 64, 175, 0.07) 100%); border: 1px solid rgba(37, 99, 235, 0.12); border-radius: 12px; padding: 12px 14px; margin: 0 14px 12px; display: flex; flex-direction: column; gap: 8px; align-items: center; text-align: center;">
      <div style="display: flex; align-items: center; gap: 6px;">
        <span style="font-size: 14px;">✨</span>
        <h3 style="font-size: 13px; font-weight: 800; color: var(--vp-text); letter-spacing: -0.01em;">AI Copilot Sidebar</h3>
      </div>
      <p style="font-size: 10.5px; color: var(--vp-muted); line-height: 1.4; margin: 0;">Run real-time ATS scores, resume tailoring, and chat with AI directly on any job page.</p>
      <button type="button" class="btn btn-primary" id="openSideBtn" style="margin: 2px 0 0; padding: 8px 14px; border-radius: 8px; font-size: 11.5px; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(37, 99, 235, 0.15); width: auto;">
        <span>Open Sidebar Copilot</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </button>
    </div>

    <!-- Quick Tools Grid -->
    <div style="padding: 0 14px 14px;">
      <div style="font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; color: var(--vp-dim); margin-bottom: 8px;">Quick Tools</div>
      <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px;">
        
        <button type="button" id="toolAtsBtn" class="premium-tool-btn">
          <div class="tool-icon-wrap" style="color: #2563eb; background: rgba(37,99,235,0.08);">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
          </div>
          <div class="tool-label">ATS Score</div>
        </button>

        <button type="button" id="toolDownloadBtn" class="premium-tool-btn">
          <div class="tool-icon-wrap" style="color: #059669; background: rgba(5,150,105,0.08);">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          </div>
          <div class="tool-label">AI Resume & Download</div>
        </button>

        <button type="button" id="toolTrackerBtn" class="premium-tool-btn">
          <div class="tool-icon-wrap" style="color: #ea580c; background: rgba(234,88,12,0.08);">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
          </div>
          <div class="tool-label">Add to Tracker</div>
        </button>

        <button type="button" id="toolFillBtn" class="premium-tool-btn">
          <div class="tool-icon-wrap" style="color: #db2777; background: rgba(219,39,119,0.08);">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
          </div>
          <div class="tool-label">Fill Form</div>
        </button>

        <button type="button" id="toolJobsBtn" class="premium-tool-btn">
          <div class="tool-icon-wrap" style="color: #0284c7; background: rgba(2,132,199,0.08);">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          </div>
          <div class="tool-label">LinkedIn Jobs</div>
        </button>

      </div>
    </div>

    <!-- Credits Section -->
    <div style="padding: 0 14px 14px;">
      <div style="font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; color: var(--vp-dim); margin-bottom: 8px;">Credits Today</div>
      <div id="creditsSection" style="display: flex; flex-wrap: wrap; gap: 5px;">
        <span style="font-size: 10px; color: var(--vp-dim);">Loading…</span>
      </div>
    </div>
  `

  bindProfilerLoginBadges()

  document.getElementById('syncAgainBtn')?.addEventListener('click', async () => {
    const btn = document.getElementById('syncAgainBtn')
    if (mainSession.linkedinStatus === 'not_logged_in') {
      await openLinkedInLoginPage()
      return
    }
    btn.disabled = true
    const isIconBtn = btn.querySelector('svg')
    if (isIconBtn) btn.classList.add('spin-icon')
    else btn.textContent = 'Syncing…'
    await runLinkedInSyncWithConflictFlow()
    setTimeout(async () => {
      await refreshSyncToolbar()
      btn.disabled = false
      if (isIconBtn) btn.classList.remove('spin-icon')
      else btn.textContent = 'Sync again'
    }, 1600)
  })

  document.getElementById('deviceTakeoverBtn')?.addEventListener('click', async () => {
    const btn = document.getElementById('deviceTakeoverBtn')
    if (btn) btn.disabled = true
    await runLinkedInSyncWithConflictFlow()
    setTimeout(async () => {
      await refreshSyncToolbar()
      if (btn) btn.disabled = false
    }, 1200)
  })

  const openSide = document.getElementById('openSideBtn')
  if (openSide) {
    openSide.addEventListener('click', (e) => {
      e.preventDefault()
      void openSidePanelWithAction()
    })
  }

  if (!isSp) {
    document.getElementById('toolAtsBtn')?.addEventListener('click', () => openSidePanelWithAction({ type: 'ats' }))
    document.getElementById('toolDownloadBtn')?.addEventListener('click', () => openSidePanelWithAction({ type: 'tailor-download' }))
    document.getElementById('toolTrackerBtn')?.addEventListener('click', () => runAddToTrackerDirect())
    document.getElementById('toolFillBtn')?.addEventListener('click', () => openSidePanelWithAction({ type: 'fill' }))
    document.getElementById('toolJobsBtn')?.addEventListener('click', () => openSidePanelWithAction({ type: 'jobs' }))
    void loadCreditsSection()
    return
  }

  const chatScroll = document.getElementById('chatScroll')
  const chatInput = document.getElementById('chatInput')
  const sendBtn = document.getElementById('sendBtn')
  const quickActionsRow = document.getElementById('quickActionsRow')
  let isSending = false
  let _pendingTailorDownload = null
  let _taskFlow = null
  let _trackerSearchFlow = null
  let _aiResumeFlow = null

  const setQuickChipsDisabled = (disabled) => {
    quickActionsRow?.querySelectorAll('.quick-chip').forEach((btn) => {
      btn.disabled = disabled
    })
  }

  const renderQuickActions = async () => {
    if (!quickActionsRow) return
    let onJobPage = false
    try {
      const pageCtx = await chrome.runtime.sendMessage({ type: 'GET_ACTIVE_PAGE_CONTEXT' })
      const pc = pageCtx?.pageContext
      onJobPage = Boolean(
        pc?.jobDescription && String(pc.jobDescription).trim().length > 80
      )
    } catch {
      /* ignore */
    }

    quickActionsRow.innerHTML = ''
    for (const action of QUICK_ACTIONS) {
      const btn = document.createElement('button')
      btn.type = 'button'
      btn.className = `quick-chip chip-${action.id}`
      if (
        action.primary ||
        (action.id === 'add-tracker' && onJobPage) ||
        (action.id === 'ats' && onJobPage) ||
        (action.id === 'tailor-download' && onJobPage) ||
        (action.id === 'cover-letter' && onJobPage) ||
        (action.id === 'mock-interview' && onJobPage)
      ) {
        btn.classList.add('primary')
      }
      btn.textContent = action.label
      btn.title = action.directAddTracker
        ? 'Save this job to your application tracker'
        : action.directDownload
          ? 'AI-optimize your full resume for this job and download as HTML'
          : action.directCoverLetter
            ? 'Generate cover letter from this job page (saved to your dashboard)'
            : action.directAiResume
              ? 'AI-optimize primary resume for this job (saved as new resume in dashboard)'
              : action.message
      if (action.directAddTracker) {
        btn.addEventListener('click', () => runAddToTrackerDirect())
      } else if (action.directAts) {
        btn.addEventListener('click', () => runAtsScoreDirect())
      } else if (action.directDownload) {
        btn.addEventListener('click', () => runTailorResumeDirectDownload())
      } else if (action.directCoverLetter) {
        btn.addEventListener('click', () => runCoverLetterDirect())
      } else if (action.directAiResume) {
        btn.addEventListener('click', () => runAiOptimizeResumeDirect())
      } else if (action.directResumes) {
        btn.addEventListener('click', () => runMyResumesDirect())
      } else if (action.directFill) {
        btn.addEventListener('click', () => runFillFormDirect())
      } else if (action.directJobs) {
        btn.addEventListener('click', () => runJobSearchDirect())
      } else if (action.directIndeedJobs) {
        btn.addEventListener('click', () => runIndeedJobSearchDirect())
      } else if (action.directNaukriJobs) {
        btn.addEventListener('click', () => runNaukriJobSearchDirect())
      } else if (action.directMonsterJobs) {
        btn.addEventListener('click', () => runMonsterJobSearchDirect())
      } else if (action.directPeople) {
        btn.addEventListener('click', () => runPeopleSearchDirect())
      } else if (action.directPageJobs) {
        btn.addEventListener('click', () => runPageJobsDirect())
      } else if (action.directMockInterview) {
        btn.addEventListener('click', () => runMockInterviewDirect())
      } else if (action.directMyTasks) {
        btn.addEventListener('click', () => runMyTasksDirect())
      } else if (action.directAddTask) {
        btn.addEventListener('click', () => runAddTaskDirect())
      } else {
        btn.addEventListener('click', () => sendMessage(action.message, action.label))
      }
      quickActionsRow.appendChild(btn)
    }
  }

  void renderQuickActions()

  const runAtsScoreDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }
    const pageContext = await fetchPageContext()

    const history = await loadChatHistory()
    history.push({ role: 'user', content: 'ATS score for this job', display: 'ATS score', t: Date.now() })
    await saveChatHistory(history)
    await paint()

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Checking your current primary resume matching with this JD...'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)
    try {
      const aiBase = await getAiChatApiBase()
      let token = authToken
      let res = await fetch(`${aiBase}/ai/tools/ats-score`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ pageContext })
      })
      if (res.status === 401) {
        const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
        if (refreshed?.success) {
          const stored = await chrome.storage.local.get('authToken')
          token = stored.authToken
          if (token) {
            res = await fetch(`${aiBase}/ai/tools/ats-score`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
              body: JSON.stringify({ pageContext })
            })
          }
        }
        if (res.status === 401) {
          await handleUnauthorizedError()
        }
      }
      const data = await res.json().catch(() => ({}))
      document.getElementById('thinkingBubble')?.remove()

      if (!res.ok || !data.ui?.data) {
        history.push({
          role: 'assistant',
          content: data.message || data.detail || `ATS failed (${res.status})`,
          t: Date.now()
        })
        await saveChatHistory(history)
        await paint()
        return
      }

      history.push({
        role: 'assistant',
        content: data.ui.data.summary || `ATS score: ${data.ui.data.score}/100`,
        ui: data.ui,
        t: Date.now()
      })
      await saveChatHistory(history)
      await paint()
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({ role: 'assistant', content: e.message || 'ATS failed.', t: Date.now() })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  const runCoverLetterDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }

    const pageContext = await fetchPageContext()
    const companyName = String(pageContext?.company || '').trim()
    const jobTitle = String(pageContext?.jobTitle || pageContext?.title || '').trim()
    if (!companyName || !jobTitle) {
      await pushAssistantMessage('Open a job posting page first (company and role title are required).')
      return
    }

    const history = await loadChatHistory()
    history.push({
      role: 'user',
      content: `Cover letter for ${jobTitle} at ${companyName}`,
      display: 'Cover letter',
      t: Date.now()
    })
    await saveChatHistory(history)
    await paint()

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Writing cover letter…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)
    try {
      const careerBase = normalizeVppoApiBase(
        mainSession.careerApiBase || (await chrome.storage.local.get('careerApiBase')).careerApiBase,
        DEFAULT_CAREER_API_BASE
      )
      const stored = await chrome.storage.local.get('dashboardUrl')
      const dashboardUrl = `${stored.dashboardUrl || DEFAULT_DASHBOARD_URL}/candidate/profile/cover-letter`

      const body = {
        companyName,
        jobTitle,
        hiringManager: '',
        tone: 'professional',
        jobDescription: pageContext?.jobDescription || '',
        minExperience: '',
        maxExperience: ''
      }

      const post = (token) =>
        fetch(`${careerBase}/candidates/profile/cover-letters/generate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify(body)
        })

      let token = authToken
      let res = await post(token)
      if (res.status === 401) {
        const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
        if (refreshed?.success) {
          const t2 = await chrome.storage.local.get('authToken')
          token = t2.authToken
          if (token) res = await post(token)
        }
        if (res.status === 401) {
          await handleUnauthorizedError()
        }
      }

      const data = await res.json().catch(() => ({}))
      document.getElementById('thinkingBubble')?.remove()

      if (!res.ok || !data.success) {
        history.push({
          role: 'assistant',
          content: data.message || `Cover letter failed (${res.status})`,
          t: Date.now()
        })
        await saveChatHistory(history)
        await paint()
        return
      }

      const generatedLetter = String(data.coverLetter?.generatedLetter || '').trim()
      history.push({
        role: 'assistant',
        content: generatedLetter
          ? `Cover letter for ${jobTitle} at ${companyName} (saved to your account).`
          : 'Cover letter generated.',
        ui: {
          type: 'coverLetter',
          data: {
            companyName,
            jobTitle,
            tone: data.coverLetter?.tone || 'professional',
            generatedLetter,
            dashboardUrl
          }
        },
        t: Date.now()
      })
      await saveChatHistory(history)
      await paint()
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({
        role: 'assistant',
        content: e.message || 'Cover letter failed.',
        t: Date.now()
      })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  const runMockInterviewDirect = async () => {
    const pageContext = await fetchPageContext()
    const jd = String(pageContext?.jobDescription || '').trim()
    const jobTitle = String(pageContext?.jobTitle || pageContext?.title || '').trim()
    const company = String(pageContext?.company || '').trim()
    if (!jd || jd.length < 50) {
      await pushAssistantMessage('Open a job posting page with a job description first.')
      return
    }
    const history = await loadChatHistory()
    history.push({
      role: 'user',
      content: `Mock interview for ${jobTitle || 'this job'}${company ? ` at ${company}` : ''}`,
      display: 'Mock Interview',
      t: Date.now()
    })
    history.push({
      role: 'assistant',
      content: `Here is the job description for ${jobTitle || 'this job'}${company ? ` at ${company}` : ''}. Click Start Interview to begin your mock interview session.`,
      ui: { type: 'mockInterview', data: { jobTitle, company, jobDescription: jd } },
      t: Date.now()
    })
    await saveChatHistory(history)
    await paint()
  }

  const runMyTasksDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) { await pushAssistantMessage('Not signed in.'); return }

    const history = await loadChatHistory()
    history.push({ role: 'user', content: 'My tasks', display: 'My Tasks', t: Date.now() })
    await saveChatHistory(history)
    await paint()

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Loading your tasks…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)
    try {
      const filterEvent = await new Promise(resolve => {
        document.dispatchEvent(new CustomEvent('task-filter-request', { bubbles: true, detail: { resolve } }))
        setTimeout(() => resolve({}), 200)
      })
      const q = new URLSearchParams()
      const f = filterEvent || {}
      if (f.date) q.set('date', f.date)
      if (f.status) q.set('status', f.status)
      if (f.exclude_completed) q.set('exclude_completed', '1')
      if (f.overdue) q.set('overdue', '1')
      const qs = q.toString() ? `?${q.toString()}` : ''
      const { res, data } = await careerApiFetch(`/candidates/self-tasks${qs}`)
      document.getElementById('thinkingBubble')?.remove()

      if (!res.ok) {
        const errHist = await loadChatHistory()
        errHist.push({ role: 'assistant', content: data.message || `Failed to load tasks (${res.status})`, t: Date.now() })
        await saveChatHistory(errHist)
        await paint()
        return
      }
      const tasks = data.data || []
      const hist = await loadChatHistory()
      hist.push({
        role: 'assistant',
        content: tasks.length ? `Found ${tasks.length} task(s).` : 'No tasks found for these filters.',
        ui: { type: 'tasks', data: { tasks } },
        t: Date.now()
      })
      await saveChatHistory(hist)
      await paint()
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({ role: 'assistant', content: e.message || 'Failed to load tasks.', t: Date.now() })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  const runAddTaskDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) { await pushAssistantMessage('Not signed in.'); return }

    const hist = await loadChatHistory()
    hist.push({
      role: 'assistant',
      content: 'Fill in the task details below.',
      ui: { type: 'addTask', data: {} },
      t: Date.now()
    })
    await saveChatHistory(hist)
    await paint()
  }

  document.addEventListener('task-submit', async (e) => {
    const { title, description, deadline, link, priority } = e.detail || {}
    if (!title || !description || !deadline) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) { await pushAssistantMessage('Not signed in.'); return }
    try {
      const { res, data } = await careerApiFetch('/candidates/self-tasks', {
        method: 'POST',
        body: JSON.stringify({ title, description, deadline, link: link || undefined, priority: priority || 'Medium' })
      })
      if (!res.ok) {
        history.push({
          role: 'assistant',
          content: data.message || `Failed to create task (${res.status})`,
          t: Date.now(),
        })
        await saveChatHistory(history)
        await paint()
        return
      }
      const hist = await loadChatHistory()
      hist.push({ role: 'user', content: `Add task: ${title}`, display: `Add task: ${title}`, t: Date.now() })
      hist.push({
        role: 'assistant',
        content: `Task "${title}" added! Deadline: ${deadline}.`,
        t: Date.now()
      })
      await saveChatHistory(hist)
      await paint()
    } catch (err) {
      history.push({ role: 'assistant', content: err.message || 'Failed to create task.', t: Date.now() })
      await saveChatHistory(history)
      await paint()
    }
  })

  document.addEventListener('tracker-stages-selected', async (e) => {
    const selectedStages = e.detail?.stages || []
    if (!selectedStages.length) return

    // Show selection in user message bubble
    const displaySelected = `Show tracker stages: ${selectedStages.map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(', ')}`
    const hist = await loadChatHistory()
    hist.push({
      role: 'user',
      content: displaySelected,
      display: displaySelected,
      t: Date.now()
    })
    await saveChatHistory(hist)
    await paint()

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)

    const chatScroll = document.getElementById('chatScroll')
    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Searching your tracker...'
    thinking.id = 'thinkingBubble'
    if (chatScroll) {
      chatScroll.appendChild(thinking)
      chatScroll.scrollTop = chatScroll.scrollHeight
    }

    // Retrieve any search keyword query if conversational search flow is active
    let query = ''
    if (_trackerSearchFlow?.step === 'select_stages') {
      query = _trackerSearchFlow.query || ''
    }
    _trackerSearchFlow = null // clear flow state

    try {
      const stagesParam = selectedStages.join(',')
      let path = `/candidates/tracker?limit=50&tab=all&stage=${encodeURIComponent(stagesParam)}`
      if (query) {
        path += `&search=${encodeURIComponent(query)}`
      }
      const { res, data } = await careerApiFetch(path)
      document.getElementById('thinkingBubble')?.remove()

      const reply = async (content, ui) => {
        const h = await loadChatHistory()
        const entry = { role: 'assistant', content, t: Date.now() }
        if (ui) entry.ui = ui
        h.push(entry)
        await saveChatHistory(h)
        await paint()
      }

      if (res.ok && data?.jobs?.length) {
        const jobs = data.jobs
        const matchesLabel = query ? `matching "${query}" ` : ''
        let html = `Found ${jobs.length} matching job(s) ${matchesLabel}in your tracker:<br><br>`
        const storedDb = await chrome.storage.local.get('dashboardUrl')
        const dashUrl = normalizeVppoApiBase(
          mainSession.dashboardUrl || storedDb.dashboardUrl,
          DEFAULT_VPPO_APP_BASE
        )
        for (const job of jobs) {
          const capitalizedStage = job.stage ? job.stage.charAt(0).toUpperCase() + job.stage.slice(1) : 'N/A'
          
          let skills = job.skills
          if (!skills && job.description) {
            const jdSkills = extractJdTechSkills(job.description)
            if (jdSkills.length > 0) {
              skills = jdSkills.slice(0, 5).join(', ')
            }
          }
          if (!skills) {
            skills = 'N/A'
          }

          html += `<strong>${job.company || 'N/A'}</strong> - ${job.title || 'Untitled Role'}<br>`
          html += `Stage: ${capitalizedStage}<br>`
          html += `Match Score: ${job.matchPercent != null ? job.matchPercent + '%' : 'N/A'}<br>`
          html += `Required Skills: ${skills}<br>`
          html += `<div style="display: flex; gap: 8px; margin-top: 6px; margin-bottom: 12px;">`
          if (job.sourceUrl) {
            html += `<a href="${job.sourceUrl}" target="_blank" style="flex: 1; text-align: center; background: #2563eb; color: #ffffff; padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: bold; text-decoration: none; display: inline-block;">Job Link</a>`
          }
          html += `<a href="${dashUrl}/candidate/tracker" target="_blank" style="flex: 1; text-align: center; background: transparent; border: 1px solid #2563eb; color: #2563eb; padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: bold; text-decoration: none; display: inline-block;">Open Tracker</a>`
          html += `</div>`
        }
        await reply(html, { type: 'html', data: html })
      } else {
        const searchLabel = query ? `matching "${query}" ` : ''
        await reply(`No jobs found in your tracker ${searchLabel}matching stages: ${selectedStages.map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(', ')}.`)
      }
    } catch (err) {
      console.error('Tracker search error:', err)
      document.getElementById('thinkingBubble')?.remove()
      const h = await loadChatHistory()
      h.push({ role: 'assistant', content: `Error searching tracker jobs: ${err.message || err}`, t: Date.now() })
      await saveChatHistory(h)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  })

  document.addEventListener('mock-interview-start', (e) => {
    const { jobTitle, company, jobDescription } = e.detail || {}
    const titlePart = jobTitle || 'this job'
    const companyPart = company ? ` at ${company}` : ''
    const prompt =
      `Start a mock interview for the ${titlePart}${companyPart} role. ` +
      `Use the job description below to ask me relevant interview questions. ` +
      `Ask one question at a time and wait for my answer before continuing.\n\n` +
      `Job Description:\n${jobDescription || ''}`
    sendMessage(prompt, `Mock interview — ${titlePart}${companyPart}`)
  })

  const runClientSearchDirect = async (toolName, displayLabel, kind, toolArgs = {}) => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }

    const history = await loadChatHistory()
    history.push({ role: 'user', content: displayLabel, display: displayLabel, t: Date.now() })
    await saveChatHistory(history)
    await paint()

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent =
      kind === 'jobs'
        ? 'Searching LinkedIn jobs…'
        : kind === 'indeedJobs'
          ? 'Searching Indeed jobs…'
          : kind === 'naukriJobs'
            ? 'Searching Naukri jobs…'
            : kind === 'monsterJobs'
              ? 'Searching Monster jobs…'
              : 'Finding people on LinkedIn…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)
    try {
      const run = await chrome.runtime.sendMessage({
        type: 'RUN_AGENT_CLIENT_TOOLS',
        actions: [{ name: toolName, args: toolArgs }]
      })
      document.getElementById('thinkingBubble')?.remove()
      const result = run?.results?.[0]?.result || {}
      if (!result.success) {
        const msg =
          result.message ||
          (result.error === 'no_new_jobs' || result.code === 'no_new_jobs'
            ? kind === 'monsterJobs'
              ? 'No Monster jobs found for this search. Try again later or update job preferences in Settings.'
              : kind === 'indeedJobs'
                ? 'No Indeed jobs found for this search. Try again later or update job preferences in Settings.'
                : 'No Naukri jobs found for this search. Try again later or update job preferences in Settings.'
            : result.code === 'NAUKRI_NEEDS_NKPARAM' || result.error === 'NAUKRI_NEEDS_NKPARAM'
              ? 'Open naukri.com in Chrome, run a job search once, then sync Naukri in the extension.'
              : result.code === 'NAUKRI_RECAPTCHA' || result.error === 'NAUKRI_RECAPTCHA'
                ? 'Naukri security check — open naukri.com, complete verification if shown, then try again.'
                : result.error === 'PLATFORM_SEARCH_LIMIT'
                  ? 'Daily search limit reached.'
                  : result.error === 'LINKEDIN_NOT_LOGGED_IN'
                    ? 'Sign in to linkedin.com in Chrome, then try again.'
                    : result.error === 'INDEED_NOT_LOGGED_IN'
                      ? 'Sign in to indeed.com in Chrome, then try again.'
                      : result.error === 'INDEED_CHALLENGE' || result.code === 'INDEED_CHALLENGE'
                        ? 'Indeed needs verification — complete the checkbox in the Indeed tab that opened, then run search again.'
                        : result.error === 'NAUKRI_NOT_LOGGED_IN'
                        ? 'Sign in to naukri.com in Chrome, browse jobs once, then sync in the extension.'
                        : result.error === 'MONSTER_NOT_LOGGED_IN'
                          ? 'Log in on monster.com in Chrome, then sync in the extension.'
                          : 'Search failed.')
        history.push({ role: 'assistant', content: msg, t: Date.now() })
        await saveChatHistory(history)
        await paint()
        return
      }
      const ui = { type: kind, data: result }
      history.push({
        role: 'assistant',
        content: summaryTextForClientSearch(result, kind),
        ui,
        t: Date.now()
      })
      await saveChatHistory(history)
      await paint()
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({ role: 'assistant', content: e.message || 'Search failed.', t: Date.now() })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  const runJobSearchDirect = () =>
    runClientSearchDirect('search_linkedin_jobs_in_browser', 'Search LinkedIn jobs', 'jobs')

  const runIndeedJobSearchDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }
    await runClientSearchDirect('search_indeed_jobs_in_browser', 'Search Indeed jobs', 'indeedJobs')
  }

  const runNaukriJobSearchDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }
    await runClientSearchDirect(
      'search_naukri_jobs_in_browser',
      'Search Naukri jobs',
      'naukriJobs'
    )
  }

  const runMonsterJobSearchDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }
    await runClientSearchDirect(
      'search_monster_jobs_via_backend',
      'Search Monster jobs',
      'monsterJobs'
    )
  }

  const runPeopleSearchDirect = () =>
    runClientSearchDirect('search_linkedin_people_in_browser', 'Find people to connect', 'people', { count: 5 })

  const runMyResumesDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) { await pushAssistantMessage('Not signed in.'); return }

    const history = await loadChatHistory()
    history.push({ role: 'user', content: 'My resume', display: 'My Resume', t: Date.now() })
    await saveChatHistory(history)
    await paint()

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Loading your primary resume…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)
    try {
      const careerBase = normalizeVppoApiBase(
        mainSession.careerApiBase || (await chrome.storage.local.get('careerApiBase')).careerApiBase,
        DEFAULT_CAREER_API_BASE
      )
      let token = authToken

      // Fetch primary resume's full extracted data
      const fetchPrimary = (tok) =>
        fetch(`${careerBase}/candidates/profile/resume/primary`, {
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` }
        })

      let res = await fetchPrimary(token)
      if (res.status === 401) {
        const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
        if (refreshed?.success) {
          const stored = await chrome.storage.local.get('authToken')
          token = stored.authToken
          if (token) res = await fetchPrimary(token)
        }
        if (res.status === 401) { await handleUnauthorizedError(); return }
      }

      const payload = await res.json().catch(() => ({}))
      document.getElementById('thinkingBubble')?.remove()

      if (!res.ok || !payload.data?.extractedJson) {
        const errHist = await loadChatHistory()
        errHist.push({
          role: 'assistant',
          content: payload.message || 'No primary resume found. Please upload and set a primary resume on your dashboard.',
          t: Date.now()
        })
        await saveChatHistory(errHist)
        await paint()
        return
      }

      const resumeData = extractionToResumeData(payload.data.extractedJson)
      if (!resumeData) {
        const errHist = await loadChatHistory()
        errHist.push({ role: 'assistant', content: 'Primary resume has no extracted data yet.', t: Date.now() })
        await saveChatHistory(errHist)
        await paint()
        return
      }

      const hist = await loadChatHistory()
      hist.push({
        role: 'assistant',
        content: `Primary resume: ${resumeData.name || 'Your resume'}`,
        ui: { type: 'primaryResume', data: resumeData },
        t: Date.now()
      })
      await saveChatHistory(hist)
      await paint()
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({ role: 'assistant', content: e.message || 'Could not load resume.', t: Date.now() })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  const runPageJobsDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }

    const history = await loadChatHistory()
    history.push({ role: 'user', content: 'Jobs on this page', display: 'Jobs on this page', t: Date.now() })
    await saveChatHistory(history)
    await paint()

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Scanning careers page for roles…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)
    try {
      const run = await chrome.runtime.sendMessage({
        type: 'RUN_AGENT_CLIENT_TOOLS',
        actions: [{ name: 'find_jobs_on_careers_page', args: {} }]
      })
      document.getElementById('thinkingBubble')?.remove()
      const result = run?.results?.[0]?.result || {}
      if (!result.success) {
        const msg = result.message || result.error || 'Could not scan this page.'
        history.push({ role: 'assistant', content: msg, t: Date.now() })
        await saveChatHistory(history)
        await paint()
        return
      }
      const ui = { type: 'pageJobs', data: result }
      history.push({
        role: 'assistant',
        content: summaryTextForPageJobs(result),
        ui,
        t: Date.now()
      })
      await saveChatHistory(history)
      await paint()
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({ role: 'assistant', content: e.message || 'Scan failed.', t: Date.now() })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  const runFillFormDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }

    const history = await loadChatHistory()
    history.push({
      role: 'user',
      content: 'Fill application form on current tab',
      display: 'Fill form',
      t: Date.now()
    })
    await saveChatHistory(history)
    await paint()

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Filling form fields on this page…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)
    try {
      const run = await chrome.runtime.sendMessage({
        type: 'RUN_AGENT_CLIENT_TOOLS',
        actions: [{ name: 'fill_job_application_form', args: {} }]
      })
      document.getElementById('thinkingBubble')?.remove()
      const result = run?.results?.[0]?.result || {}
      if (result.success && (result.filled > 0 || result.filled === 0)) {
        const msg =
          result.filled > 0
            ? `Filled ${result.filled} field(s) on this page. Review before submitting.`
            : 'No matching fields found on this tab. Open the application form (after Apply) and try again.'
        history.push({ role: 'assistant', content: msg, t: Date.now() })
        await saveChatHistory(history)
        await paint()
      } else {
        const msg =
          result.error ||
          'Could not fill this page. Open the job application form (click Apply on the posting), then try Fill form again.'
        history.push({ role: 'assistant', content: msg, t: Date.now() })
        await saveChatHistory(history)
        await paint()
      }
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({ role: 'assistant', content: e.message || 'Fill form failed.', t: Date.now() })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  // ── Conversational tracker search flow ──────────────────────────────────────
  const advanceTrackerSearchFlow = async (userText) => {
    const flow = _trackerSearchFlow
    if (!flow) return

    const reply = async (content, ui) => {
      const h = await loadChatHistory()
      const entry = { role: 'assistant', content, t: Date.now() }
      if (ui) entry.ui = ui
      h.push(entry)
      await saveChatHistory(h)
      await paint()
    }

    const lowerText = userText.trim().toLowerCase()
    const cancel = ['cancel', 'stop', 'abort', 'quit', 'exit', 'no', 'none'].includes(lowerText)
    if (cancel) {
      _trackerSearchFlow = null
      await reply('Ok, cancelled tracker search.')
      return
    }

    if (flow.step === 'search_query') {
      const query = userText.trim()
      _trackerSearchFlow = { step: 'select_stages', query: query }
      await reply('Which sections would you like to search within? Please select below:', {
        type: 'trackerStageSelect',
        data: {}
      })
    }
  }

  // ── Conversational resume tailoring flow ─────────────────────────────────────
  const advanceAiResumeFlow = async (userText) => {
    const flow = _aiResumeFlow
    if (!flow) return

    const reply = async (content, ui) => {
      const h = await loadChatHistory()
      const entry = { role: 'assistant', content, t: Date.now() }
      if (ui) entry.ui = ui
      h.push(entry)
      await saveChatHistory(h)
      await paint()
    }

    const lowerText = userText.trim().toLowerCase()
    const cancel = ['cancel', 'stop', 'abort', 'quit', 'exit'].includes(lowerText)
    if (cancel) {
      _aiResumeFlow = null
      _pendingTailorDownload = null
      await reply('Ok, sure I have cancelled the resume tailoring.')
      return
    }

    // Save the user's answer
    flow.answers.push({
      question: flow.questions[flow.currentIndex],
      answer: userText.trim()
    })

    flow.currentIndex++

    if (flow.currentIndex < flow.questions.length) {
      const nextQ = flow.questions[flow.currentIndex]
      const n = flow.currentIndex + 1
      await reply(`**${n}.** ${nextQ}`)
    } else {
      // All questions answered! Proceed with tailor and download!
      const finalFlow = _aiResumeFlow
      _aiResumeFlow = null
      _pendingTailorDownload = null

      // Combine Q&A context to pass to additionalContext
      const qaString = finalFlow.answers.map(a => `Q: ${a.question}\nA: ${a.answer}`).join('\n\n')
      
      const enrichedUserInput = {
        answers: finalFlow.skillsData.answers || [],
        extraNote: [
          finalFlow.skillsData.extraNote,
          finalFlow.skillsData.experienceGapNote
            ? `Experience context: ${finalFlow.skillsData.experienceGapNote}`
            : '',
          qaString,
        ].filter(Boolean).join('\n\n'),
        qaAnswers: finalFlow.answers,
      }

      await _doTailorDownload(finalFlow.pending, enrichedUserInput)
    }
  }

  // ── Core generation + download (called either directly or after Q&A) ──
  const _doTailorDownload = async ({ pageContext, resumeContext, token: startToken }, userInput) => {
    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Generating your AI-optimized resume…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    try {
      const aiBase = await getAiChatApiBase()
      let token = startToken

      // Build enriched request — add skill confirmations + candidate note if from Q&A
      const skillUsageNotes = (userInput.answers || [])
        .filter((a) => a.hasIt && a.note)
        .map((a) => `${a.skill}: ${a.note}`)
        .join('\n')

      const additionalContext = userInput
        ? {
            skillsConfirmed: (userInput.answers || [])
              .filter((a) => a.hasIt)
              .map((a) => a.skill),
            skillsNotApplicable: (userInput.answers || [])
              .filter((a) => a.answered && !a.hasIt)
              .map((a) => a.skill),
            candidateNote: [
              skillUsageNotes ? `Confirmed skill usage:\n${skillUsageNotes}` : '',
              userInput.extraNote || '',
            ].filter(Boolean).join('\n\n') || undefined,
            qaAnswers: (userInput.qaAnswers || []).map((row) => ({
              question: row.question,
              answer: row.answer,
            })),
          }
        : undefined

      const requestBody = {
        pageContext,
        ...(resumeContext ? { resumeContext } : {}),
        ...(additionalContext ? { additionalContext } : {})
      }

      let res = await fetch(`${aiBase}/ai/tools/tailor-resume-document`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(requestBody)
      })
      if (res.status === 401) {
        const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
        if (refreshed?.success) {
          const stored = await chrome.storage.local.get('authToken')
          token = stored.authToken
          if (token) {
            res = await fetch(`${aiBase}/ai/tools/tailor-resume-document`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
              body: JSON.stringify(requestBody)
            })
          }
        }
        if (res.status === 401) { await handleUnauthorizedError(); return }
      }
      const data = await res.json().catch(() => ({}))
      document.getElementById('thinkingBubble')?.remove()

      const hist = await loadChatHistory()
      if (!res.ok || !data.downloadToken) {
        hist.push({ role: 'assistant', content: data.message || data.detail || `Failed (${res.status})`, t: Date.now() })
        await saveChatHistory(hist)
        await paint()
        return
      }
      await downloadTailoredResumeFile(aiBase, data.downloadToken, data.fileName, token)
      const enhancementLines = []
      if (data.enhancements?.skillsAdded?.length) {
        enhancementLines.push(`Skills added: ${data.enhancements.skillsAdded.join(', ')}`)
      }
      if (data.enhancements?.skillsTotal) {
        enhancementLines.push(`Skills in resume: ${data.enhancements.skillsTotal} total`)
      }
      if (data.enhancements?.atsKeywords?.length) {
        enhancementLines.push(`JD keywords applied: ${data.enhancements.atsKeywords.slice(0, 10).join(', ')}`)
      }
      if (data.enhancements?.qaAnswerCount) {
        enhancementLines.push(`Your ${data.enhancements.qaAnswerCount} answer(s) were added to summary, skills, experience & projects`)
      }
      const detailBlock = [data.summary || '', enhancementLines.length ? enhancementLines.join('\n') : ''].filter(Boolean).join('\n\n')
      hist.push({
        role: 'assistant',
        content: `Resume downloaded: ${data.fileName || 'Resume-Tailored.pdf'}.\n\n${detailBlock}`,
        t: Date.now()
      })
      await saveChatHistory(hist)
      await paint()
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({ role: 'assistant', content: e.message || 'Could not generate resume.', t: Date.now() })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  // ── Inline validation for skills check (no browser popups) ──
  document.addEventListener('resume-skills-validation-failed', async (e) => {
    const message = String(e.detail?.message || '').trim()
    if (!message) return
    const h = await loadChatHistory()
    h.push({ role: 'assistant', content: message, t: Date.now() })
    await saveChatHistory(h)
    await paint()
    chatScroll.scrollTop = chatScroll.scrollHeight
  })

  // ── Listens for the Generate button inside the skillsCheck card ──
  document.addEventListener('resume-skills-confirmed', async (e) => {
    const pending = _pendingTailorDownload
    if (!pending) return

    const skillsData = e.detail || {}
    const questions = buildTailorGapQuestions({
      pageContext: pending.pageContext,
      resumeContext: pending.resumeContext,
      skillsData,
    })

    if (questions.length === 0) {
      await _doTailorDownload(pending, {
        answers: skillsData.answers || [],
        extraNote: [
          skillsData.extraNote,
          skillsData.experienceGapNote
            ? `Experience context: ${skillsData.experienceGapNote}`
            : '',
        ].filter(Boolean).join('\n\n'),
        qaAnswers: [],
      })
      _pendingTailorDownload = null
      return
    }

    _aiResumeFlow = {
      pending,
      skillsData,
      questions,
      currentIndex: 0,
      answers: [],
    }

    const reply = async (content) => {
      const h = await loadChatHistory()
      h.push({ role: 'assistant', content, t: Date.now() })
      await saveChatHistory(h)
      await paint()
    }

    const yesCount = (skillsData.answers || []).filter((a) => a.hasIt).length
    const skillList = (skillsData.answers || []).filter((a) => a.hasIt).map((a) => a.skill).join(', ')
    const intro = yesCount
      ? `Skills noted — I'll add **${skillList}** to your resume.\n\nNow ${questions.length} separate questions about experience & fit (not repeating the skill check):`
      : `Now ${questions.length} questions about your experience & fit for this role (separate from the skill check):`

    await reply(intro)
    await reply(`**1.** ${questions[0]}`)
  })

  const runTailorResumeDirectDownload = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) { await pushAssistantMessage('Not signed in.'); return }

    const pageContext = await fetchPageContext()
    const careerBase = normalizeVppoApiBase(
      mainSession.careerApiBase || (await chrome.storage.local.get('careerApiBase')).careerApiBase,
      DEFAULT_CAREER_API_BASE
    )
    let token = authToken

    // Push user message
    const history = await loadChatHistory()
    history.push({ role: 'user', content: 'Generate AI-optimized resume for this job', display: 'AI Resume & Download', t: Date.now() })
    await saveChatHistory(history)
    await paint()

    isSending = true; sendBtn.disabled = true; setQuickChipsDisabled(true)
    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Checking your ATS score…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    let resumeContext = null
    let atsResult = null
    try {
      // Fetch primary resume extractedJson
      try {
        let primaryRes = await fetch(`${careerBase}/candidates/profile/resume/primary`, {
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }
        })
        if (primaryRes.status === 401) {
          const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
          if (refreshed?.success) {
            const stored = await chrome.storage.local.get('authToken')
            token = stored.authToken
            if (token) {
              primaryRes = await fetch(`${careerBase}/candidates/profile/resume/primary`, {
                headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }
              })
            }
          }
        }
        if (primaryRes.ok) {
          const payload = await primaryRes.json().catch(() => ({}))
          if (payload?.data?.extractedJson) resumeContext = payload.data.extractedJson
        }
      } catch { /* fall through */ }

      // Fetch ATS Score
      try {
        const atsRes = await fetch(`${careerBase}/candidates/career/ai/batch-ats-score`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            jobs: [{
              jobId: pageContext?.jobId || 'current_job',
              title: pageContext?.jobTitle || 'Role',
              company: pageContext?.company || 'Company',
              description: pageContext?.jobDescription || '',
              skills: pageContext?.jobSkills || '',
              experience: ''
            }]
          })
        })
        if (atsRes.ok) {
          const atsData = await atsRes.json().catch(() => ({}))
          if (atsData?.results?.length) {
            atsResult = atsData.results[0]
          }
        }
      } catch (err) {
        console.error('ATS score check failed', err)
      }

      document.getElementById('thinkingBubble')?.remove()

      if (atsResult) {
        const histScore = await loadChatHistory()
        histScore.push({
          role: 'assistant',
          content: `Checked ATS Match Score: **${atsResult.score}%**\n\n_${atsResult.summary || ''}_`,
          t: Date.now()
        })
        await saveChatHistory(histScore)
        await paint()
      }

      // Find skills in the JD that are not in the resume
      const jdText = String(pageContext?.jobDescription || '')
      const jdSkills = extractJdTechSkills(jdText)
      const resumeSkills = extractResumeSkillNames(resumeContext)
      let missingSkills = findMissingSkills(jdSkills, resumeSkills)

      if (missingSkills.length === 0) {
        // Fallback to top 5 JD skills if none are flagged as missing, to ALWAYS show the skills selection card first
        missingSkills = jdSkills.slice(0, 5)
      }

      if (missingSkills.length === 0) {
        // Ultimate fallback to generic key requirements if jdSkills is also empty
        missingSkills = ['Technical Consultant', 'System Integration', 'Requirements Gathering', 'Client Communication', 'Consulting']
      }

      // Show Q&A card — store pending state and wait for user answers
      _pendingTailorDownload = { pageContext, resumeContext, token }
      const jdExperience = extractJdExperienceRequirement(jdText)
      const resumeExperience = extractResumeExperienceSummary(resumeContext)
      const jdYears = parseExperienceYearsMin(jdExperience)
      const resumeYears = parseExperienceYearsMin(resumeExperience)
      const experienceGapRequired = jdYears > 0 && resumeYears > 0 && resumeYears < jdYears
      const hist2 = await loadChatHistory()
      hist2.push({
        role: 'assistant',
        content: `Quick check: mark skills from the JD that are missing on your resume. If **Yes**, say where you used each skill. Then I'll ask up to 5 separate questions about experience & achievements.`,
        ui: {
          type: 'skillsCheck',
          data: {
            missingSkills,
            jobTitle: pageContext?.jobTitle,
            company: pageContext?.company,
            jdExperience,
            resumeExperience,
            experienceGapRequired,
          },
        },
        t: Date.now()
      })
      await saveChatHistory(hist2)
      await paint()
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({ role: 'assistant', content: e.message || 'ATS score or check failed.', t: Date.now() })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  const runAiOptimizeResumeDirect = async () => {
    if (isSending) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }

    const pageContext = await fetchPageContext()
    const jobDescription = String(pageContext?.jobDescription || '').trim()
    if (!pageLooksLikeJob(pageContext) || jobDescription.length < 80) {
      await pushAssistantMessage('Open a job posting page with a full job description first.')
      return
    }

    const jobTitle = String(pageContext?.jobTitle || pageContext?.title || '').trim()
    const companyName = String(pageContext?.company || '').trim()
    const history = await loadChatHistory()
    history.push({
      role: 'user',
      content: `AI resume for ${[jobTitle, companyName].filter(Boolean).join(' at ') || 'this job'}`,
      display: 'AI resume',
      t: Date.now()
    })
    await saveChatHistory(history)
    await paint()

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Optimizing resume for this job…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)
    try {
      const careerBase = normalizeVppoApiBase(
        mainSession.careerApiBase || (await chrome.storage.local.get('careerApiBase')).careerApiBase,
        DEFAULT_CAREER_API_BASE
      )
      const stored = await chrome.storage.local.get('dashboardUrl')
      const dashboardUrl = `${stored.dashboardUrl || DEFAULT_DASHBOARD_URL}/candidate/profile/resume-upload`

      const authFetch = async (path, options = {}) => {
        let token = authToken
        let res = await fetch(`${careerBase}${path}`, {
          ...options,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
            ...(options.headers || {})
          }
        })
        if (res.status === 401) {
          const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
          if (refreshed?.success) {
            const t2 = await chrome.storage.local.get('authToken')
            token = t2.authToken
            if (token) {
              res = await fetch(`${careerBase}${path}`, {
                ...options,
                headers: {
                  'Content-Type': 'application/json',
                  Authorization: `Bearer ${token}`,
                  ...(options.headers || {})
                }
              })
            }
          }
          if (res.status === 401) {
            await handleUnauthorizedError()
          }
        }
        return res
      }

      const primaryRes = await authFetch('/candidates/profile/resume/primary')
      const primaryPayload = await primaryRes.json().catch(() => ({}))
      if (!primaryRes.ok || !primaryPayload?.data) {
        throw new Error(
          primaryPayload.message ||
            'No primary resume found. Upload one in Profile → My Resumes on the dashboard.'
        )
      }

      const extracted = primaryPayload.data.extractedJson
      const resumeData = extractionToResumeData(extracted)
      if (!resumeData) {
        throw new Error(
          'Primary resume has no structured data yet. Open Resume Editor on the dashboard once, or re-upload your resume.'
        )
      }

      const enhanceRes = await authFetch('/candidates/profile/resume/enhance', {
        method: 'POST',
        body: JSON.stringify({ jobDescription, resumeData })
      })
      const enhancePayload = await enhanceRes.json().catch(() => ({}))
      if (!enhanceRes.ok || !enhancePayload?.success || !enhancePayload?.data) {
        throw new Error(
          enhancePayload.message || `Resume optimization failed (${enhanceRes.status})`
        )
      }

      const merged = applyOptimizeToResumeData(resumeData, enhancePayload.data)
      const extractedJson = resumeDataToExtractedJson(merged)

      let savedFileName = ''
      const saveRes = await authFetch('/candidates/profile/resume/save-new', {
        method: 'POST',
        body: JSON.stringify({ extractedJson })
      })
      const savePayload = await saveRes.json().catch(() => ({}))
      if (saveRes.ok && savePayload?.data?.fileName) {
        savedFileName = savePayload.data.fileName
      }

      const skillNames = (merged.skills || []).map((s) => s.name).filter(Boolean).slice(0, 12)
      const expHighlights = []
      for (const exp of merged.experience || []) {
        const bullets = (exp.bullets || []).filter(Boolean).slice(0, 2)
        if (bullets.length) {
          expHighlights.push({
            role: exp.role,
            company: exp.company,
            bullets
          })
        }
        if (expHighlights.length >= 2) break
      }

      document.getElementById('thinkingBubble')?.remove()
      history.push({
        role: 'assistant',
        content: savedFileName
          ? `Resume optimized for this job and saved as ${savedFileName}.`
          : 'Resume optimized for this job.',
        ui: {
          type: 'aiResume',
          data: {
            jobTitle,
            companyName,
            title: merged.title || '',
            summaryPreview: String(merged.summary || '').slice(0, 320),
            skillNames,
            experienceHighlights: expHighlights,
            savedFileName,
            dashboardUrl,
            providerUsed: enhancePayload.providerUsed || ''
          }
        },
        t: Date.now()
      })
      await saveChatHistory(history)
      await paint()
    } catch (e) {
      document.getElementById('thinkingBubble')?.remove()
      const errHist = await loadChatHistory()
      errHist.push({
        role: 'assistant',
        content: e.message || 'AI resume optimization failed.',
        t: Date.now()
      })
      await saveChatHistory(errHist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  window.downloadCandidateResume = downloadCandidateResumeFile

  const paint = async () => {
    if (!chatScroll) return
    const history = await loadChatHistory()
    chatScroll.innerHTML = ''
    if (history.length === 0) {
      const hint = document.createElement('div')
      hint.className = 'bubble system'
      hint.textContent = 'Ask KareerGrowth anything, or tap a quick action below.'
      chatScroll.appendChild(hint)
    } else if (window.ChatUi) {
      for (const m of history) {
        window.ChatUi.appendMessageBubble(m, chatScroll)
      }
    } else {
      const _mdToHtml = (text) => {
        if (!text) return '';
        let s = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        s = s.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
        s = s.replace(/\*([^*\n]+)\*/g, '<strong>$1</strong>');
        s = s.replace(/_([^_\n]+)_/g, '<em>$1</em>');
        s = s.replace(/\n/g, '<br>');
        return s;
      };
      for (const m of history) {
        const el = document.createElement('div')
        el.className = `bubble ${m.role === 'user' ? 'user' : 'assistant'}`
        if (m.role === 'user') {
          el.textContent = m.display || m.content
        } else {
          el.innerHTML = _mdToHtml(m.display || m.content || '')
        }
        chatScroll.appendChild(el)
      }
    }
    chatScroll.scrollTop = chatScroll.scrollHeight
  }

  paint()

  const runPendingQuickAction = async () => {
    const { [PENDING_QUICK_ACTION_KEY]: pending } = await chrome.storage.local.get(
      PENDING_QUICK_ACTION_KEY
    )
    if (!pending) return
    await chrome.storage.local.remove(PENDING_QUICK_ACTION_KEY)
    if (pending.type === 'ats') await runAtsScoreDirect()
    else if (pending.type === 'tailor-download') await runTailorResumeDirectDownload()
    else if (pending.type === 'fill') await runFillFormDirect()
    else if (pending.type === 'jobs') await runJobSearchDirect()
    else if (pending.type === 'indeed-jobs') await runIndeedJobSearchDirect()
    else if (pending.type === 'naukri-jobs') await runNaukriJobSearchDirect()
    else if (pending.type === 'monster-jobs') await runMonsterJobSearchDirect()
    else if (pending.type === 'people') await runPeopleSearchDirect()
    else if (pending.type === 'pageJobs') await runPageJobsDirect()
    else if (pending.type === 'coverLetter') await runCoverLetterDirect()
    else if (pending.type === 'aiResume') await runAiOptimizeResumeDirect()
    else if (pending.type === 'message') await sendMessage(pending.message, pending.label)
  }

  // ── Conversational task creation flow ──────────────────────────────────────
  const advanceTaskFlow = async (userText) => {
    const flow = _taskFlow
    if (!flow) return

    const reply = async (content, ui) => {
      const h = await loadChatHistory()
      const entry = { role: 'assistant', content, t: Date.now() }
      if (ui) entry.ui = ui
      h.push(entry)
      await saveChatHistory(h)
      await paint()
    }

    const lowerText = userText.trim().toLowerCase()
    const cancel = ['cancel', 'stop', 'abort', 'quit', 'exit', 'ignore it', 'no need to create task', 'i dont want to create task'].includes(lowerText)
    if (cancel) {
      _taskFlow = null
      await reply('Ok , sure i have canceld the creating task.')
      return
    }

    if (flow.step === 'title_and_description') {
      const text = userText.trim()
      if (!text) { await reply('Please provide that details properly.'); return }
      
      let title = text
      let description = text
      
      if (/(this|that|the|current|from|add|use|copy|look)\s*(page|link|url|job)/i.test(text)) {
        try {
          const pageCtx = await fetchPageContext()
          if (pageCtx && (pageCtx.jobTitle || pageCtx.title || pageCtx.url)) {
            const role = String(pageCtx.jobTitle || pageCtx.title || '').trim()
            const company = String(pageCtx.company || '').trim()
            const desc = String(pageCtx.jobDescription || pageCtx.description || '').trim()
            
            title = company && role ? `${role} - ${company}` : (role || text)
            description = desc || text
          }
        } catch (e) {
          // fallback
        }
      } else if (text.includes('\n')) {
         title = text.substring(0, text.indexOf('\n')).trim()
         description = text.substring(text.indexOf('\n') + 1).trim()
      } else if (text.includes(' - ')) {
         title = text.substring(0, text.indexOf(' - ')).trim()
         description = text.substring(text.indexOf(' - ') + 3).trim()
      }
      
      flow.title = title || text
      flow.description = description || text
      flow.step = 'priority'
      await reply(
        `Got it! What is the priority for "${flow.title}"?`,
        { type: 'taskFlowOptions', data: { options: ['Low', 'Medium', 'High'] } }
      )

    } else if (flow.step === 'priority') {
      const map = { low: 'Low', medium: 'Medium', high: 'High' }
      flow.priority = map[userText.trim().toLowerCase()] || 'Medium'
      flow.step = 'deadline'
      await reply(
        `When is the deadline for "${flow.title}"?`,
        { type: 'taskFlowDateInput', data: {} }
      )

    } else if (flow.step === 'deadline') {
      let d = userText.trim()
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(d)) {
        const [dd, mm, yyyy] = d.split('/'); d = `${yyyy}-${mm}-${dd}`
      }
      if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) {
        await reply(
          'Please pick a deadline date.',
          { type: 'taskFlowDateInput', data: {} }
        ); return
      }
      flow.deadline = d
      flow.step = 'link'
      await reply('Do you have any reference link to add? Paste the URL or type "no".')

    } else if (flow.step === 'link') {
      const lowerText = userText.trim().toLowerCase()
      const noLink = ['no', 'n', 'nope', 'none', 'skip', '-', 'na'].includes(lowerText)
      
      if (/(this|that|the|current|from|add|use|copy|look)\s*(page|link|url|job)/i.test(lowerText) && !lowerText.includes('http')) {
        try {
          const pageCtx = await fetchPageContext()
          flow.link = pageCtx?.url || userText.trim()
        } catch (e) {
          flow.link = userText.trim()
        }
      } else {
        flow.link = noLink ? '' : userText.trim()
      }
      
      flow.step = 'confirm'
      let summary = `Here's the task I'll create:\n\nTitle: ${flow.title}\nDescription: ${flow.description}\nPriority: ${flow.priority}\nDeadline: ${flow.deadline}`
      if (flow.link) summary += `\nLink: ${flow.link}`
      summary += '\n\nConfirm to create this task?'
      await reply(summary, { type: 'taskFlowOptions', data: { options: ['Yes', 'No'] } })

    } else if (flow.step === 'confirm') {
      const yes = ['yes', 'y', 'confirm', 'ok', 'yeah', 'yep', 'sure'].includes(userText.trim().toLowerCase())
      const saved = { ...flow }
      _taskFlow = null
      if (!yes) { await reply('Task creation cancelled.'); return }
      isSending = true; sendBtn.disabled = true; setQuickChipsDisabled(true)
      try {
        const { res, data } = await careerApiFetch('/candidates/self-tasks', {
          method: 'POST',
          body: JSON.stringify({ title: saved.title, description: saved.description, deadline: saved.deadline, link: saved.link || undefined, priority: saved.priority })
        })
        if (res.ok || res.status === 201) {
          await reply(`Task "${saved.title}" created! Deadline: ${saved.deadline}.`)
        } else {
          await reply(data?.message || 'Failed to create task. Please try again.')
        }
      } catch (err) {
        await reply(err.message || 'Error creating task.')
      } finally {
        isSending = false; sendBtn.disabled = false; setQuickChipsDisabled(false)
      }
    }
  }

  document.addEventListener('task-flow-reply', (e) => {
    if (e.detail?.text) sendMessage(e.detail.text)
  })

  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

  async function openAndScrapeJobUrl(url) {
    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)

    const chatScroll = document.getElementById('chatScroll')
    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = 'Opening and scraping job details...'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    try {
      const tab = await chrome.tabs.create({ url, active: true })
      
      // Poll tab status to wait until it completes loading (up to 10 seconds)
      let loaded = false
      for (let i = 0; i < 10; i++) {
        await delay(1000)
        const currentTab = await chrome.tabs.get(tab.id)
        if (currentTab.status === 'complete') {
          loaded = true
          break
        }
      }
      // Extra delay for DOM rendering / scripts
      await delay(1500)

      const pageCtxResp = await chrome.runtime.sendMessage({ type: 'GET_ACTIVE_PAGE_CONTEXT' })
      document.getElementById('thinkingBubble')?.remove()

      if (pageCtxResp?.success && pageCtxResp.pageContext) {
        const pc = pageCtxResp.pageContext
        const title = pc.jobTitle || pc.title || 'Untitled Role'
        const company = pc.company || 'Unknown Company'
        const description = pc.jobDescription || ''

        // Show scraped message
        const hist = await loadChatHistory()
        
        // Add to tracker
        const trackerResp = await chrome.runtime.sendMessage({
          type: 'ADD_TO_TRACKER',
          payload: {
            sourceUrl: url,
            title: title,
            company: company,
            location: pc.location || '',
            description: description,
            source: 'extension'
          }
        })

        const addedMsg = trackerResp?.success && !trackerResp.duplicate
          ? `Added **${title}** at **${company}** to your tracker!`
          : `Found **${title}** at **${company}** (already present in your tracker).`

        hist.push({
          role: 'assistant',
          content: `I've successfully opened the page and scraped the job details!\n\n${addedMsg}`,
          t: Date.now()
        })

        // Fetch ATS Score
        let atsResult = null
        try {
          const { res: atsRes, data: atsData } = await careerApiFetch(`/candidates/career/ai/batch-ats-score`, {
            method: 'POST',
            body: JSON.stringify({
              jobs: [{
                jobId: 'current_job',
                title: title,
                company: company,
                description: description,
                skills: pc.jobSkills || '',
                experience: ''
              }]
            })
          })
          if (atsRes.ok && atsData?.results?.length) {
            atsResult = atsData.results[0]
          }
        } catch (err) {
          console.error('ATS evaluation error:', err)
        }

        if (atsResult) {
          hist.push({
            role: 'assistant',
            content: `Here is the ATS Match Analysis for your resume against this job:`,
            ui: { type: 'ats', data: atsResult },
            t: Date.now() + 1
          })
        }

        await saveChatHistory(hist)
        await paint()
      } else {
        const hist = await loadChatHistory()
        hist.push({
          role: 'assistant',
          content: `Opened the page but could not automatically scrape the job details. Please make sure the job page is fully loaded and visible in your browser.`,
          t: Date.now()
        })
        await saveChatHistory(hist)
        await paint()
      }
    } catch (err) {
      document.getElementById('thinkingBubble')?.remove()
      const hist = await loadChatHistory()
      hist.push({
        role: 'assistant',
        content: `Error opening or scraping the job link: ${err.message || err}`,
        t: Date.now()
      })
      await saveChatHistory(hist)
      await paint()
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  const sendMessage = async (prefilledText, displayLabel) => {
    const text = String(prefilledText ?? chatInput.value).trim()
    if (!text || isSending) return

    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      await pushAssistantMessage('Not signed in.')
      return
    }

    chatInput.value = ''
    const history = await loadChatHistory()
    history.push({
      role: 'user',
      content: text,
      display: displayLabel || undefined,
      t: Date.now()
    })
    await saveChatHistory(history)
    await paint()

    // --- Hook URL detection to scrape and ATS evaluate job postings ---
    const urlMatch = text.match(/(https?:\/\/[^\s]+)/i)
    if (urlMatch) {
      await openAndScrapeJobUrl(urlMatch[1])
      return
    }

    // --- Active conversational resume tailoring flow ---
    if (_aiResumeFlow) {
      await advanceAiResumeFlow(text)
      return
    }

    // --- Active conversational task creation flow ---
    if (_taskFlow) {
      await advanceTaskFlow(text)
      return
    }

    if (_trackerSearchFlow) {
      await advanceTrackerSearchFlow(text)
      return
    }

    const lowerText = text.toLowerCase().trim().replace(/[?.!,]/g, '')
    if (['good', 'thanks', 'thank you', 'great', 'awesome', 'nice'].includes(lowerText)) {
      const hist2 = await loadChatHistory()
      hist2.push({
        role: 'assistant',
        content: `Thank you! Let me know if there's anything else I can help you with.`,
        t: Date.now()
      })
      await saveChatHistory(hist2)
      await paint()
      return
    }

    if (wantsDirectTrackerSearch(text)) {
      isSending = true
      sendBtn.disabled = true
      setQuickChipsDisabled(true)
      
      const thinking = document.createElement('div')
      thinking.className = 'bubble assistant'
      thinking.textContent = 'Searching your tracker...'
      thinking.id = 'thinkingBubble'
      chatScroll.appendChild(thinking)
      chatScroll.scrollTop = chatScroll.scrollHeight

      const query = extractSearchQuery(text)
      
      try {
        const { res, data } = await careerApiFetch(`/candidates/tracker?limit=50&tab=all&search=${encodeURIComponent(query)}`)
        document.getElementById('thinkingBubble')?.remove()
        
        const reply = async (content, ui) => {
          const h = await loadChatHistory()
          const entry = { role: 'assistant', content, t: Date.now() }
          if (ui) entry.ui = ui
          h.push(entry)
          await saveChatHistory(h)
          await paint()
        }

        if (res.ok && data?.jobs?.length) {
          const jobs = data.jobs
          let html = `Found ${jobs.length} matching job(s) in your tracker:<br><br>`
          const storedDb = await chrome.storage.local.get('dashboardUrl')
          const dashUrl = normalizeVppoApiBase(
            mainSession.dashboardUrl || storedDb.dashboardUrl,
            DEFAULT_VPPO_APP_BASE
          )
          for (const job of jobs) {
            let skills = job.skills
            if (!skills && job.description) {
              const jdSkills = extractJdTechSkills(job.description)
              if (jdSkills.length > 0) {
                skills = jdSkills.slice(0, 5).join(', ')
              }
            }
            if (!skills) {
              skills = 'N/A'
            }

            html += `<strong>${job.company || 'N/A'}</strong> - ${job.title || 'Untitled Role'}<br>`
            html += `Match Score: ${job.matchPercent != null ? job.matchPercent + '%' : 'N/A'}<br>`
            html += `Required Skills: ${skills}<br>`
            html += `<div style="display: flex; gap: 8px; margin-top: 6px; margin-bottom: 12px;">`
            if (job.sourceUrl) {
              html += `<a href="${job.sourceUrl}" target="_blank" style="flex: 1; text-align: center; background: #2563eb; color: #ffffff; padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: bold; text-decoration: none; display: inline-block;">Job Link</a>`
            }
            html += `<a href="${dashUrl}/candidate/tracker" target="_blank" style="flex: 1; text-align: center; background: transparent; border: 1px solid #2563eb; color: #2563eb; padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: bold; text-decoration: none; display: inline-block;">Open Tracker</a>`
            html += `</div>`
          }
          await reply(html, { type: 'html', data: html })
        } else {
          await reply(`No jobs found in your tracker matching "${query}".`)
        }
      } catch (err) {
        document.getElementById('thinkingBubble')?.remove()
        const h = await loadChatHistory()
        h.push({ role: 'assistant', content: 'Error searching tracker jobs.', t: Date.now() })
        await saveChatHistory(h)
        await paint()
      } finally {
        isSending = false
        sendBtn.disabled = false
        setQuickChipsDisabled(false)
      }
      return
    }

    if (wantsCredits(text)) {
      isSending = true
      sendBtn.disabled = true
      setQuickChipsDisabled(true)
      const fetchingBubble = document.createElement('div')
      fetchingBubble.className = 'bubble assistant'
      fetchingBubble.textContent = 'Fetching your credit usage…'
      fetchingBubble.id = 'thinkingBubble'
      chatScroll.appendChild(fetchingBubble)
      chatScroll.scrollTop = chatScroll.scrollHeight
      try {
        const { res, data } = await careerApiFetch(`/candidates/limits`)
        document.getElementById('thinkingBubble')?.remove()
        if (res.ok && data) {
          const hist2 = await loadChatHistory()
          const creditsText = `Credits Usage:\n` +
            `• **Cover Letter**: ${data.usage?.usedCoverLetter ?? 0}/${data.limits?.coverLetterPerDay ?? 5}\n` +
            `• **Resume Builder**: ${data.usage?.usedResume ?? 0}/${data.limits?.resumePerMonth ?? 10}\n` +
            `• **AI Mock Interview**: ${data.usage?.usedMockInterview ?? 0}/${data.limits?.mockInterviewPerDay ?? 2}\n` +
            `• **Salary Negotiator**: ${data.usage?.usedNegotiator ?? 0}/${data.limits?.negotiatorPerDay ?? 10}\n` +
            `• **LinkedIn Influencer**: ${data.usage?.usedInfluencer ?? 0}/${data.limits?.influencerPerMonth ?? 15}`
          
          hist2.push({
            role: 'assistant',
            content: creditsText,
            t: Date.now()
          })
          await saveChatHistory(hist2)
          await paint()
        } else {
          const errBubble = document.createElement('div')
          errBubble.className = 'bubble assistant'
          errBubble.textContent = 'Could not load credits. Please try again.'
          chatScroll.appendChild(errBubble)
          chatScroll.scrollTop = chatScroll.scrollHeight
        }
      } catch (err) {
        document.getElementById('thinkingBubble')?.remove()
        const errBubble = document.createElement('div')
        errBubble.className = 'bubble assistant'
        errBubble.textContent = 'Error loading credits.'
        chatScroll.appendChild(errBubble)
        chatScroll.scrollTop = chatScroll.scrollHeight
      } finally {
        isSending = false
        sendBtn.disabled = false
        setQuickChipsDisabled(false)
      }
      return
    }

    if (wantsTrackerJobs(text)) {
      isSending = true
      sendBtn.disabled = true
      setQuickChipsDisabled(true)
      const fetchingBubble = document.createElement('div')
      fetchingBubble.className = 'bubble assistant'
      fetchingBubble.textContent = 'Fetching tracker jobs…'
      fetchingBubble.id = 'thinkingBubble'
      chatScroll.appendChild(fetchingBubble)
      chatScroll.scrollTop = chatScroll.scrollHeight
      try {
        const { res, data } = await careerApiFetch(`/candidates/tracker/stats`)
        document.getElementById('thinkingBubble')?.remove()
        if (res.ok && data?.success) {
          const counts = data.stats?.stagesAll || {}
          _trackerSearchFlow = { step: 'search_query' }
          const hist2 = await loadChatHistory()
          hist2.push({
            role: 'assistant',
            content: `Tracker Jobs count:\nSaved - ${counts.saved || 0}\nActive - ${counts.active || 0}\nClosed - ${counts.closed || 0}\nPreparing - ${counts.preparing || 0}\nApplied - ${counts.applied || 0}\n\nAny specific role or company name you are looking for?`,
            t: Date.now()
          })
          await saveChatHistory(hist2)
          await paint()
        } else {
          const errBubble = document.createElement('div')
          errBubble.className = 'bubble assistant'
          errBubble.textContent = 'Could not load tracker jobs. Please try again.'
          chatScroll.appendChild(errBubble)
          chatScroll.scrollTop = chatScroll.scrollHeight
        }
      } catch (err) {
        document.getElementById('thinkingBubble')?.remove()
        const errBubble = document.createElement('div')
        errBubble.className = 'bubble assistant'
        errBubble.textContent = 'Error loading tracker jobs.'
        chatScroll.appendChild(errBubble)
        chatScroll.scrollTop = chatScroll.scrollHeight
      } finally {
        isSending = false
        sendBtn.disabled = false
        setQuickChipsDisabled(false)
      }
      return
    }

    // --- Task list interception: answer from real API, skip AI ---
    if (wantsTaskList(text)) {
      isSending = true
      sendBtn.disabled = true
      setQuickChipsDisabled(true)
      const fetchingBubble = document.createElement('div')
      fetchingBubble.className = 'bubble assistant'
      fetchingBubble.textContent = 'Fetching your tasks…'
      fetchingBubble.id = 'thinkingBubble'
      chatScroll.appendChild(fetchingBubble)
      chatScroll.scrollTop = chatScroll.scrollHeight
      try {
        const filters = parseTaskFilters(text)
        filters.limit = 10
        filters.offset = 0
        const qs = '?' + new URLSearchParams(filters).toString()
        const { res: taskRes, data: taskData } = await careerApiFetch(`/candidates/self-tasks${qs}`)
        document.getElementById('thinkingBubble')?.remove()
        if (taskRes.ok || taskRes.status === 304) {
          const tasks = taskData.data || taskData.tasks || (Array.isArray(taskData) ? taskData : [])
          const hasMore = taskData.pagination?.hasMore || false
          const total = taskData.pagination?.total || tasks.length
          const label = taskFilterLabel(filters)
          const hist2 = await loadChatHistory()
          hist2.push({
            role: 'assistant',
            content: tasks.length
              ? `Found ${total} task(s)${label ? ' — ' + label : ''}.`
              : `No tasks found${label ? ' — ' + label : ''}.`,
            ui: { type: 'tasks', data: { tasks, filters, hasMore, total, offset: 0 } },
            t: Date.now()
          })
          await saveChatHistory(hist2)
          await paint()
        } else {
          const errBubble = document.createElement('div')
          errBubble.className = 'bubble assistant'
          errBubble.textContent = taskData?.message || 'Could not load tasks. Please try again.'
          chatScroll.appendChild(errBubble)
          chatScroll.scrollTop = chatScroll.scrollHeight
        }
      } catch (taskErr) {
        document.getElementById('thinkingBubble')?.remove()
        const errBubble = document.createElement('div')
        errBubble.className = 'bubble assistant'
        errBubble.textContent = taskErr.message || 'Error fetching tasks.'
        chatScroll.appendChild(errBubble)
        chatScroll.scrollTop = chatScroll.scrollHeight
      } finally {
        isSending = false
        sendBtn.disabled = false
        setQuickChipsDisabled(false)
      }
      return
    }

    // --- Add current page as task interception ---
    if (wantsPageTask(text)) {
      isSending = true; sendBtn.disabled = true; setQuickChipsDisabled(true)
      try {
        const pageCtx = await fetchPageContext()
        const pageTitle = String(pageCtx?.jobTitle || pageCtx?.title || '').trim()
        const pageUrl = String(pageCtx?.url || '').trim()
        if (!pageTitle && !pageUrl) {
          const hx = await loadChatHistory()
          hx.push({ role: 'assistant', content: "I couldn't detect any page content. Please navigate to a page first, then try again.", t: Date.now() })
          await saveChatHistory(hx)
          await paint()
          return
        }
        const rawDesc = pageCtx?.jobDescription || pageCtx?.description || ''
        const descSnippet = rawDesc ? rawDesc.slice(0, 400) + (rawDesc.length > 400 ? '...' : '') : ''
        const pageDesc = descSnippet || (pageCtx?.company ? `${pageTitle} at ${pageCtx.company}`.trim() : pageTitle)

        _taskFlow = {
          step: 'priority',
          title: pageTitle || pageUrl.slice(0, 80),
          description: pageDesc || `From: ${pageUrl}`,
          link: pageUrl,
          priority: 'Medium',
          deadline: ''
        }

        let preview = `I found this page:\n\nTitle: ${_taskFlow.title}`
        if (pageCtx?.company) preview += `\nSite: ${pageCtx.company}`
        if (descSnippet) preview += `\nAbout: ${descSnippet.slice(0, 180)}${descSnippet.length > 180 ? '...' : ''}`
        if (pageUrl) preview += `\nLink: ${pageUrl.slice(0, 80)}${pageUrl.length > 80 ? '...' : ''}`
        preview += '\n\nWhat priority should this task have?'

        const hx = await loadChatHistory()
        hx.push({
          role: 'assistant',
          content: preview,
          ui: { type: 'taskFlowOptions', data: { options: ['Low', 'Medium', 'High'] } },
          t: Date.now()
        })
        await saveChatHistory(hx)
        await paint()
      } finally {
        isSending = false; sendBtn.disabled = false; setQuickChipsDisabled(false)
      }
      return
    }

    // --- Add-task interception: start conversational flow, skip AI ---
    if (wantsTaskCreate(text)) {
      _taskFlow = { step: 'title_and_description', title: '', description: '', priority: 'Medium', deadline: '', link: '' }
      const hist3 = await loadChatHistory()
      hist3.push({ role: 'assistant', content: "Sure! What task do you need to create? Please provide the task title and description.", t: Date.now() })
      await saveChatHistory(hist3)
      await paint()
      return
    }

    const thinking = document.createElement('div')
    thinking.className = 'bubble assistant'
    thinking.textContent = '…'
    thinking.id = 'thinkingBubble'
    chatScroll.appendChild(thinking)
    chatScroll.scrollTop = chatScroll.scrollHeight

    isSending = true
    sendBtn.disabled = true
    setQuickChipsDisabled(true)
    try {
      const aiBase = await getAiChatApiBase()
      const candidateName = await getCandidateGreetingName(authToken)
      const agentMessages = buildAgentMessages(history, candidateName)

      const pageContext = await fetchPageContext()

      const agentBody = (token, sessionId, clientToolResults) => {
        const isContinuation = Boolean(sessionId && clientToolResults?.length)
        const payload = {
          messages: isContinuation
            ? [{ role: 'user', content: 'Continue with the tool results above.' }]
            : agentMessages
        }
        if (pageContext && !isContinuation) payload.pageContext = pageContext
        if (sessionId) payload.sessionId = sessionId
        if (clientToolResults?.length) payload.clientToolResults = clientToolResults
        return fetch(`${aiBase}/ai/agent/chat`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        })
      }

      let token = authToken
      let res = await agentBody(token, null, null)

      if (res.status === 401) {
        const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
        if (refreshed?.success) {
          const stored = await chrome.storage.local.get('authToken')
          token = stored.authToken
          if (token) res = await agentBody(token, null, null)
        }
        if (res.status === 401) {
          await handleUnauthorizedError()
        }
      }

      let data = await res.json().catch(() => ({}))

      let lastClientUi = null
      for (let guard = 0; guard < 4 && data.status === 'needs_client'; guard++) {
        const run = await chrome.runtime.sendMessage({
          type: 'RUN_AGENT_CLIENT_TOOLS',
          actions: (data.clientActions || []).map((a) => ({
            ...a,
            args:
              a.name === 'fill_job_application_form'
                ? {}
                : { ...(a.args || {}) }
          }))
        })
        const parsedUi = parseClientToolUi(run?.results)
        if (parsedUi) lastClientUi = parsedUi
        const clientToolResults = (run?.results || []).map((r) => ({
          toolCallId: r.toolCallId,
          name: r.name,
          result: typeof r.result === 'string' ? r.result : JSON.stringify(r.result),
        }))
        res = await agentBody(token, data.sessionId, clientToolResults)
        data = await res.json().catch(() => ({}))
        if (!res.ok) break
      }

      const tb = document.getElementById('thinkingBubble')
      if (tb) tb.remove()

      if (!res.ok || (data.success === false && !data.text)) {
        let msg = data.message || `Chat failed (${res.status})`
        if (data.issues?.fieldErrors) {
          const detail = Object.entries(data.issues.fieldErrors)
            .map(([k, v]) => `${k}: ${(v || []).join(', ')}`)
            .join('; ')
          if (detail) msg = `${msg} — ${detail}`
        }
        const errBubble = document.createElement('div')
        errBubble.className = 'bubble assistant'
        errBubble.textContent = msg
        chatScroll.appendChild(errBubble)
        chatScroll.scrollTop = chatScroll.scrollHeight
        return
      }

      if (data.download?.downloadToken) {
        try {
          await downloadTailoredResumeFile(
            aiBase,
            data.download.downloadToken,
            data.download.fileName,
            token
          )
        } catch (dlErr) {
          console.warn('[Extension] resume download', dlErr)
        }
      }

      let reply = typeof data.text === 'string' ? data.text : ''
      if (data.download?.fileName && !reply.includes('download')) {
        reply = `${reply}\n\nResume downloaded as PDF: ${data.download.fileName}.`.trim()
      }
      const uiPayload = data.ui || lastClientUi || undefined
      history.push({
        role: 'assistant',
        content: uiPayload
          ? clipText(
              uiPayload.type === 'jobs'
                ? summaryTextForClientSearch(uiPayload.data, 'jobs')
                : uiPayload.type === 'indeedJobs'
                  ? summaryTextForClientSearch(uiPayload.data, 'indeedJobs')
                  : uiPayload.type === 'naukriJobs'
                    ? summaryTextForClientSearch(uiPayload.data, 'naukriJobs')
                    : uiPayload.type === 'monsterJobs'
                      ? summaryTextForClientSearch(uiPayload.data, 'monsterJobs')
                      : uiPayload.type === 'people'
                    ? summaryTextForClientSearch(uiPayload.data, 'people')
                    : uiPayload.type === 'pageJobs'
                      ? summaryTextForPageJobs(uiPayload.data)
                      : uiPayload.data?.summary || reply || 'Results below.',
              1200
            )
          : clipText(reply || '(empty reply)'),
        ui: uiPayload,
        t: Date.now()
      })
      await saveChatHistory(history)
      await paint()
    } catch (e) {
      const tb2 = document.getElementById('thinkingBubble')
      if (tb2) tb2.remove()
      const errBubble = document.createElement('div')
      errBubble.className = 'bubble assistant'
      errBubble.textContent = e.message || 'Network error calling AI.'
      chatScroll.appendChild(errBubble)
      chatScroll.scrollTop = chatScroll.scrollHeight
    } finally {
      isSending = false
      sendBtn.disabled = false
      setQuickChipsDisabled(false)
    }
  }

  const send = () => sendMessage()

  if (sendBtn) sendBtn.addEventListener('click', send)
  if (chatInput) {
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault()
        send()
      }
    })
  }

  document.getElementById('clearChatBtn')?.addEventListener('click', async () => {
    await chrome.storage.local.remove(CHAT_HISTORY_KEY)
    await paint()
  })

  document.addEventListener('task-view-click', async () => {
    const { dashboardUrl } = await chrome.storage.local.get('dashboardUrl')
    const url = (dashboardUrl || 'https://candidate.systemmindz.com') + '/candidate/tracker'
    window.open(url, '_blank')
  })

  document.addEventListener('task-fetch-more', async (e) => {
    const { filters, currentOffset, msgTime } = e.detail || {}
    if (!msgTime) return
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) return

    try {
      const nextOffset = currentOffset + 10
      const fetchFilters = { ...filters, limit: 10, offset: nextOffset }
      const qs = '?' + new URLSearchParams(fetchFilters).toString()
      const { res: taskRes, data: taskData } = await careerApiFetch(`/candidates/self-tasks${qs}`)
      
      if (taskRes.ok || taskRes.status === 304) {
        const newTasks = taskData.data || taskData.tasks || (Array.isArray(taskData) ? taskData : [])
        const hasMore = taskData.pagination?.hasMore || false
        const total = taskData.pagination?.total || 0
        
        const hist = await loadChatHistory()
        const msgIdx = hist.findIndex(m => m.t === msgTime)
        if (msgIdx !== -1 && hist[msgIdx].ui?.type === 'tasks') {
          hist[msgIdx].ui.data.tasks = [...hist[msgIdx].ui.data.tasks, ...newTasks]
          hist[msgIdx].ui.data.hasMore = hasMore
          hist[msgIdx].ui.data.offset = nextOffset
          hist[msgIdx].ui.data.total = total
          await saveChatHistory(hist)
          await paint()
        }
      }
    } catch (err) {
      console.warn('Failed to fetch more tasks', err)
    }
  })

  setTimeout(() => void runPendingQuickAction(), 150)
}

document.getElementById('headerProfileBtn')?.addEventListener('click', async () => {
  const { authToken } = await chrome.storage.local.get('authToken')
  if (!authToken) return
  activeView = 'profile'
  await renderProfile()
})

document.getElementById('headerNewChatBtn')?.addEventListener('click', async () => {
  await chrome.storage.local.remove(CHAT_HISTORY_KEY)
  void render()
})

document.getElementById('headerSyncBtn')?.addEventListener('click', async () => {
  const btn = document.getElementById('headerSyncBtn')
  if (!btn || btn.classList.contains('syncing')) return
  btn.classList.add('syncing')
  await runLinkedInSyncWithConflictFlow()
  setTimeout(async () => {
    await refreshSyncToolbar()
    btn.classList.remove('syncing')
  }, 1600)
})

async function getCareerApiBaseFromStorage() {
  const { careerApiBase } = await chrome.storage.local.get('careerApiBase')
  return normalizeVppoApiBase(careerApiBase || DEFAULT_CAREER_API_BASE, DEFAULT_CAREER_API_BASE)
}

/** Same as ConnectionLeadsGrid on /candidate/connections */
let cachedResumeContextForAi = null

function targetCompanyForAi(profile) {
  const direct = String(profile?.company || '').trim()
  if (direct) return direct
  const headline = String(profile?.headline || '').trim()
  if (!headline) return ''
  const atMatch = headline.match(/\s+at\s+(.+)$/i)
  if (atMatch) {
    const rest = atMatch[1].split(/[·•|]/)[0].trim()
    if (rest) return rest
  }
  const parts = headline.split(/[·•]/).map((s) => s.trim()).filter(Boolean)
  if (parts.length > 1) {
    const last = parts[parts.length - 1]
    if (last && last.length <= 120) return last
  }
  return ''
}

async function fetchResumeContextForAi() {
  if (cachedResumeContextForAi) return cachedResumeContextForAi
  const base = await getCareerApiBaseFromStorage()
  const { authToken } = await chrome.storage.local.get('authToken')
  if (!authToken) return null

  const get = (token) =>
    fetch(`${base}/candidates/career/resume-context`, {
      headers: { Authorization: `Bearer ${token}` }
    })

  let res = await get(authToken)
  if (res.status === 401) {
    const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
    if (refreshed?.success) {
      const stored = await chrome.storage.local.get('authToken')
      if (stored.authToken) res = await get(stored.authToken)
    }
    if (res.status === 401) {
      await handleUnauthorizedError()
    }
  }

  const data = await res.json().catch(() => ({}))
  if (!res.ok || !data?.success) return null
  cachedResumeContextForAi = data
  return data
}

function resumeContextPayloadForAi(resumeCtx) {
  if (!resumeCtx?.hasResume || !resumeCtx.extraction) return {}
  const ex = resumeCtx.extraction
  return {
    summary: ex.summary,
    skills: ex.skills,
    experience: ex.experience,
    education: ex.education,
    projects: ex.projects
  }
}

/** POST /api/candidates/career/ai/linkedin-connection-note → backend-ai (same as dashboard) */
async function generateConnectionNoteForProfile(profile) {
  const base = await getCareerApiBaseFromStorage()
  const { authToken } = await chrome.storage.local.get('authToken')
  if (!authToken) throw new Error('Not signed in')

  const resumeCtx = await fetchResumeContextForAi()
  const company = targetCompanyForAi(profile)
  const body = {
    ...(company ? { targetCompany: company } : {}),
    targetName: profile.displayName || undefined,
    targetTitle: profile.headline || undefined,
    targetPublicIdentifier: profile.publicIdentifier,
    resumeContext: resumeContextPayloadForAi(resumeCtx)
  }

  const post = (token) =>
    fetch(`${base}/candidates/career/ai/linkedin-connection-note`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(body)
    })

  let res = await post(authToken)
  if (res.status === 401) {
    const refreshed = await chrome.runtime.sendMessage({ type: 'REFRESH_PLATFORM_TOKEN' })
    if (refreshed?.success) {
      const stored = await chrome.storage.local.get('authToken')
      if (stored.authToken) res = await post(stored.authToken)
    }
    if (res.status === 401) {
      await handleUnauthorizedError()
    }
  }

  const data = await res.json().catch(() => ({}))
  if (!res.ok || !data.success || !data.connectionNote) {
    throw new Error(data.message || 'AI did not return a note')
  }
  return String(data.connectionNote).slice(0, 280)
}

async function sendLinkedInConnectionFromPopup(publicIdentifier, message) {
  const slug = String(publicIdentifier || '').replace(/^\/+|\/+$/g, '')
  if (!slug) return { success: false, error: 'Missing profile id' }
  return chrome.runtime.sendMessage({
    type: 'SEND_CONNECTION_REQUEST',
    payload: { publicIdentifier: slug, message: message || '' }
  })
}

if (window.ChatUi?.setConnectionHandlers) {
  window.ChatUi.setConnectionHandlers({
    onAiNote: (profile) => generateConnectionNoteForProfile(profile),
    onConnect: (profile, message) =>
      sendLinkedInConnectionFromPopup(profile.publicIdentifier, message)
  })
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return
  if (changes.linkedinStatus || changes.lastSync) {
    void refreshSyncToolbar()
  }
})

void render()
