/* global window */
/**
 * Rich chat cards for structured assistant responses (ATS, tailor, resumes).
 */

function scoreColor(score) {
  const s = Number(score) || 0
  if (s >= 75) return '#22c55e'
  if (s >= 50) return '#eab308'
  return '#3b82f6'
}

function el(tag, className, text) {
  const node = document.createElement(tag)
  if (className) node.className = className
  if (text != null && text !== '') node.textContent = text
  return node
}

let connectionHandlers = null

function setConnectionHandlers(handlers) {
  connectionHandlers = handlers || null
}

function applyNameTemplate(template, displayName) {
  const name = String(displayName || '').trim().split(/\s+/)[0] || 'there'
  return String(template || '')
    .replace(/\{name\}/gi, name)
    .replace(/\{firstName\}/gi, name)
    .trim()
}

function chipList(items, className) {
  const wrap = el('div', `chip-list ${className || ''}`)
  const list = Array.isArray(items) ? items : []
  if (!list.length) {
    wrap.appendChild(el('span', 'chip-empty', 'None'))
    return wrap
  }
  for (const item of list.slice(0, 24)) {
    wrap.appendChild(el('span', 'chip', String(item)))
  }
  return wrap
}

function bulletList(items, className) {
  const ul = el('ul', `ui-bullets ${className || ''}`)
  for (const item of (items || []).slice(0, 8)) {
    const li = el('li', '', String(item))
    ul.appendChild(li)
  }
  return ul
}

function buildAtsCard(data) {
  const card = el('div', 'ui-card ui-card-ats')
  const score = Math.round(Number(data?.score) || 0)
  const color = scoreColor(score)

  // ── Score banner ──────────────────────────────────────
  const banner = el('div', 'ats-banner')

  const scoreBox = el('div', 'ats-score-box')
  scoreBox.style.borderColor = color
  const scoreNum = el('span', 'ats-score-num', String(score))
  scoreNum.style.color = color
  scoreBox.appendChild(scoreNum)
  scoreBox.appendChild(el('span', 'ats-score-slash', '/100'))
  banner.appendChild(scoreBox)

  const bannerText = el('div', 'ats-banner-text')
  bannerText.appendChild(el('p', 'ats-title', 'ATS Match Score'))
  bannerText.appendChild(el('p', 'ats-summary', data?.summary || 'How your resume aligns with this job.'))
  banner.appendChild(bannerText)
  card.appendChild(banner)

  // Progress bar
  const barTrack = el('div', 'ats-bar-track')
  const barFill = el('div', 'ats-bar-fill')
  barFill.style.width = `${score}%`
  barFill.style.background = color
  barTrack.appendChild(barFill)
  card.appendChild(barTrack)

  // ── Matched keywords ──────────────────────────────────
  const matched = Array.isArray(data?.matchedKeywords) ? data.matchedKeywords : []
  if (matched.length) {
    const sec = el('div', 'ats-kw-section')
    sec.appendChild(el('p', 'ats-kw-label ats-kw-matched-label', '✓ Matched keywords'))
    const chips = el('div', 'ats-chips')
    for (const kw of matched.slice(0, 20)) chips.appendChild(el('span', 'ats-chip ats-chip-matched', kw))
    sec.appendChild(chips)
    card.appendChild(sec)
  }

  // ── Missing keywords ──────────────────────────────────
  const missing = Array.isArray(data?.missingKeywords) ? data.missingKeywords : []
  if (missing.length) {
    const sec = el('div', 'ats-kw-section')
    sec.appendChild(el('p', 'ats-kw-label ats-kw-missing-label', '⚠ Missing — add to resume if applicable'))
    const chips = el('div', 'ats-chips')
    for (const kw of missing.slice(0, 20)) chips.appendChild(el('span', 'ats-chip ats-chip-missing', kw))
    sec.appendChild(chips)
    card.appendChild(sec)
  }

  // ── Strengths ─────────────────────────────────────────
  if ((data?.strengths || []).length) {
    const sec = el('div', 'ats-list-section')
    sec.appendChild(el('p', 'ats-list-title', 'Strengths'))
    const ul = el('ul', 'ats-list')
    for (const item of data.strengths.slice(0, 5)) ul.appendChild(el('li', 'ats-list-item', item))
    sec.appendChild(ul)
    card.appendChild(sec)
  }

  // ── Gaps ──────────────────────────────────────────────
  if ((data?.gaps || []).length) {
    const sec = el('div', 'ats-list-section')
    sec.appendChild(el('p', 'ats-list-title ats-gaps-title', 'Gaps to address'))
    const ul = el('ul', 'ats-list')
    for (const item of data.gaps.slice(0, 5)) ul.appendChild(el('li', 'ats-list-item', item))
    sec.appendChild(ul)
    card.appendChild(sec)
  }

  return card
}

function buildTailorCard(data) {
  const card = el('div', 'ui-card ui-card-tailor')
  card.appendChild(el('h3', 'ui-card-title', 'Resume tailoring'))
  if (data?.summary) {
    const sec = el('div', 'ui-section')
    sec.appendChild(el('h4', 'ui-section-title', 'Summary'))
    sec.appendChild(el('p', 'ui-para', data.summary))
    card.appendChild(sec)
  }
  if ((data?.skillsToEmphasize || []).length) {
    const sec = el('div', 'ui-section')
    sec.appendChild(el('h4', 'ui-section-title', 'Emphasize'))
    sec.appendChild(chipList(data.skillsToEmphasize, 'matched-chips'))
    card.appendChild(sec)
  }
  if ((data?.skillsToAdd || []).length) {
    const sec = el('div', 'ui-section')
    sec.appendChild(el('h4', 'ui-section-title', 'Consider adding'))
    sec.appendChild(chipList(data.skillsToAdd, 'missing-chips'))
    card.appendChild(sec)
  }
  if ((data?.suggestedBullets || []).length) {
    const sec = el('div', 'ui-section')
    sec.appendChild(el('h4', 'ui-section-title', 'Suggested bullets'))
    sec.appendChild(bulletList(data.suggestedBullets))
    card.appendChild(sec)
  }
  return card
}

function buildJobsSearchCard(data, opts = {}) {
  const source = opts.source || data?.source || 'linkedin'
  const isIndeed = source === 'indeed'
  const isNaukri = source === 'naukri'
  const isMonster = source === 'monster'
  const card = el('div', 'ui-card ui-card-jobs')
  card.className = isIndeed
    ? 'ui-card ui-card-jobs ui-card-indeed-jobs'
    : isNaukri
      ? 'ui-card ui-card-jobs ui-card-naukri-jobs'
      : isMonster
        ? 'ui-card ui-card-jobs ui-card-monster-jobs'
        : 'ui-card ui-card-jobs'
  const head = el('div', 'ui-card-header')
  const headText = el('div', 'ui-card-headtext')
  headText.appendChild(
    el(
      'h3',
      'ui-card-title',
      isIndeed
        ? 'Indeed job matches'
        : isNaukri
          ? 'Naukri job matches'
          : isMonster
            ? 'Monster job matches'
            : 'LinkedIn job matches'
    )
  )
  const sub = [
    data?.savedToLibrary != null && data.savedToLibrary > 0
      ? `${data.savedToLibrary} new`
      : data?.totalFetched != null
        ? `${data.totalFetched} new`
        : '',
    data?.savedToLibrary != null ? `${data.savedToLibrary} saved to library` : '',
    data?.savedToTracker != null ? `${data.savedToTracker} saved to tracker` : '',
    data?.duplicatesSkipped > 0 ? `${data.duplicatesSkipped} skipped (already saved)` : '',
    data?.alreadyInTracker > 0 ? `${data.alreadyInTracker} already in tracker` : '',
    data?.searchesRemaining != null ? `${data.searchesRemaining} searches left today` : '',
  ]
    .filter(Boolean)
    .join(' · ')
  headText.appendChild(el('p', 'ui-card-sub', sub || data?.creditNote || ''))
  head.appendChild(headText)
  card.appendChild(head)

  if (data?.searchCriteria?.length) {
    for (const line of data.searchCriteria) {
      if (line?.label && line?.value) {
        card.appendChild(el('p', 'ui-para ui-meta-line', `${line.label}: ${line.value}`))
      }
    }
  } else if (data?.keywordsUsed) {
    const kwLabel = isNaukri ? 'Job title' : 'Keywords';
    card.appendChild(el('p', 'ui-para ui-meta-line', `${kwLabel}: ${data.keywordsUsed}`))
  }
  if (data?.savedToTracker > 0) {
    const trackerBox = el('div', 'ui-tracker-saved-box')
    const trackerTitle = el(
      'p',
      'ui-tracker-saved-title',
      `${data.savedToTracker} job${data.savedToTracker === 1 ? '' : 's'} saved to Application Tracker`
    )
    trackerBox.appendChild(trackerTitle)
    trackerBox.appendChild(
      el(
        'p',
        'ui-tracker-saved-hint',
        'Open your dashboard → Application Tracker to review and manage these roles.'
      )
    )
    card.appendChild(trackerBox)
  }
  if (data?.creditNote) {
    card.appendChild(el('p', 'ui-para ui-meta-line', data.creditNote))
  }

  const displayJobs = (data?.jobs || []).slice(0, 12)
  if (!displayJobs.length && (data?.duplicatesSkipped > 0 || data?.alreadyInTracker > 0)) {
    card.appendChild(
      el(
        'p',
        'ui-para ui-hint-line',
        isNaukri
          ? 'All matching jobs are already in your library or tracker — nothing new to show.'
          : 'All matching jobs are already saved — nothing new to show.'
      )
    )
  }

  const list = el('div', 'search-result-list')
  for (const j of displayJobs) {
    const row = el('div', 'search-result-row')
    const meta = el('div', 'search-result-meta')
    meta.appendChild(el('strong', '', j.title || 'Role'))
    const line = [j.company, j.location].filter(Boolean).join(' · ')
    if (line) meta.appendChild(el('span', 'resume-sub', line))
    if (j.salaryText || j.salary) {
      meta.appendChild(el('span', 'resume-sub', j.salaryText || j.salary))
    }
    if (j.isEasyApply) meta.appendChild(el('span', 'badge-pill badge-easy', 'Easy Apply'))
    if (j.isIndeedApply) meta.appendChild(el('span', 'badge-pill badge-indeed', 'Indeed Apply'))
    if (source === 'naukri') meta.appendChild(el('span', 'badge-pill badge-naukri', 'Naukri'))
    if (source === 'monster') meta.appendChild(el('span', 'badge-pill badge-monster', 'Monster'))
    row.appendChild(meta)
    if (j.jobUrl) {
      const a = el('a', 'btn-link', j.applyLabel || 'Open & apply')
      a.href = j.jobUrl
      a.target = '_blank'
      a.rel = 'noopener noreferrer'
      row.appendChild(a)
    }
    list.appendChild(row)
  }
  card.appendChild(list)

  if (data?.applyHowTo) {
    card.appendChild(el('p', 'ui-para ui-hint-line', data.applyHowTo))
  }
  return card
}

function buildPeopleSearchCard(data) {
  const card = el('div', 'ui-card ui-card-people')
  const headText = el('div', 'ui-card-headtext')
  headText.className = 'ui-card-headtext'
  headText.appendChild(el('h3', 'ui-card-title', 'People to connect with'))
  const sub = [
    data?.totalFetched != null ? `${data.totalFetched} found` : '',
    data?.savedToLibrary != null ? `${data.savedToLibrary} added to Connections` : '',
    data?.searchesRemaining != null ? `${data.searchesRemaining} searches left today` : '',
    data?.connectionsRemaining != null ? `${data.connectionsRemaining} invites left today` : ''
  ]
    .filter(Boolean)
    .join(' · ')
  headText.appendChild(el('p', 'ui-card-sub', sub || data?.creditNote || ''))
  card.appendChild(headText)

  if (data?.warning) {
    card.appendChild(el('p', 'ui-para ui-hint-line ui-warning', data.warning))
  }
  if (data?.creditNote) {
    card.appendChild(el('p', 'ui-para ui-meta-line', data.creditNote))
  }

  const profiles = Array.isArray(data?.profiles) ? data.profiles : []
  if (profiles.length && connectionHandlers) {
    card.appendChild(
      el(
        'p',
        'ui-para ui-meta-line',
        'Personalized notes use the same AI as Connections on your dashboard (review before sending).'
      )
    )

    const list = el('div', 'people-connect-list')
    for (const p of profiles.slice(0, 5)) {
      const row = el('div', 'people-connect-row')
      const top = el('div', 'people-connect-top')
      const meta = el('div', 'search-result-meta')
      meta.appendChild(el('strong', '', p.displayName || 'Profile'))
      const line = [p.headline, p.company].filter(Boolean).join(' · ')
      if (line) meta.appendChild(el('span', 'resume-sub', line))
      top.appendChild(meta)
      if (p.profileUrl) {
        const a = el('a', 'btn-link', 'Profile')
        a.href = p.profileUrl
        a.target = '_blank'
        a.rel = 'noopener noreferrer'
        top.appendChild(a)
      }
      row.appendChild(top)

      const noteInput = document.createElement('textarea')
      noteInput.className = 'people-invite-input'
      noteInput.maxLength = 280
      noteInput.rows = 3
      noteInput.placeholder = 'Generating personalized note…'
      noteInput.disabled = true
      row.appendChild(noteInput)

      const actions = el('div', 'people-connect-actions')
      const statusEl = el('span', 'people-connect-status', '')

      const runAiFill = async () => {
        if (!connectionHandlers?.onAiNote) return
        noteInput.disabled = true
        statusEl.textContent = 'Writing note…'
        statusEl.className = 'people-connect-status'
        try {
          const note = await connectionHandlers.onAiNote(p)
          noteInput.value = String(note || '').slice(0, 280)
          noteInput.disabled = false
          statusEl.textContent = note ? 'Note ready' : 'No note'
        } catch (e) {
          noteInput.placeholder = e?.message || 'AI note failed — tap Regenerate'
          noteInput.disabled = false
          statusEl.textContent = 'AI failed'
          statusEl.classList.add('err')
        }
      }

      void runAiFill()

      const aiBtn = el('button', 'btn-outline-sm', 'Regenerate')
      aiBtn.type = 'button'
      aiBtn.addEventListener('click', () => {
        void runAiFill()
      })

      const connectBtn = el('button', 'btn-connect-sm', 'Connect')
      connectBtn.type = 'button'
      connectBtn.addEventListener('click', async () => {
        if (!connectionHandlers?.onConnect || !p.publicIdentifier) return
        connectBtn.disabled = true
        aiBtn.disabled = true
        statusEl.textContent = 'Sending…'
        statusEl.className = 'people-connect-status'
        try {
          const out = await connectionHandlers.onConnect(p, noteInput.value.trim())
          if (out?.success) {
            statusEl.textContent = 'Sent'
            statusEl.classList.add('ok')
            connectBtn.textContent = 'Sent'
          } else {
            statusEl.textContent = formatConnectError(out?.error)
            statusEl.classList.add('err')
            connectBtn.disabled = false
            aiBtn.disabled = false
          }
        } catch (e) {
          statusEl.textContent = e?.message || 'Failed'
          statusEl.classList.add('err')
          connectBtn.disabled = false
          aiBtn.disabled = false
        }
      })

      actions.appendChild(aiBtn)
      actions.appendChild(connectBtn)
      actions.appendChild(statusEl)
      row.appendChild(actions)
      list.appendChild(row)
    }
    card.appendChild(list)
  } else if (profiles.length) {
    const list = el('div', 'search-result-list')
    for (const p of profiles.slice(0, 5)) {
      const row = el('div', 'search-result-row')
      const meta = el('div', 'search-result-meta')
      meta.appendChild(el('strong', '', p.displayName || 'Profile'))
      const line = [p.headline, p.company].filter(Boolean).join(' · ')
      if (line) meta.appendChild(el('span', 'resume-sub', line))
      row.appendChild(meta)
      if (p.profileUrl) {
        const a = el('a', 'btn-link', p.connectLabel || 'View profile')
        a.href = p.profileUrl
        a.target = '_blank'
        a.rel = 'noopener noreferrer'
        row.appendChild(a)
      }
      list.appendChild(row)
    }
    card.appendChild(list)
  }

  if (data?.connectHowTo) {
    card.appendChild(el('p', 'ui-para ui-hint-line', data.connectHowTo))
  }
  return card
}

function formatConnectError(code) {
  const c = String(code || '')
  if (c === 'ALREADY_CONNECTED' || c === 'CANT_RESEND_YET') return 'Already invited'
  if (c === 'PLATFORM_DAILY_LIMIT' || c === 'DAILY_LIMIT_REACHED') return 'Daily limit reached'
  if (c === 'LINKEDIN_NOT_LOGGED_IN' || c.includes('JSESSIONID')) return 'Sign in on LinkedIn'
  if (c.startsWith('HTTP_')) return `LinkedIn error (${c.replace('HTTP_', '')})`
  return c || 'Could not send'
}

function buildAiResumeCard(data) {
  const card = el('div', 'ui-card ui-card-ai-resume')
  const headText = el('div', 'ui-card-headtext')
  headText.appendChild(el('h3', 'ui-card-title', 'AI-optimized resume'))
  const sub = [data?.jobTitle, data?.companyName].filter(Boolean).join(' · ')
  headText.appendChild(el('p', 'ui-card-sub', sub || ''))
  card.appendChild(headText)

  if (data?.savedFileName) {
    card.appendChild(
      el('p', 'ui-para ui-meta-line', `Saved as ${data.savedFileName} in My Resumes`)
    )
  } else {
    card.appendChild(el('p', 'ui-para ui-meta-line', 'Optimized for this job description'))
  }

  if (data?.title) {
    card.appendChild(el('p', 'ui-para', `Headline: ${data.title}`))
  }

  if (data?.summaryPreview) {
    const body = el('pre', 'cover-letter-body')
    body.textContent = data.summaryPreview
    card.appendChild(body)
  }

  if (data?.skillNames?.length) {
    card.appendChild(el('p', 'ui-para', `Skills: ${data.skillNames.join(', ')}`))
  }

  for (const exp of data?.experienceHighlights || []) {
    const block = el('div', 'ai-resume-exp-block')
    const label = [exp.role, exp.company].filter(Boolean).join(' · ')
    if (label) block.appendChild(el('strong', '', label))
    const ul = el('ul', 'ai-resume-bullets')
    for (const b of exp.bullets || []) {
      ul.appendChild(el('li', '', b))
    }
    block.appendChild(ul)
    card.appendChild(block)
  }

  const actions = el('div', 'cover-letter-actions')
  if (data?.dashboardUrl) {
    const open = el('a', 'btn-link', 'Open My Resumes')
    open.href = data.dashboardUrl
    open.target = '_blank'
    open.rel = 'noopener noreferrer'
    actions.appendChild(open)
  }
  card.appendChild(actions)

  card.appendChild(
    el(
      'p',
      'ui-para ui-hint-line',
      'Same AI optimizer as Resume Editor → Tailor resume with job description on the candidate portal.'
    )
  )
  return card
}

function buildCoverLetterCard(data) {
  const card = el('div', 'ui-card ui-card-cover-letter')
  const headText = el('div', 'ui-card-headtext')
  headText.appendChild(el('h3', 'ui-card-title', 'Cover letter'))
  const sub = [data?.jobTitle, data?.companyName].filter(Boolean).join(' · ')
  headText.appendChild(el('p', 'ui-card-sub', sub || ''))
  card.appendChild(headText)

  if (data?.tone) {
    card.appendChild(el('p', 'ui-para ui-meta-line', `Tone: ${data.tone} · Saved to your account`))
  }

  const body = el('pre', 'cover-letter-body')
  body.textContent = data?.generatedLetter || ''
  card.appendChild(body)

  const actions = el('div', 'cover-letter-actions')
  const copyBtn = el('button', 'btn-outline-sm', 'Copy')
  copyBtn.type = 'button'
  copyBtn.addEventListener('click', async () => {
    const text = data?.generatedLetter || ''
    if (!text) return
    try {
      await navigator.clipboard.writeText(text)
      copyBtn.textContent = 'Copied'
      setTimeout(() => { copyBtn.textContent = 'Copy' }, 1500)
    } catch {
      copyBtn.textContent = 'Copy failed'
    }
  })
  actions.appendChild(copyBtn)

  if (data?.dashboardUrl) {
    const open = el('a', 'btn-link', 'Open in dashboard')
    open.href = data.dashboardUrl
    open.target = '_blank'
    open.rel = 'noopener noreferrer'
    actions.appendChild(open)
  }
  card.appendChild(actions)

  card.appendChild(
    el(
      'p',
      'ui-para ui-hint-line',
      'Same generator as Profile → Cover letter on the candidate portal.'
    )
  )
  return card
}

function buildPageJobsSearchCard(data) {
  const card = el('div', 'ui-card ui-card-page-jobs')
  const headText = el('div', 'ui-card-headtext')
  headText.appendChild(el('h3', 'ui-card-title', 'Jobs on this page'))
  const sub = [
    data?.totalFetched != null ? `${data.totalFetched} roles` : '',
    data?.matchedCount != null ? `${data.matchedCount} skill matches` : '',
    data?.matchKeywords ? `Keywords: ${data.matchKeywords}` : ''
  ]
    .filter(Boolean)
    .join(' · ')
  headText.appendChild(el('p', 'ui-card-sub', sub || data?.pageTitle || ''))
  card.appendChild(headText)

  const list = el('div', 'search-result-list')
  for (const j of (data?.jobs || []).slice(0, 15)) {
    const row = el('div', 'search-result-row')
    const meta = el('div', 'search-result-meta')
    meta.appendChild(el('strong', '', j.title || 'Role'))
    const line = [j.company, j.location, j.matchScore > 0 ? `match ${j.matchScore}` : '']
      .filter(Boolean)
      .join(' · ')
    if (line) meta.appendChild(el('span', 'resume-sub', line))
    row.appendChild(meta)
    if (j.jobUrl) {
      const a = el('a', 'btn-link', j.applyLabel || 'Open role')
      a.href = j.jobUrl
      a.target = '_blank'
      a.rel = 'noopener noreferrer'
      row.appendChild(a)
    }
    list.appendChild(row)
  }
  card.appendChild(list)
  if (data?.applyHowTo) {
    card.appendChild(el('p', 'ui-para ui-hint-line', data.applyHowTo))
  }
  return card
}

function buildResumesCard(data) {
  const card = el('div', 'ui-card ui-card-resumes')
  card.appendChild(el('h3', 'ui-card-title', `Your resumes (${data?.count || 0})`))
  const list = el('div', 'resume-list')
  for (const r of (data?.resumes || []).slice(0, 12)) {
    const row = el('div', 'resume-row')
    const meta = el('div', 'resume-meta')
    meta.appendChild(el('strong', '', r.fileName || 'Resume'))
    const sub = [r.resumeType, r.isPrimary ? 'primary' : '', `${r.technicalSkillsCount || 0} skills`]
      .filter(Boolean)
      .join(' · ')
    meta.appendChild(el('span', 'resume-sub', sub))
    row.appendChild(meta)
    const actions = el('div', 'resume-actions')
    if (r.fileUrl || r.id) {
      const dl = el('button', 'resume-dl-btn', 'Download')
      dl.type = 'button'
      dl.title = 'Download this resume file'
      dl.addEventListener('click', () => {
        if (typeof window.downloadCandidateResume === 'function') {
          window.downloadCandidateResume(r)
        }
      })
      actions.appendChild(dl)
    }
    if (r.isPrimary) actions.appendChild(el('span', 'badge-pill', 'Primary'))
    row.appendChild(actions)
    list.appendChild(row)
  }
  card.appendChild(list)
  return card
}

function buildPrimaryResumeCard(data) {
  const card = el('div', 'ui-card ui-card-primary-resume')

  // Header — avatar + name + title + contact
  const hdr = el('div', 'pr-header')
  const avatar = el('div', 'pr-avatar', (data.name || 'R').charAt(0).toUpperCase())
  const hdrText = el('div', 'pr-header-text')
  hdrText.appendChild(el('h3', 'pr-name', data.name || 'Your Resume'))
  if (data.title) hdrText.appendChild(el('p', 'pr-title', data.title))
  const contactParts = [data.email, data.phone, data.location].filter(Boolean)
  if (contactParts.length) hdrText.appendChild(el('p', 'pr-meta', contactParts.join(' · ')))
  if (data.linkedin) {
    const cRow = el('div', 'pr-contact-row')
    const a = el('a', 'pr-contact-link', data.linkedin.replace(/^https?:\/\/(www\.)?/i, '').split('/').slice(0, 4).join('/'))
    a.href = data.linkedin.startsWith('http') ? data.linkedin : `https://${data.linkedin}`
    a.target = '_blank'; a.rel = 'noopener noreferrer'
    cRow.appendChild(a)
    if (data.github) {
      const ga = el('a', 'pr-contact-link', data.github.replace(/^https?:\/\/(www\.)?/i, '').split('/').slice(0, 4).join('/'))
      ga.href = data.github.startsWith('http') ? data.github : `https://${data.github}`
      ga.target = '_blank'; ga.rel = 'noopener noreferrer'
      ga.style.marginLeft = '8px'
      cRow.appendChild(ga)
    }
    hdrText.appendChild(cRow)
  }
  hdr.appendChild(avatar)
  hdr.appendChild(hdrText)
  card.appendChild(hdr)

  // Summary
  if (data.summary) {
    const s = el('div', 'pr-section')
    s.appendChild(el('p', 'pr-section-title', 'Summary'))
    s.appendChild(el('p', 'pr-body', data.summary))
    card.appendChild(s)
  }

  // Skills — all, no slice
  const techSkills = (data.skills || []).filter(s => s.type !== 'soft').map(s => s.name || s).filter(Boolean)
  const softSkills = (data.skills || []).filter(s => s.type === 'soft').map(s => s.name || s).filter(Boolean)
  if (techSkills.length) {
    const s = el('div', 'pr-section')
    s.appendChild(el('p', 'pr-section-title', 'Technical Skills'))
    const chips = el('div', 'pr-chips')
    for (const sk of techSkills) chips.appendChild(el('span', 'pr-chip pr-chip-tech', sk))
    s.appendChild(chips)
    card.appendChild(s)
  }
  if (softSkills.length) {
    const s = el('div', 'pr-section')
    s.appendChild(el('p', 'pr-section-title', 'Soft Skills'))
    const chips = el('div', 'pr-chips')
    for (const sk of softSkills) chips.appendChild(el('span', 'pr-chip pr-chip-soft', sk))
    s.appendChild(chips)
    card.appendChild(s)
  }

  // Experience — all entries, all bullets
  if ((data.experience || []).length) {
    const s = el('div', 'pr-section')
    s.appendChild(el('p', 'pr-section-title', 'Experience'))
    for (const exp of data.experience) {
      const block = el('div', 'pr-exp-block')
      const topRow = el('div', 'pr-exp-top')
      topRow.appendChild(el('strong', 'pr-exp-company', exp.company || ''))
      if (exp.dates) topRow.appendChild(el('span', 'pr-exp-dates', exp.dates))
      block.appendChild(topRow)
      const roleLine = exp.role ? (exp.role + (exp.location ? ' · ' + exp.location : '')) : ''
      if (roleLine) block.appendChild(el('div', 'pr-exp-role', roleLine))
      if ((exp.bullets || []).length) {
        const ul = el('ul', 'pr-exp-bullets')
        for (const b of exp.bullets) ul.appendChild(el('li', '', b))
        block.appendChild(ul)
      }
      s.appendChild(block)
    }
    card.appendChild(s)
  }

  // Education — all entries
  if ((data.education || []).length) {
    const s = el('div', 'pr-section')
    s.appendChild(el('p', 'pr-section-title', 'Education'))
    for (const edu of data.education) {
      const block = el('div', 'pr-edu-block')
      const topRow = el('div', 'pr-exp-top')
      topRow.appendChild(el('strong', '', edu.institution || ''))
      if (edu.year) topRow.appendChild(el('span', 'pr-exp-dates', edu.year))
      block.appendChild(topRow)
      const degLine = [edu.degree, edu.grade].filter(Boolean).join(' · ')
      if (degLine) block.appendChild(el('div', 'pr-exp-role', degLine))
      s.appendChild(block)
    }
    card.appendChild(s)
  }

  // Projects — all entries
  if ((data.projects || []).length) {
    const s = el('div', 'pr-section')
    s.appendChild(el('p', 'pr-section-title', 'Projects'))
    for (const p of data.projects) {
      const block = el('div', 'pr-edu-block')
      block.appendChild(el('strong', '', p.title || ''))
      if (p.tech) block.appendChild(el('div', 'pr-exp-role', p.tech))
      if (p.description) block.appendChild(el('p', 'pr-proj-desc', p.description))
      if (p.link) {
        const a = el('a', 'pr-contact-link', p.link.replace(/^https?:\/\/(www\.)?/i, ''))
        a.href = p.link.startsWith('http') ? p.link : `https://${p.link}`
        a.target = '_blank'; a.rel = 'noopener noreferrer'
        block.appendChild(a)
      }
      s.appendChild(block)
    }
    card.appendChild(s)
  }

  // Certifications — all entries
  if ((data.certifications || []).length) {
    const s = el('div', 'pr-section')
    s.appendChild(el('p', 'pr-section-title', 'Certifications'))
    const ul = el('ul', 'pr-bullets')
    for (const c of data.certifications) {
      const line = [c.name || c, c.issuer, c.date].filter(Boolean).join(' · ')
      ul.appendChild(el('li', '', line))
    }
    s.appendChild(ul)
    card.appendChild(s)
  }

  // Languages
  if ((data.languages || []).length) {
    const s = el('div', 'pr-section')
    s.appendChild(el('p', 'pr-section-title', 'Languages'))
    const chips = el('div', 'pr-chips')
    for (const lang of data.languages) chips.appendChild(el('span', 'pr-chip pr-chip-soft', typeof lang === 'string' ? lang : lang.name || ''))
    s.appendChild(chips)
    card.appendChild(s)
  }

  return card
}

function buildSkillsCheckCard(data) {
  const {
    missingSkills = [],
    jobTitle = '',
    company = '',
    jdExperience = '',
    resumeExperience = '',
    experienceGapRequired = false,
  } = data
  const card = el('div', 'ui-card ui-card-skills-check')

  // Header
  const header = el('div', 'ui-card-header')
  const iconWrap = el('div', 'mock-interview-icon')
  iconWrap.textContent = '💡'
  const headText = el('div', 'ui-card-headtext')
  headText.appendChild(el('h3', 'ui-card-title', 'Quick check before generating'))
  const roleLine = jobTitle ? `${jobTitle}${company ? ' · ' + company : ''}` : ''
  headText.appendChild(el('p', 'ui-card-sub', roleLine || 'These skills are in the JD but not found in your resume'))
  header.appendChild(iconWrap)
  header.appendChild(headText)
  card.appendChild(header)

  let expGapInput = null
  if (jdExperience && resumeExperience) {
    const expBlock = el('div', 'skills-check-exp-gap')
    const expP = document.createElement('p')
    expP.innerHTML =
      `Your resume shows <strong>${escapeHtml(resumeExperience)}</strong>; this JD asks for <strong>${escapeHtml(jdExperience)}</strong>. ` +
      'Briefly describe your relevant experience (roles, domains, team scope).'
    expBlock.appendChild(expP)
    expGapInput = document.createElement('textarea')
    expGapInput.className = 'skills-check-exp-input'
    expGapInput.placeholder = 'e.g. 6 years across backend + platform roles; led 4-person squad on cloud migrations…'
    expGapInput.rows = 3
    expBlock.appendChild(expGapInput)
    card.appendChild(expBlock)
  }

  if (missingSkills.length) {
    card.appendChild(el(
      'p',
      'skills-check-intro',
      'These skills are in the job description but not on your resume. Mark Yes/No — if Yes, say where you used each. Then we ask separate follow-up questions and generate.'
    ))
  }

  const skillRows = []
  for (const skill of missingSkills) {
    const row = el('div', 'skill-check-row')
    row.dataset.skill = skill
    row.dataset.answer = ''

    const nameEl = el('div', 'skill-check-top')
    nameEl.appendChild(el('span', 'skill-check-name', skill))

    const btns = el('div', 'skill-check-btns')
    const yesBtn = el('button', 'skill-yn-btn skill-yes-btn', '✓ Yes')
    yesBtn.type = 'button'
    const noBtn = el('button', 'skill-yn-btn skill-no-btn', '✗ No')
    noBtn.type = 'button'
    btns.appendChild(yesBtn)
    btns.appendChild(noBtn)
    nameEl.appendChild(btns)
    row.appendChild(nameEl)

    const noteArea = el('div', 'skill-note-area')
    noteArea.style.display = 'none'
    const noteInput = document.createElement('textarea')
    noteInput.className = 'skill-note-input'
    noteInput.placeholder = 'Where have you used this? (role, project, tools, outcome)'
    noteInput.rows = 2
    noteArea.appendChild(noteInput)
    row.appendChild(noteArea)

    yesBtn.addEventListener('click', () => {
      row.dataset.answer = 'yes'
      yesBtn.classList.add('active-yes')
      noBtn.classList.remove('active-no')
      noteArea.style.display = 'block'
      noteInput.focus()
    })
    noBtn.addEventListener('click', () => {
      row.dataset.answer = 'no'
      noBtn.classList.add('active-no')
      yesBtn.classList.remove('active-yes')
      noteArea.style.display = 'none'
      noteInput.value = ''
    })

    skillRows.push({ row, noteInput })
    card.appendChild(row)
  }

  const extraSection = el('div', 'skills-check-extra')
  extraSection.appendChild(el('p', 'skills-check-extra-label', 'Anything else to highlight in your resume?'))
  const extraInput = document.createElement('textarea')
  extraInput.className = 'skills-check-extra-input'
  extraInput.placeholder = 'e.g. "I led a team of 5 engineers, I hold an AWS certification…"'
  extraInput.rows = 2
  extraSection.appendChild(extraInput)
  card.appendChild(extraSection)

  const generateBtn = el('button', 'mock-interview-start-btn skills-check-generate-btn', 'Continue → Answer JD questions')
  generateBtn.type = 'button'
  generateBtn.addEventListener('click', () => {
    skillRows.forEach(({ row, noteInput }) => {
      row.classList.remove('skill-check-row-error')
      noteInput.classList.remove('skills-check-input-error')
    })
    if (expGapInput) expGapInput.classList.remove('skills-check-input-error')

    const answers = skillRows.map(({ row, noteInput }) => ({
      skill: row.dataset.skill,
      hasIt: row.dataset.answer === 'yes',
      answered: row.dataset.answer !== '',
      note: noteInput.value.trim(),
    }))
    const experienceGapNote = expGapInput ? expGapInput.value.trim() : ''
    const validationParts = []

    if (missingSkills.length) {
      const unanswered = answers.filter((a) => !a.answered)
      if (unanswered.length === answers.length) {
        validationParts.push('Please mark **Yes** or **No** for each skill below before continuing.')
        unanswered.forEach((a) => {
          const rowObj = skillRows.find((r) => r.row.dataset.skill === a.skill)
          rowObj?.row.classList.add('skill-check-row-error')
        })
      }
      const yesWithoutNote = answers.filter((a) => a.hasIt && !a.note)
      if (yesWithoutNote.length) {
        validationParts.push(
          `You forgot to enter where you used: **${yesWithoutNote.map((a) => a.skill).join(', ')}**. Please fill in the boxes below.`
        )
        yesWithoutNote.forEach((a) => {
          const rowObj = skillRows.find((r) => r.row.dataset.skill === a.skill)
          if (rowObj) {
            rowObj.row.classList.add('skill-check-row-error')
            rowObj.noteInput.classList.add('skills-check-input-error')
            rowObj.noteArea.style.display = 'block'
          }
        })
      }
    }

    if (experienceGapRequired && !experienceGapNote) {
      validationParts.push(
        `Your resume shows **${resumeExperience}**; this JD asks for **${jdExperience}**. Briefly describe your relevant experience below (roles, domains, team scope).`
      )
      if (expGapInput) expGapInput.classList.add('skills-check-input-error')
    }

    if (validationParts.length) {
      document.dispatchEvent(new CustomEvent('resume-skills-validation-failed', {
        bubbles: true,
        detail: { message: validationParts.join('\n\n') },
      }))
      return
    }

    generateBtn.textContent = 'Please wait…'
    generateBtn.disabled = true
    document.dispatchEvent(new CustomEvent('resume-skills-confirmed', {
      bubbles: true,
      detail: { answers, extraNote: extraInput.value.trim(), experienceGapNote },
    }))
  })
  card.appendChild(generateBtn)

  return card
}

function escapeHtml(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

function buildTasksCard(data, msgTime) {
  const tasks = Array.isArray(data.tasks) ? data.tasks : []
  const card = el('div', '') // plain container instead of ui-card

  const header = el('div', '')
  const headText = el('div', '')
  const totalStr = data.total ? `${data.total} task(s) found` : (tasks.length ? `${tasks.length} task(s) found` : 'No tasks found for these filters')
  headText.appendChild(el('p', '', totalStr))
  header.appendChild(headText)
  card.appendChild(header)

  if (!tasks.length) {
    return card
  }

  for (const t of tasks) {
    const row = el('div', 'task-row')
    
    const titleEl = el('div', 'task-title', t.title || 'Untitled Task')
    titleEl.style.marginBottom = '4px'
    row.appendChild(titleEl)
    
    if (t.deadline) {
      const dl = el('div', 'task-deadline')
      const dateStr = String(t.deadline).split('T')[0]
      const parts = dateStr.split('-')
      let displayDate = dateStr
      if (parts.length === 3) {
        const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]))
        if (!isNaN(d.getTime())) {
          displayDate = d.toLocaleDateString()
        }
      } else {
        const d = new Date(t.deadline)
        if (!isNaN(d.getTime())) {
          displayDate = d.toLocaleDateString()
        }
      }
      dl.textContent = 'Deadline: ' + displayDate
      dl.style.marginBottom = '8px'
      row.appendChild(dl)
    }
    
    const viewBtnWrap = el('div', '')
    const viewBtn = el('a', 'btn-link', 'View')
    viewBtn.href = '#'
    viewBtn.addEventListener('click', (e) => {
      e.preventDefault()
      document.dispatchEvent(new CustomEvent('task-view-click', { bubbles: true }))
    })
    viewBtnWrap.appendChild(viewBtn)
    row.appendChild(viewBtnWrap)
    
    row.style.borderBottom = '1px solid #e2e8f0'
    row.style.paddingBottom = '12px'
    row.style.marginBottom = '12px'
    
    card.appendChild(row)
  }
  
  if (data.hasMore) {
    const showMoreWrap = el('div', 'task-show-more-wrap')
    showMoreWrap.style.textAlign = 'center'
    showMoreWrap.style.marginTop = '8px'
    const showMore = el('a', 'btn-link', 'Show more')
    showMore.style.cursor = 'pointer'
    showMore.style.color = '#2563eb'
    showMore.addEventListener('click', (e) => {
      e.preventDefault()
      showMore.textContent = 'Loading...'
      document.dispatchEvent(new CustomEvent('task-fetch-more', {
        bubbles: true,
        detail: { filters: data.filters, currentOffset: data.offset || 0, msgTime }
      }))
    })
    showMoreWrap.appendChild(showMore)
    card.appendChild(showMoreWrap)
  }

  return card
}

function buildAddTaskCard() {
  const card = el('div', 'ui-card ui-card-add-task')

  const header = el('div', 'ui-card-header')
  const iconWrap = el('div', 'mock-interview-icon')
  iconWrap.textContent = '➕'
  const headText = el('div', 'ui-card-headtext')
  headText.appendChild(el('h3', 'ui-card-title', 'New Self Task'))
  headText.appendChild(el('p', 'ui-card-sub', 'Title, description and deadline are required'))
  header.appendChild(iconWrap)
  header.appendChild(headText)
  card.appendChild(header)

  const mkInput = (placeholder, type, name, required) => {
    const wrap = el('div', 'add-task-field')
    const inp = document.createElement(type === 'textarea' ? 'textarea' : 'input')
    inp.className = 'add-task-input'
    if (type !== 'textarea') inp.type = type || 'text'
    inp.placeholder = placeholder
    inp.name = name
    if (type === 'textarea') inp.rows = 2
    wrap.appendChild(inp)
    if (required) {
      const req = el('span', 'add-task-required', '*')
      wrap.insertBefore(req, inp)
    }
    return wrap
  }

  card.appendChild(mkInput('Title *', 'text', 'title', true))
  card.appendChild(mkInput('Description *', 'textarea', 'description', true))
  card.appendChild(mkInput('Deadline * (YYYY-MM-DD)', 'date', 'deadline', true))
  card.appendChild(mkInput('Reference link (optional)', 'url', 'link', false))

  const selWrap = el('div', 'add-task-field')
  const sel = document.createElement('select')
  sel.className = 'add-task-input'
  sel.name = 'priority'
  for (const p of ['Low', 'Medium', 'High']) {
    const opt = document.createElement('option')
    opt.value = p
    opt.textContent = p
    if (p === 'Medium') opt.selected = true
    sel.appendChild(opt)
  }
  selWrap.appendChild(sel)
  card.appendChild(selWrap)

  const errMsg = el('p', 'add-task-err hidden', '')
  card.appendChild(errMsg)

  const submitBtn = el('button', 'mock-interview-start-btn', '➕  Add Task')
  submitBtn.type = 'button'
  submitBtn.style.background = 'linear-gradient(135deg,#3b82f6,#1d4ed8)'
  submitBtn.style.marginTop = '8px'
  submitBtn.addEventListener('click', () => {
    const get = (name) => {
      const el2 = card.querySelector(`[name="${name}"]`)
      return el2 ? el2.value.trim() : ''
    }
    const title = get('title')
    const description = get('description')
    const deadline = get('deadline')
    const link = get('link')
    const priority = get('priority')
    const missing = []
    if (!title) missing.push('title')
    if (!description) missing.push('description')
    if (!deadline) missing.push('deadline')
    if (missing.length) {
      errMsg.textContent = `Required: ${missing.join(', ')}`
      errMsg.classList.remove('hidden')
      return
    }
    errMsg.classList.add('hidden')
    document.dispatchEvent(new CustomEvent('task-submit', {
      bubbles: true,
      detail: { title, description, deadline, link, priority }
    }))
    card.querySelectorAll('.add-task-input').forEach(i => { i.value = ''; if (i.tagName === 'SELECT') i.value = 'Medium' })
    submitBtn.textContent = 'Task added!'
    submitBtn.disabled = true
    setTimeout(() => { submitBtn.textContent = '➕  Add Task'; submitBtn.disabled = false }, 2500)
  })
  card.appendChild(submitBtn)
  return card
}

function parseJd(text) {
  if (!text) return {}
  const out = {}

  // Experience: "3+ years", "5 years of experience", "minimum 2 years"
  const expM = text.match(/(\d+\s*[\+\-–]?\s*(?:to\s*\d+\s*)?years?(?:\s+of\s+(?:relevant\s+)?(?:experience|exp(?:erience)?))?)/i)
  if (expM) out.experience = expM[1].trim()

  // Normalise to lines, strip markdown-style bullets
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n')
  const clean = (l) => l.replace(/^[\-\*\•\·►▸▶✓]\s*/, '').replace(/^\d+[\.\)]\s*/, '').trim()

  const SECTIONS = [
    { key: 'responsibilities', re: /^(key\s+)?responsibilities|what you.?ll do|your role|role overview|job duties|key duties/i },
    { key: 'requirements',     re: /^(minimum\s+)?(requirements|qualifications)|what (we.?re|you.?ll need)|must.have|you (have|bring)/i },
    { key: 'skills',           re: /^(required\s+|technical\s+|key\s+)?skills|tech(nical)?\s+stack|technologies|tools/i },
    { key: 'about',            re: /^about (the|us|company|role)|company overview|who we are|the role|position summary/i },
    { key: 'nice',             re: /^nice.to.have|preferred|bonus|good.to.have|desirable/i },
  ]

  let cur = null
  const buckets = {}
  for (const line of lines) {
    const t = line.trim()
    if (!t) continue
    let hit = false
    for (const { key, re } of SECTIONS) {
      if (re.test(t) && t.length < 80) {
        cur = key
        buckets[cur] = buckets[cur] || []
        hit = true
        break
      }
    }
    if (!hit && cur) buckets[cur].push(t)
  }

  const toBullets = (arr) =>
    (arr || []).map(clean).filter(l => l.length > 3).slice(0, 8)

  if (buckets.responsibilities?.length) out.responsibilities = toBullets(buckets.responsibilities)
  if (buckets.requirements?.length)     out.requirements     = toBullets(buckets.requirements)
  if (buckets.skills?.length)           out.skills           = toBullets(buckets.skills)
  if (buckets.about?.length)            out.about            = buckets.about.map(clean).filter(Boolean).join(' ').slice(0, 280)
  if (buckets.nice?.length)             out.nice             = toBullets(buckets.nice)

  // Fallback skill extraction from full text
  if (!out.skills || !out.skills.length) {
    const TECH = [
      'JavaScript','TypeScript','Python','Java','Go','Rust','Ruby','PHP','Swift','Kotlin','Scala','C#','C++',
      'React','Next.js','Angular','Vue','Node.js','Django','Flask','Spring Boot','FastAPI','Laravel',
      'SQL','MySQL','PostgreSQL','MongoDB','Redis','Elasticsearch','Kafka','RabbitMQ',
      'AWS','GCP','Azure','Docker','Kubernetes','Terraform','CI/CD','GitHub Actions','Jenkins',
      'GraphQL','REST','gRPC','HTML','CSS','Tailwind','Git','Linux','Agile','Scrum',
      'Machine Learning','Deep Learning','TensorFlow','PyTorch','Pandas','NumPy'
    ]
    const found = TECH.filter(k => new RegExp(`\\b${k.replace(/[.+]/g, '\\$&')}\\b`, 'i').test(text))
    if (found.length) out.skills = found.slice(0, 14)
  }

  return out
}

function buildMockInterviewCard(data) {
  const wrap = el('div', 'mi-plain-wrap')
  const parsed = parseJd(data.jobDescription)

  const addLine = (label, value) => {
    const p = el('p', 'mi-line')
    const b = el('strong', 'mi-label', label + ': ')
    p.appendChild(b)
    p.appendChild(document.createTextNode(value))
    wrap.appendChild(p)
  }

  const addList = (label, items) => {
    const p = el('p', 'mi-line')
    p.appendChild(el('strong', 'mi-label', label + ':'))
    wrap.appendChild(p)
    const ul = el('ul', 'mi-bullets')
    for (const item of items) ul.appendChild(el('li', '', item))
    wrap.appendChild(ul)
  }

  if (data.company)          addLine('Company', data.company)
  if (data.jobTitle)         addLine('Role', data.jobTitle)
  if (parsed.experience)     addLine('Experience', parsed.experience)
  if (parsed.skills?.length) addLine('Skills', parsed.skills.join(', '))

  const keyPoints = parsed.responsibilities?.length
    ? parsed.responsibilities
    : parsed.requirements?.length ? parsed.requirements : null
  if (keyPoints) addList('Key Points', keyPoints)
  if (parsed.nice?.length) addList('Nice to have', parsed.nice)

  const fullJdText = String(data.jobDescription || '').trim()
  if (fullJdText) {
    const jdLabel = el('p', 'mi-line')
    jdLabel.appendChild(el('strong', 'mi-label', 'Job Description:'))
    wrap.appendChild(jdLabel)

    const jdBody = el('div', 'mi-jd-body')
    jdBody.textContent = fullJdText
    wrap.appendChild(jdBody)

    const showMoreBtn = el('button', 'mi-show-more-btn', 'Show more')
    showMoreBtn.type = 'button'
    let expanded = false
    showMoreBtn.addEventListener('click', () => {
      expanded = !expanded
      jdBody.style.maxHeight = expanded ? 'none' : ''
      jdBody.style.webkitMaskImage = expanded ? 'none' : ''
      jdBody.style.maskImage = expanded ? 'none' : ''
      showMoreBtn.textContent = expanded ? 'Show less' : 'Show more'
    })
    wrap.appendChild(showMoreBtn)
  }

  const startBtn = el('button', 'mock-interview-start-btn', 'Start Interview')
  startBtn.type = 'button'
  startBtn.addEventListener('click', () => {
    document.dispatchEvent(new CustomEvent('mock-interview-start', {
      bubbles: true,
      detail: { jobTitle: data.jobTitle, company: data.company, jobDescription: data.jobDescription }
    }))
  })
  wrap.appendChild(startBtn)

  return wrap
}
function markdownToHtml(text) {
  if (!text) return '';
  let s = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
  s = s.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/\*([^*\n]+)\*/g, '<strong>$1</strong>');
  s = s.replace(/_([^_\n]+)_/g, '<em>$1</em>');
  s = s.replace(/\n/g, '<br>');
  return s;
}


function buildTaskFlowOptions(data) {
  const wrap = el('div', 'tfo-wrap')
  for (const opt of (data.options || [])) {
    const btn = el('button', 'tfo-btn', opt)
    btn.type = 'button'
    btn.addEventListener('click', () => {
      document.dispatchEvent(new CustomEvent('task-flow-reply', { bubbles: true, detail: { text: opt } }))
    })
    wrap.appendChild(btn)
  }
  return wrap
}

function buildTaskFlowDateInput(data) {
  const wrap = el('div', 'tfo-date-wrap')
  const today = new Date().toISOString().slice(0, 10)
  const input = document.createElement('input')
  input.type = 'date'
  input.className = 'tfo-date-input'
  input.min = today
  input.value = (data && data.defaultDate) ? data.defaultDate : ''
  const btn = el('button', 'tfo-date-btn', 'Set Deadline')
  btn.type = 'button'
  btn.addEventListener('click', () => {
    const val = input.value
    if (!val) { input.focus(); return }
    document.dispatchEvent(new CustomEvent('task-flow-reply', { bubbles: true, detail: { text: val } }))
  })
  wrap.appendChild(input)
  wrap.appendChild(btn)
  return wrap
}

function buildTrackerStageSelectCard(data) {
  const card = el('div', 'ui-card ui-card-tracker-stages')
  card.appendChild(el('h4', 'ui-card-title', 'Select Tracker Pipeline Stages'))
  
  const container = el('div', 'tracker-stages-list')
  container.style.display = 'flex'
  container.style.flexWrap = 'wrap'
  container.style.gap = '8px'
  container.style.marginTop = '8px'
  container.style.marginBottom = '12px'

  const stages = [
    { key: 'saved', label: 'Saved' },
    { key: 'preparing', label: 'Preparing' },
    { key: 'applied', label: 'Applied' },
    { key: 'active', label: 'Active' },
    { key: 'closed', label: 'Closed' }
  ]

  const selected = new Set()

  for (const s of stages) {
    const pill = el('button', 'tracker-stage-pill', s.label)
    pill.type = 'button'
    pill.style.padding = '6px 12px'
    pill.style.border = '1px solid var(--vp-border)'
    pill.style.borderRadius = '20px'
    pill.style.background = 'transparent'
    pill.style.color = 'var(--vp-text)'
    pill.style.fontSize = '11px'
    pill.style.fontWeight = '500'
    pill.style.cursor = 'pointer'
    pill.style.transition = 'all 0.2s ease'

    pill.addEventListener('click', () => {
      if (selected.has(s.key)) {
        selected.delete(s.key)
        pill.style.background = 'transparent'
        pill.style.borderColor = 'var(--vp-border)'
        pill.style.color = 'var(--vp-text)'
      } else {
        selected.add(s.key)
        pill.style.background = '#2563eb'
        pill.style.borderColor = '#2563eb'
        pill.style.color = '#ffffff'
      }
    })
    container.appendChild(pill)
  }
  card.appendChild(container)

  const confirmBtn = el('button', 'mock-interview-start-btn', 'Confirm Selection')
  confirmBtn.type = 'button'
  confirmBtn.style.background = 'linear-gradient(135deg,#3b82f6,#1d4ed8)'
  confirmBtn.style.width = '100%'
  confirmBtn.style.color = '#ffffff'
  confirmBtn.style.border = 'none'
  confirmBtn.style.padding = '8px'
  confirmBtn.style.borderRadius = '8px'
  confirmBtn.style.fontWeight = 'bold'
  confirmBtn.style.cursor = 'pointer'
  
  confirmBtn.addEventListener('click', () => {
    if (selected.size === 0) {
      alert('Please select at least one pipeline stage.')
      return
    }
    confirmBtn.disabled = true
    confirmBtn.textContent = 'Submitted'
    document.dispatchEvent(new CustomEvent('tracker-stages-selected', {
      bubbles: true,
      detail: { stages: Array.from(selected) }
    }))
  })

  card.appendChild(confirmBtn)
  return card
}

function appendMessageBubble(m, parent) {
  const bubble = el('div', `bubble ${m.role === 'user' ? 'user' : 'assistant'}`)
  if (m.role === 'user') {
    bubble.textContent = m.display || m.content
    parent.appendChild(bubble)
    return
  }

  if (m.ui?.type === 'html' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.innerHTML = m.ui.data
    parent.appendChild(bubble)
    return
  }

  if (m.ui?.type === 'ats' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildAtsCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'tailor' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildTailorCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'resumes' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildResumesCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (
    (m.ui?.type === 'jobs' ||
      m.ui?.type === 'indeedJobs' ||
      m.ui?.type === 'naukriJobs' ||
      m.ui?.type === 'monsterJobs') &&
    m.ui.data
  ) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(
      buildJobsSearchCard(m.ui.data, {
        source:
          m.ui.type === 'indeedJobs'
            ? 'indeed'
            : m.ui.type === 'naukriJobs'
              ? 'naukri'
              : m.ui.type === 'monsterJobs'
                ? 'monster'
                : 'linkedin'
      })
    )
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'people' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildPeopleSearchCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'pageJobs' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildPageJobsSearchCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'coverLetter' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildCoverLetterCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'aiResume' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildAiResumeCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'mockInterview' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildMockInterviewCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'primaryResume' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildPrimaryResumeCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'skillsCheck' && m.ui.data) {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildSkillsCheckCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'tasks') {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildTasksCard(m.ui.data, m.t))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'addTask') {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildAddTaskCard())
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'taskFlowOptions' && m.ui.data) {
    if (m.content) {
      const p = document.createElement('p')
      p.className = 'tfo-content-text'
      p.textContent = m.content
      bubble.appendChild(p)
    }
    bubble.appendChild(buildTaskFlowOptions(m.ui.data))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'taskFlowDateInput') {
    if (m.content) {
      const p = document.createElement('p')
      p.className = 'tfo-content-text'
      p.textContent = m.content
      bubble.appendChild(p)
    }
    bubble.appendChild(buildTaskFlowDateInput(m.ui.data || {}))
    parent.appendChild(bubble)
    return
  }
  if (m.ui?.type === 'trackerStageSelect') {
    bubble.classList.add('bubble-rich')
    bubble.appendChild(buildTrackerStageSelectCard(m.ui.data))
    parent.appendChild(bubble)
    return
  }

  bubble.innerHTML = markdownToHtml(m.display || m.content || '')
  parent.appendChild(bubble)
}

window.ChatUi = {
  appendMessageBubble,
  markdownToHtml,
  setConnectionHandlers,
  buildAtsCard,
  buildTailorCard,
  buildResumesCard,
  buildJobsSearchCard,
  buildPeopleSearchCard,
  buildPageJobsSearchCard,
  buildCoverLetterCard,
  buildAiResumeCard,
  buildMockInterviewCard,
  buildPrimaryResumeCard,
  buildSkillsCheckCard,
  buildTasksCard,
  buildAddTaskCard,
  buildTrackerStageSelectCard
}
