/**
 * Indeed page helpers (no automatic browser tab opening).
 */

import { resolveIndeedBase } from './indeedClient.js'
import { resolvePostedWithinDays } from './jobSearchPrefs.js'

export function buildIndeedJobsSearchUrl(filters = {}) {
  const country = String(filters.country || 'IN').toUpperCase()
  const base = resolveIndeedBase(country)
  const q = String(filters.keywords || filters.jobTitle || '').trim() || 'software engineer'
  const l = String(filters.location || '').trim()
  const params = new URLSearchParams()
  params.set('q', q)
  if (l) params.set('l', l)
  if (filters.start > 0) params.set('start', String(filters.start))
  if (filters.radius) params.set('radius', String(filters.radius))
  if (filters.fromage) params.set('fromage', String(filters.fromage))
  else {
    const days = resolvePostedWithinDays(filters.datePostedDays ?? filters.postedWithinDays, 0)
    if (days >= 1) params.set('fromage', String(days))
  }
  if (filters.explvl) params.set('explvl', String(filters.explvl))
  if (filters.jt) params.set('jt', String(filters.jt))
  return `${base}/jobs?${params.toString()}`
}

export function analyzeIndeedPage(html = '', title = '', url = '') {
  const text = String(html || '')
  const t = String(title || '')
  const hasJobs =
    text.includes('mosaic-provider-jobcards') || /data-jk="[a-f0-9]{16}"/i.test(text)
  const isSecurity =
    /Security Check|verify you are human|not a robot|unusual traffic|Just a moment/i.test(t) ||
    /Security Check|bot-detection|challenge-platform|hcaptcha|recaptcha|cf-challenge|turnstile|arkose/i.test(
      text
    ) ||
    /\/verify|challenges\.cloudflare/i.test(String(url || ''))
  let path = ''
  try {
    path = new URL(url).pathname || ''
  } catch {
    path = ''
  }
  const isLoginUrl =
    /\/account\/login|\/auth\/|\/login\/?$/i.test(path) || /indeed\.com\/login/i.test(url)
  const isLoginTitle = /sign in to indeed|log in to indeed/i.test(t)
  const isLogin = (isLoginUrl || isLoginTitle) && !hasJobs && !isSecurity
  return { hasJobs, isSecurity, isLogin }
}
