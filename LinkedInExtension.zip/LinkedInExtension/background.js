import { searchPeopleInExtension, buildPeopleKeywordSets } from './linkedinPeopleSearch.js'
import { searchJobsInExtension } from './linkedinJobsSearch.js'
import { searchIndeedJobsInExtension, padIndeedJobForImport } from './indeedJobsSearch.js'
import { searchNaukriJobsInExtension } from './naukriJobsSearch.js'
import { searchMonsterJobsInExtension } from './monsterJobsSearch.js'
import { buildAutoSearchFilters, buildSearchKeywords, buildSearchCriteriaSummary, resolveDatePostedDays } from './jobSearchPrefs.js'
import { buildJobSearchQuerySets, mergeResumeSearchSkills, resolveJobSearchTarget } from './jobSearchQuerySets.js'
import { dedupeSearchJobs } from './jobDedupe.js'
import {
  getExtensionDeviceId,
  collectDeviceMeta,
} from './linkedinDevice.js'
import { getLinkedInAuthCookies } from './linkedinCookies.js'
import {
  getIndeedSessionSnapshot,
  probeIndeedCookieSession,
} from './indeedClient.js'
import {
  getNaukriSessionSnapshot,
  pullNkparamFromOpenNaukriTabs,
  captureNkparamSilently,
  probeNaukriCookieSession,
} from './naukriClient.js'
import {
  getMonsterSessionSnapshot,
  persistMonsterSessionMeta,
  pullMonsterSessionFromOpenTabs,
  captureMonsterSessionForSync,
} from './monsterClient.js'
import { canonicalNaukriJobUrl } from './naukriJobUrl.js'
import {
  DEFAULT_AUTH_API_BASE,
  DEFAULT_CAREER_API_BASE,
  DEFAULT_AI_CHAT_API_BASE,
  DEFAULT_DASHBOARD_URL,
  normalizeVppoApiBase,
  stripTrailingSlashes,
  getAuthApiBase,
  getCareerApiBase,
  getAiChatApiBase,
  parseAuthTokens,
} from './authConfig.js'

const MAX_EXTENSION_LOG = 80

/** Debounce cookie-change bursts so we do not POST to backend (and avoid duplicate work) on every tiny cookie update */
let syncDebounceTimer = null
let isSidePanelOpen = false

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'sidepanel-connection') {
    isSidePanelOpen = true
    chrome.storage.local.set({ isSidePanelOpen: true })
    port.onDisconnect.addListener(() => {
      isSidePanelOpen = false
      chrome.storage.local.set({ isSidePanelOpen: false })
    })
  }
})

async function appendExtensionLog(level, message) {
  try {
    const { extensionLog = [] } = await chrome.storage.local.get('extensionLog')
    const row = { t: new Date().toISOString(), level, message }
    const next = [row, ...extensionLog].slice(0, MAX_EXTENSION_LOG)
    await chrome.storage.local.set({ extensionLog: next })
  } catch (e) {
    console.warn('[Extension] log write failed', e)
  }
}

// ─── On install ───────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  console.log('[Extension] Installed. Setting up cookie watcher alarm.')
  appendExtensionLog('info', 'Extension installed / updated')
  const stored = await chrome.storage.local.get(['careerApiBase', 'aiChatApiBase', 'authApiBase', 'dashboardUrl'])
  const patch = {}
  if (!stored.careerApiBase) patch.careerApiBase = DEFAULT_CAREER_API_BASE
  if (!stored.aiChatApiBase) patch.aiChatApiBase = DEFAULT_AI_CHAT_API_BASE
  if (!stored.authApiBase) patch.authApiBase = DEFAULT_AUTH_API_BASE
  if (!stored.dashboardUrl) patch.dashboardUrl = DEFAULT_DASHBOARD_URL
  if (Object.keys(patch).length) await chrome.storage.local.set(patch)
  chrome.alarms.create('cookie-sync', { periodInMinutes: 30 })
})

// ─── Alarm handler ────────────────────────────────────────────────────────────
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'cookie-sync') {
    const allowed = await shouldAutoSyncLinkedIn()
    if (!allowed) {
      await appendExtensionLog('info', 'Skipped scheduled sync — LinkedIn active on another device')
      return
    }
    await appendExtensionLog('info', 'Scheduled sync (30 min alarm)')
    await syncLinkedInCookies()
  }
})

// ─── Listen for cookie changes on LinkedIn ────────────────────────────────────
let authSyncDebounceTimer = null

const CAREER_SYNC_TTL_MS = 30 * 60 * 1000

function isSessionFresh(lastSyncIso) {
  if (!lastSyncIso) return false
  const age = Date.now() - new Date(lastSyncIso).getTime()
  return Number.isFinite(age) && age >= 0 && age < CAREER_SYNC_TTL_MS
}

async function syncLinkedInIfAuthed() {
  const auth = await ensurePlatformAuthToken()
  if (!auth.ok) return
  await appendExtensionLog('info', 'Auto-sync LinkedIn session')
  await syncLinkedInCookies()
}

function scheduleAuthCareerSync(reason = 'auth') {
  if (authSyncDebounceTimer) clearTimeout(authSyncDebounceTimer)
  authSyncDebounceTimer = setTimeout(async () => {
    authSyncDebounceTimer = null
    const { lastCareerPlatformsSync } = await chrome.storage.local.get('lastCareerPlatformsSync')
    if (reason === 'set-auth-token' && isSessionFresh(lastCareerPlatformsSync)) {
      return
    }
    await syncLinkedInIfAuthed()
    await chrome.storage.local.set({ lastCareerPlatformsSync: new Date().toISOString() })
  }, 3000)
}

function resolveNaukriSearchFilters(filters, ctx, payload = {}) {
  const f = filters && typeof filters === 'object' ? filters : {}
  const c = ctx && typeof ctx === 'object' ? ctx : {}
  const p = payload && typeof payload === 'object' ? payload : {}
  return {
    wfhType: f.wfhType ?? p.wfhType,
    experience: f.experience ?? p.experience ?? c?.filters?.naukri?.experience,
    cityTypeGid: f.cityTypeGid ?? p.cityTypeGid,
    ctcFilter: f.ctcFilter ?? p.ctcFilter,
    functionAreaIdGid: f.functionAreaIdGid ?? p.functionAreaIdGid,
    pgTypeGid: f.pgTypeGid ?? p.pgTypeGid,
    employement: f.employement ?? p.employement,
  }
}

async function ensureBrowserSessionReady(platform) {
  if (platform === 'naukri') {
    const snap = await getNaukriSessionSnapshot()
    if (snap.loggedIn && snap.cookieHeader) {
      if (!snap.hasNkparam) {
        await captureNkparamSilently()
      }
      await setNaukriSessionStatus('connected')
      return { ok: true, naukriStatus: 'connected', hasNkparam: true }
    }
    return {
      ok: false,
      error: 'NAUKRI_NOT_LOGGED_IN',
      message: 'Log in on naukri.com in this browser, then search again.',
    }
  }
  if (platform === 'indeed') {
    const snap = await getIndeedSessionSnapshot()
    if (!snap.loggedIn || !snap.cookieHeader) {
      return {
        ok: false,
        error: 'INDEED_NOT_LOGGED_IN',
        message: 'Log in on indeed.com in this browser, then search again.',
      }
    }
    await setIndeedSessionStatus('connected')
    return { ok: true, indeedStatus: 'connected' }
  }
  if (platform === 'monster') {
    await pullMonsterSessionFromOpenTabs({ injectHooks: true })
    const snap = await getMonsterSessionSnapshot()
    const hasCookies = Boolean(String(snap.cookieHeader || '').trim().length >= 10)
    if (!hasCookies && !snap.loggedIn) {
      return {
        ok: false,
        error: 'MONSTER_NOT_LOGGED_IN',
        message: 'Log in on monster.com in this browser, then search again.',
      }
    }
    await setMonsterSessionStatus('connected')
    return { ok: true, monsterStatus: 'connected', hasDatadome: snap.hasDatadome }
  }
  return { ok: false }
}

async function probeIndeedSessionStatus() {
  try {
    const snap = await getIndeedSessionSnapshot()
    const { indeedStatus } = await chrome.storage.local.get('indeedStatus')
    if (!snap.loggedIn || !snap.cookieHeader) {
      if (indeedStatus === 'connected' || indeedStatus === 'session_invalid') {
        await setIndeedSessionStatus('not_logged_in')
        await appendExtensionLog('warn', 'Indeed session ended — log in on indeed.com again')
      }
      return { loggedIn: false, indeedStatus: 'not_logged_in', cookieCount: 0 }
    }

    if (indeedStatus !== 'connected') {
      await setIndeedSessionStatus('connected')
    }

    return {
      loggedIn: true,
      indeedStatus: indeedStatus === 'connected' ? 'connected' : indeedStatus || 'not_logged_in',
      cookieCount: snap.cookieCount,
      needsSync: indeedStatus !== 'connected',
    }
  } catch (e) {
    return { loggedIn: false, error: e.message }
  }
}

async function probeNaukriSessionStatus() {
  try {
    const snap = await getNaukriSessionSnapshot()
    const { naukriStatus } = await chrome.storage.local.get('naukriStatus')
    if (!snap.loggedIn) {
      if (naukriStatus === 'connected' || naukriStatus === 'needs_nkparam') {
        await setNaukriSessionStatus('not_logged_in')
        await appendExtensionLog('warn', 'Naukri session ended — log in on naukri.com again')
      }
      return { loggedIn: false, naukriStatus: 'not_logged_in', hasNkparam: false, cookieCount: 0 }
    }

    if (naukriStatus !== 'connected' && snap.hasNkparam) {
      await setNaukriSessionStatus('connected')
    } else if (naukriStatus !== 'connected' && snap.loggedIn) {
      await setNaukriSessionStatus(snap.hasNkparam ? 'connected' : 'needs_nkparam')
    }

    return {
      loggedIn: true,
      naukriStatus: naukriStatus === 'connected' ? 'connected' : naukriStatus || 'not_logged_in',
      hasNkparam: snap.hasNkparam,
      cookieCount: snap.cookieCount,
      needsSync: naukriStatus !== 'connected',
    }
  } catch (e) {
    return { loggedIn: false, error: e.message }
  }
}

async function probeMonsterSessionStatus() {
  try {
    await pullMonsterSessionFromOpenTabs({ injectHooks: true }).catch(() => null)
    const snap = await getMonsterSessionSnapshot()
    const { monsterStatus } = await chrome.storage.local.get('monsterStatus')

    let profileTabOpen = false
    try {
      const tabs = await chrome.tabs.query({ url: ['https://www.monster.com/*', 'https://*.monster.com/*'] })
      profileTabOpen = tabs.some((tab) => /monster\.com\/profile/i.test(String(tab?.url || '')))
    } catch {
      /* ignore */
    }

    const loggedIn = snap.loggedIn || profileTabOpen
    if (!loggedIn) {
      if (monsterStatus === 'connected' || monsterStatus === 'session_invalid') {
        await setMonsterSessionStatus('not_logged_in')
        await appendExtensionLog('warn', 'Monster session ended — log in on monster.com again')
      }
      return {
        loggedIn: false,
        monsterStatus: 'not_logged_in',
        hasDatadome: false,
        cookieCount: snap.cookieCount || 0,
      }
    }

    if (monsterStatus !== 'connected' && (snap.hasDatadome || snap.loggedIn)) {
      await setMonsterSessionStatus('connected')
    }

    const current = await chrome.storage.local.get('monsterStatus')

    return {
      loggedIn: true,
      monsterStatus: current.monsterStatus === 'connected' ? 'connected' : current.monsterStatus || 'connected',
      hasDatadome: snap.hasDatadome,
      cookieCount: snap.cookieCount,
      needsSync: current.monsterStatus !== 'connected',
    }
  } catch (e) {
    return { loggedIn: false, error: e.message }
  }
}

chrome.cookies.onChanged.addListener((changeInfo) => {
  const cookie = changeInfo.cookie
  if (
    cookie.domain.includes('linkedin.com') &&
    (cookie.name === 'li_at' || cookie.name === 'JSESSIONID') &&
    !changeInfo.removed
  ) {
    console.log(`[Extension] LinkedIn cookie changed: ${cookie.name}`)
    appendExtensionLog('info', `LinkedIn cookie updated: ${cookie.name} — sync in ~8s`)
    if (syncDebounceTimer) clearTimeout(syncDebounceTimer)
    syncDebounceTimer = setTimeout(async () => {
      syncDebounceTimer = null
      const allowed = await shouldAutoSyncLinkedIn()
      if (!allowed) {
        await appendExtensionLog('info', 'Skipped auto-sync — LinkedIn active on another device')
        return
      }
      syncLinkedInCookies()
    }, 8000)
  }
})

async function refreshPlatformAccessToken() {
  const { refreshToken, xsrfToken } = await chrome.storage.local.get(['refreshToken', 'xsrfToken'])
  if (!refreshToken) return false
  const authBase = await getAuthApiBase()
  try {
    const res = await fetch(`${authBase}/auth-session/refresh`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(xsrfToken ? { 'X-XSRF-Token': xsrfToken } : {}),
      },
      credentials: 'include',
      body: JSON.stringify({ refreshToken }),
    })
    const data = await res.json().catch(() => ({}))
    const tokens = parseAuthTokens(data)
    if (!res.ok || !tokens?.accessToken) {
      await appendExtensionLog(
        'warn',
        `Token refresh failed (${res.status}): ${data.message || data?.data?.message || res.statusText}`
      )
      await chrome.storage.local.remove(['authToken', 'refreshToken', 'xsrfToken'])
      return false
    }
    const patch = {
      authToken: tokens.accessToken,
      refreshToken: tokens.refreshToken || refreshToken,
      xsrfToken: tokens.xsrfToken || xsrfToken,
    }
    await chrome.storage.local.set(patch)
    await appendExtensionLog('info', 'Access token refreshed (SuperadminBackend)')
    return true
  } catch (e) {
    await appendExtensionLog('warn', `Token refresh network: ${e.message}`)
    await chrome.storage.local.remove(['authToken', 'refreshToken', 'xsrfToken'])
    return false
  }
}

/** Use stored JWT, or bootstrap from candidate portal httpOnly cookies (no popup required). */
async function ensurePlatformAuthToken() {
  const { authToken } = await chrome.storage.local.get('authToken')
  if (authToken) return { ok: true }

  const { dashboardUrl } = await chrome.storage.local.get('dashboardUrl')
  const origins = []
  try {
    origins.push(new URL(dashboardUrl || DEFAULT_DASHBOARD_URL).origin)
  } catch {
    /* ignore */
  }
  try {
    origins.push(await getAuthApiBase())
  } catch {
    /* ignore */
  }

  for (const origin of origins) {
    const cookieUrl = `${origin}/`
    const access =
      (await chrome.cookies.get({ url: cookieUrl, name: 'accessToken' })) ||
      (await chrome.cookies.get({ url: cookieUrl, name: 'access_token' }))
    if (access?.value) {
      await chrome.storage.local.set({ authToken: access.value })
      await appendExtensionLog('info', 'Token loaded from portal session cookie')
      return { ok: true }
    }
    const refresh =
      (await chrome.cookies.get({ url: cookieUrl, name: 'refreshToken' })) ||
      (await chrome.cookies.get({ url: cookieUrl, name: 'refresh_token' }))
    if (refresh?.value) {
      await chrome.storage.local.set({ refreshToken: refresh.value })
      const refreshed = await refreshPlatformAccessToken()
      if (refreshed) {
        await appendExtensionLog('info', 'Token refreshed from portal session')
        return { ok: true }
      }
    }
  }

  return {
    ok: false,
    error: 'NOT_LOGGED_IN_EXTENSION',
    message:
      'Sign in to the candidate portal in this browser. You do not need to open the extension popup.'
  }
}

/** Fetch with Bearer; on 401, try refresh once and retry. */
async function platformAuthFetch(url, options = {}) {
  let { authToken } = await chrome.storage.local.get('authToken')
  if (!authToken) {
    const ensured = await ensurePlatformAuthToken()
    if (!ensured.ok) {
      return new Response(
        JSON.stringify({
          success: false,
          message: ensured.message || 'Sign in to the candidate portal first.'
        }),
        { status: 401, headers: { 'Content-Type': 'application/json' } }
      )
    }
    const stored = await chrome.storage.local.get('authToken')
    authToken = stored.authToken
  }
  if (!authToken) {
    return new Response(
      JSON.stringify({ success: false, message: 'Not authenticated' }),
      { status: 401, headers: { 'Content-Type': 'application/json' } }
    )
  }
  const withAuth = async (token) => {
    const { xsrfToken } = await chrome.storage.local.get('xsrfToken')
    return {
      ...options,
      headers: {
        ...(options.headers || {}),
        Authorization: `Bearer ${token}`,
        ...(xsrfToken ? { 'X-XSRF-Token': xsrfToken } : {}),
      },
    }
  }
  let res = await fetch(url, await withAuth(authToken))
  if (res.status === 401 && (await refreshPlatformAccessToken())) {
    const { authToken: t2 } = await chrome.storage.local.get('authToken')
    if (t2) res = await fetch(url, await withAuth(t2))
  }
  return res
}

async function fetchPlatformQuota() {
  const base = await getCareerApiBase()
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/quota`, {})
    if (!res.ok) return { success: false }
    return await res.json()
  } catch {
    return { success: false }
  }
}

function jobSearchQuotaRemaining(quota, source = 'linkedin') {
  if (!quota?.success) return null
  if (source === 'indeed') {
    return Number(quota.indeedJobsRemaining ?? quota.dailyIndeedJobsLimit ?? 0)
  }
  if (source === 'naukri') {
    return Number(quota.naukriJobsRemaining ?? quota.dailyNaukriJobsLimit ?? quota.dailyIndeedJobsLimit ?? 0)
  }
  if (source === 'monster') {
    return Number(
      quota.monsterJobsRemaining ?? quota.dailyMonsterJobsLimit ?? quota.dailyNaukriJobsLimit ?? quota.dailyIndeedJobsLimit ?? 0
    )
  }
  return Number(quota.linkedinJobsRemaining ?? quota.searchesRemaining ?? 0)
}

/** Job preferences + resume-derived search context (replaces linkedin/search-keywords). */
async function fetchJobSearchPreferencesBundle() {
  const base = await getCareerApiBase()
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/job-search-preferences`, {})
    if (!res.ok) return { prefs: null, ctx: null }
    const data = await res.json()
    if (!data?.success) return { prefs: null, ctx: null }
    return {
      prefs: data.preferences || null,
      ctx: data.searchContext || null,
    }
  } catch {
    return { prefs: null, ctx: null }
  }
}

async function fetchJobSearchContext() {
  const { ctx } = await fetchJobSearchPreferencesBundle()
  return ctx
}

async function fetchJobSearchKeywords() {
  const ctx = await fetchJobSearchContext()
  return ctx?.keywords ? String(ctx.keywords).trim() : ''
}

async function fetchJobSearchPreferences() {
  const { prefs } = await fetchJobSearchPreferencesBundle()
  return prefs
}

const NAUKRI_NO_NEW_JOBS_MSG =
  'No Naukri jobs found for this search. Try again later or update job preferences in Settings.'

async function prepareJobSearchPayload(platform, payload = {}) {
  const { ctx, prefs } = await fetchJobSearchPreferencesBundle()
  const keywords = buildSearchKeywords(platform, prefs, ctx, payload)
  const datePostedDays = resolveDatePostedDays(platform, prefs, payload)
  const filters = buildAutoSearchFilters(platform, prefs, ctx, payload)
  const mergedSkills = mergeResumeSearchSkills(ctx?.skills, filters.skills)
  const querySets = buildJobSearchQuerySets(platform, {
    jobTitle: ctx?.targetRole || filters.jobTitle,
    targetRole: ctx?.targetRole,
    skills: mergedSkills,
    skillsStr: filters.skills,
    experienceTitles: ctx?.experienceTitles,
    keywords,
    combinedKeywords: ctx?.keywords,
  })
  const criteriaFilters = {
    ...filters,
    jobTitle: ctx?.targetRole || filters.jobTitle,
    skills: mergedSkills.length ? mergedSkills.join(', ') : filters.skills,
  }
  const searchCriteria = buildSearchCriteriaSummary(platform, criteriaFilters, keywords, querySets)
  return { ctx, prefs, keywords, jobTitle: keywords, datePostedDays, filters, searchCriteria, querySets }
}

async function scrapeLeadsFromBackend(count) {
  const base = await getCareerApiBase()
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/leads/scrape`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ batchSize: count })
    })
    const data = await res.json().catch(() => ({}))
    return data
  } catch (e) {
    return { ok: false, message: e.message }
  }
}

async function fetchRecentLeads(count) {
  const base = await getCareerApiBase()
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/leads?limit=${count}&period=all`)
    if (!res.ok) return []
    const data = await res.json().catch(() => ({}))
    return Array.isArray(data?.leads) ? data.leads : []
  } catch {
    return []
  }
}

async function addJobToTracker(payload) {
  const base = await getCareerApiBase()
  try {
    const res = await platformAuthFetch(`${base}/candidates/tracker`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload || {})
    })
    const data = await res.json().catch(() => ({}))
    const success = data.success === true
    if (success) {
      return { ...data, httpStatus: res.status, success: true }
    }
    const message =
      data.message ||
      data.error ||
      (res.status === 403 && String(data.message || '').toLowerCase().includes('csrf')
        ? 'Session expired — sign in again in the extension.'
        : null) ||
      (res.status === 401 ? 'Session expired — sign in again.' : null) ||
      (res.status === 403 ? 'Access denied — use a candidate account.' : null) ||
      `Could not add to tracker (HTTP ${res.status}).`
    return { ...data, httpStatus: res.status, success: false, message }
  } catch (e) {
    return { success: false, message: e.message || 'Network error' }
  }
}

async function importJobsToPlatform(jobs) {
  const base = await getCareerApiBase()
  const list = Array.isArray(jobs) ? jobs.slice(0, 40) : []
  if (!list.length) return { success: false, message: 'No jobs to save' }
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/jobs/linkedin/import`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobs: list })
    })
    const data = await res.json().catch(() => ({}))
    return { ...data, httpStatus: res.status, success: data?.success !== false }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

async function importIndeedJobsToPlatform(jobs) {
  const base = await getCareerApiBase()
  const list = Array.isArray(jobs) ? jobs.slice(0, 40) : []
  if (!list.length) return { success: false, message: 'No jobs to save' }
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/jobs/indeed/import`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobs: list })
    })
    const data = await res.json().catch(() => ({}))
    const ok = data?.success === true || (res.ok && data?.success !== false)
    return { ...data, httpStatus: res.status, success: ok }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

async function importNaukriJobsToPlatform(jobs) {
  const base = await getCareerApiBase()
  const list = Array.isArray(jobs) ? jobs.slice(0, 40) : []
  if (!list.length) return { success: false, message: 'No jobs to save' }
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/jobs/naukri/import`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobs: list })
    })
    const data = await res.json().catch(() => ({}))
    return { ...data, httpStatus: res.status, success: data?.success !== false }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

async function importMonsterJobsToPlatform(jobs) {
  const base = await getCareerApiBase()
  const list = Array.isArray(jobs) ? jobs.slice(0, 40) : []
  if (!list.length) return { success: false, message: 'No jobs to save' }
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/jobs/monster/import`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobs: list })
    })
    const data = await res.json().catch(() => ({}))
    return { ...data, httpStatus: res.status, success: data?.success !== false }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

/** Always push searched jobs into Application Tracker Saved (LinkedIn or Indeed). */
async function syncSearchJobsToTracker(jobs, platform = 'linkedin') {
  const base = await getCareerApiBase()
  const list = Array.isArray(jobs) ? jobs.slice(0, 40) : []
  if (!list.length) return { success: false, savedToTracker: 0, alreadyInTracker: 0 }
  try {
    const res = await platformAuthFetch(`${base}/candidates/tracker/sync-search`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobs: list, platform })
    })
    const data = await res.json().catch(() => ({}))
    return {
      ...data,
      httpStatus: res.status,
      success: data?.success === true,
      savedToTracker: Number(data?.savedToTracker) || 0,
      alreadyInTracker: Number(data?.alreadyInTracker) || 0
    }
  } catch (e) {
    return { success: false, message: e.message, savedToTracker: 0, alreadyInTracker: 0 }
  }
}

/** Apply match scores returned from import API (new DB rows only — backend already scored them). */
function applyImportMatchScores(formatted, importedJobs) {
  if (!Array.isArray(formatted) || !Array.isArray(importedJobs) || !importedJobs.length) return
  const scoreById = new Map()
  for (const row of importedJobs) {
    const id = String(row?.jobId || row?.naukriJobId || row?.indeedJobId || row?.monsterJobId || '').trim()
    if (!id) continue
    const score = row.matchPercent ?? row.matchScore
    if (score == null || !Number.isFinite(Number(score))) continue
    scoreById.set(id, Number(score))
  }
  for (const job of formatted) {
    const score = scoreById.get(String(job.jobId || ''))
    if (score != null) job.matchScore = score
  }
}

async function importProfilesToPlatform(profiles) {
  const base = await getCareerApiBase()
  const list = Array.isArray(profiles) ? profiles.slice(0, 24) : []
  if (!list.length) return { success: false, message: 'No profiles to save' }
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/leads/import`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ profiles: list })
    })
    const data = await res.json().catch(() => ({}))
    return { ...data, httpStatus: res.status }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

function formatJobForClient(job) {
  const jobId = String(job?.jobId || '').trim()
  const jobUrl =
    String(job?.jobUrl || '').trim() ||
    (jobId ? `https://www.linkedin.com/jobs/view/${jobId}` : '')
  const easy = Boolean(job?.isEasyApply)
  return {
    jobId,
    title: String(job?.title || '').trim() || 'Role',
    company: String(job?.company || '').trim() || '—',
    location: String(job?.location || '').trim() || '—',
    jobUrl,
    isEasyApply: easy,
    applyLabel: easy ? 'Easy Apply on LinkedIn' : 'View & apply on LinkedIn'
  }
}

function formatIndeedJobForClient(job) {
  const jobId = String(job?.jobId || '').trim()
  const jobUrl =
    String(job?.jobUrl || '').trim() ||
    (jobId ? `https://in.indeed.com/viewjob?jk=${jobId}` : '')
  const indeedApply = Boolean(job?.isIndeedApply)
  const salaryText = job?.salaryText || job?.salary || null
  return {
    jobId,
    title: String(job?.title || '').trim() || 'Role',
    company: String(job?.company || '').trim() || '—',
    location: String(job?.location || '').trim() || '—',
    jobUrl,
    source: 'indeed',
    salary: salaryText,
    salaryText,
    salaryMin: job?.salaryMin ?? null,
    salaryMax: job?.salaryMax ?? null,
    salaryCurrency: job?.salaryCurrency || null,
    salaryPeriod: job?.salaryPeriod || null,
    deadline: job?.deadline || null,
    isIndeedApply: indeedApply,
    applyLabel: indeedApply ? 'Indeed Apply' : 'View & apply on Indeed'
  }
}

const CANDIDATE_PORTAL_TAB_URLS = [
  'http://192.168.1.65:4003/*',
  'https://192.168.1.65:4003/*',
  'http://localhost:4003/*',
  'https://localhost:4003/*',
  'http://127.0.0.1:4003/*',
  'https://127.0.0.1:4003/*',
]

async function notifyCandidatePortalIndeedJobsSaved() {
  try {
    const tabs = await chrome.tabs.query({ url: CANDIDATE_PORTAL_TAB_URLS })
    for (const tab of tabs) {
      if (!tab?.id) continue
      chrome.tabs.sendMessage(tab.id, { type: 'INDEED_JOBS_SAVED' }, () => {
        void chrome.runtime.lastError
      })
    }
  } catch (_) {}
}

/** Search in browser + import to dashboard DB + tracker (shared by popup and dashboard). */
async function saveIndeedSearchResults(fetched, keywords) {
  const raw = dedupeSearchJobs(Array.isArray(fetched) ? fetched : [], 'indeed')
  const list = raw.length
    ? raw.map((j) => padIndeedJobForImport(j)).filter((j) => j.jobId && j.title && j.company)
    : []
  const formatted = list.map(formatIndeedJobForClient)
  let savedToLibrary = 0
  let savedToTracker = 0
  let alreadyInTracker = 0
  let duplicatesSkipped = 0
  let importMessage = ''

  if (list.length) {
    const importOut = await importIndeedJobsToPlatform(list)
    savedToLibrary = Number(importOut.inserted) || 0
    importMessage = importOut.message || ''
    alreadyInTracker = Number(importOut.alreadyInTracker) || 0
    savedToTracker = Number(importOut.savedToTracker) || 0

    const trackerOut = await syncSearchJobsToTracker(list, 'indeed')
    savedToTracker = Math.max(savedToTracker, Number(trackerOut.savedToTracker) || 0)
    alreadyInTracker = Math.max(alreadyInTracker, Number(trackerOut.alreadyInTracker) || 0)
    duplicatesSkipped = Math.max(0, list.length - savedToLibrary)
    applyImportMatchScores(formatted, importOut.jobs)
  }

  const quotaAfter = await fetchPlatformQuota()
  if (list.length) {
    notifyCandidatePortalIndeedJobsSaved().catch(() => {})
  }
  return {
    formatted,
    savedToLibrary,
    savedToTracker,
    alreadyInTracker,
    duplicatesSkipped,
    importMessage,
    quotaAfter,
    keywordsUsed: keywords,
  }
}

function sortNaukriJobsByLatest(jobs) {
  return [...jobs].sort((a, b) => {
    const ta = a?.postedAt ? new Date(a.postedAt).getTime() : 0
    const tb = b?.postedAt ? new Date(b.postedAt).getTime() : 0
    return tb - ta
  })
}

/** Search in browser + import new Naukri jobs (shared by popup and dashboard). */
async function saveNaukriSearchResults(fetched, keywords) {
  const raw = dedupeSearchJobs(sortNaukriJobsByLatest(Array.isArray(fetched) ? fetched : []), 'naukri')
  const formatted = raw.map(formatNaukriJobForClient)
  let savedToLibrary = 0
  let savedToTracker = 0
  let alreadyInTracker = 0
  let duplicatesSkipped = 0
  let importMessage = ''

  if (raw.length) {
    const importOut = await importNaukriJobsToPlatform(raw)
    savedToLibrary = Number(importOut.inserted) || 0
    importMessage = importOut.message || ''
    alreadyInTracker = Number(importOut.alreadyInTracker) || 0
    savedToTracker = Number(importOut.savedToTracker) || 0
    duplicatesSkipped = Number(importOut.skippedDuplicates) || Math.max(0, raw.length - savedToLibrary)

    if (savedToLibrary === 0 && savedToTracker === 0 && importOut.success === false) {
      const trackerOut = await syncSearchJobsToTracker(raw, 'naukri')
      savedToTracker = Number(trackerOut.savedToTracker) || 0
      alreadyInTracker = Number(trackerOut.alreadyInTracker) || 0
    }

    applyImportMatchScores(formatted, importOut.jobs)
  }

  const quotaAfter = await fetchPlatformQuota()
  return {
    formatted,
    savedToLibrary,
    savedToTracker,
    alreadyInTracker,
    duplicatesSkipped,
    importMessage,
    quotaAfter,
    keywordsUsed: keywords,
  }
}

/** Search in browser + import new Monster jobs (shared by popup and dashboard). */
async function saveMonsterSearchResults(fetched, keywords) {
  const raw = dedupeSearchJobs(Array.isArray(fetched) ? fetched : [], 'monster')
  const formatted = raw.map(formatMonsterJobForClient)
  let savedToLibrary = 0
  let savedToTracker = 0
  let alreadyInTracker = 0
  let duplicatesSkipped = 0
  let importMessage = ''

  if (raw.length) {
    const importOut = await importMonsterJobsToPlatform(raw)
    savedToLibrary = Number(importOut.inserted) || 0
    importMessage = importOut.message || ''
    alreadyInTracker = Number(importOut.alreadyInTracker) || 0
    savedToTracker = Number(importOut.savedToTracker) || 0
    duplicatesSkipped = Number(importOut.skippedDuplicates) || Math.max(0, raw.length - savedToLibrary)

    const trackerOut = await syncSearchJobsToTracker(raw, 'monster')
    savedToTracker = Math.max(savedToTracker, Number(trackerOut.savedToTracker) || 0)
    alreadyInTracker = Math.max(alreadyInTracker, Number(trackerOut.alreadyInTracker) || 0)

    applyImportMatchScores(formatted, importOut.jobs)
  }

  const quotaAfter = await fetchPlatformQuota()
  return {
    formatted,
    savedToLibrary,
    savedToTracker,
    alreadyInTracker,
    duplicatesSkipped,
    importMessage,
    quotaAfter,
    keywordsUsed: keywords,
  }
}

function formatNaukriJobForClient(job) {
  const jobId = String(job?.jobId || job?.naukriJobId || '').trim()
  const jobUrl = canonicalNaukriJobUrl(jobId, job?.jobUrl || job?.jdURL || '')
  const salaryText = job?.salaryText || job?.salary || null
  const postedAt = job?.postedAt || null
  return {
    jobId,
    title: String(job?.title || '').trim() || 'Role',
    company: String(job?.company || '').trim() || '—',
    location: String(job?.location || '').trim() || '—',
    description: String(job?.description || '').trim(),
    jobUrl,
    postedAt: postedAt instanceof Date ? postedAt.toISOString() : postedAt,
    source: 'naukri',
    salary: salaryText,
    salaryText,
    salaryMin: job?.salaryMin ?? null,
    salaryMax: job?.salaryMax ?? null,
    salaryCurrency: job?.salaryCurrency || null,
    salaryPeriod: job?.salaryPeriod || null,
    employmentType: job?.employmentType || null,
    workplaceType: job?.workplaceType || null,
    education: job?.education || null,
    domain: job?.domain || null,
    skills: job?.skills || null,
    experience: job?.experience || null,
    applyLabel: 'View & apply on Naukri'
  }
}

function formatMonsterJobForClient(job) {
  const jobId = String(job?.jobId || job?.monsterJobId || '').trim()
  const jobUrl =
    String(job?.jobUrl || job?.canonicalUrl || '').trim() ||
    (jobId ? `https://www.monster.com/job-openings/${jobId}` : '')
  const salaryText = String(job?.salaryText || job?.salary || '').trim()
  return {
    jobId,
    title: String(job?.title || '').trim() || 'Untitled role',
    company: String(job?.company || '').trim() || 'Company not listed',
    location: String(job?.location || '').trim() || '—',
    jobUrl,
    source: 'monster',
    salary: salaryText,
    salaryText,
    salaryMin: job?.salaryMin ?? null,
    salaryMax: job?.salaryMax ?? null,
    salaryCurrency: job?.salaryCurrency || null,
    salaryPeriod: job?.salaryPeriod || null,
    applyLabel: 'View & apply on Monster',
  }
}

function formatProfileForClient(profile) {
  const slug = String(profile?.publicIdentifier || '').trim()
  const profileUrl =
    String(profile?.profileUrl || '').trim() ||
    (slug ? `https://www.linkedin.com/in/${slug}` : '')
  const name = [profile?.firstName, profile?.lastName].filter(Boolean).join(' ').trim() || slug || 'Profile'
  return {
    publicIdentifier: slug,
    displayName: name,
    headline: String(profile?.headline || '').trim(),
    company: String(profile?.company || '').trim(),
    location: String(profile?.location || '').trim(),
    profileUrl,
    connectLabel: 'Open profile to connect'
  }
}

async function recordPlatformConnectionUsage() {
  const base = await getCareerApiBase()
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/quota/connection/consume`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    })
    if (!res.ok) {
      let t = res.statusText
      try {
        const j = await res.json()
        t = j.message || JSON.stringify(j)
      } catch {
        /* ignore */
      }
      await appendExtensionLog('warn', `Platform connection quota consume failed (${res.status}): ${t}`)
    }
  } catch (e) {
    await appendExtensionLog('warn', `Platform connection quota consume network: ${e.message}`)
  }
}

// ─── LinkedIn device sync helpers ─────────────────────────────────────────────
async function fetchLinkedInDeviceStatus() {
  const auth = await ensurePlatformAuthToken()
  if (!auth.ok) return null
  const extensionDeviceId = await getExtensionDeviceId()
  const API_BASE = await getCareerApiBase()
  const url = `${API_BASE}/candidates/career/linkedin/device-status?extensionDeviceId=${encodeURIComponent(extensionDeviceId)}`
  try {
    const res = await platformAuthFetch(url, { method: 'GET' })
    if (!res.ok) return null
    const data = await res.json()
    const superseded = Boolean(data.hasActiveDevice && data.isThisDeviceActive === false)
    await chrome.storage.local.set({
      linkedinActiveDevice: data.activeDevice || null,
      linkedinDeviceSuperseded: superseded,
    })
    if (superseded) {
      await updateStatus('disconnected_other_device')
    } else if ((await chrome.storage.local.get('linkedinStatus')).linkedinStatus === 'disconnected_other_device') {
      const { liAtCookie } = await getLinkedInAuthCookies()
      if (liAtCookie) await updateStatus('connected')
    }
    return data
  } catch {
    return null
  }
}

async function shouldAutoSyncLinkedIn() {
  const { linkedinDeviceSuperseded } = await chrome.storage.local.get('linkedinDeviceSuperseded')
  if (linkedinDeviceSuperseded) return false
  const status = await fetchLinkedInDeviceStatus()
  if (!status) return true
  if (status.hasActiveDevice && status.isThisDeviceActive === false) return false
  return true
}

async function applyLocalDeviceSyncSuccess(saveOut = {}) {
  await chrome.storage.local.set({
    linkedinDeviceSuperseded: false,
    linkedinActiveDevice: saveOut.platformLabel
      ? { platformLabel: saveOut.platformLabel, id: saveOut.deviceId }
      : null,
  })
}

// ─── Core: read and send cookies to backend ───────────────────────────────────
async function syncLinkedInCookies(options = {}) {
  const takeover = options.takeover === true
  await appendExtensionLog('info', `syncLinkedInCookies() started${takeover ? ' (takeover)' : ''}`)

  const auth = await ensurePlatformAuthToken()
  if (!auth.ok) {
    console.log('[Extension] No platform session:', auth.message)
    await appendExtensionLog('warn', auth.message || 'No platform auth')
    await updateStatus('not_logged_in')
    return {
      ok: false,
      error: auth.error || 'NOT_LOGGED_IN_EXTENSION',
      message: auth.message,
      linkedinStatus: 'not_logged_in'
    }
  }

  if (!takeover) {
    const deviceStatus = await fetchLinkedInDeviceStatus()
    if (deviceStatus?.hasActiveDevice && deviceStatus.isThisDeviceActive === false) {
      await updateStatus('disconnected_other_device')
      return {
        ok: false,
        conflict: true,
        error: 'LINKEDIN_SYNC_ACTIVE_ON_OTHER_DEVICE',
        message: 'LinkedIn is already synced on another device.',
        activeDevice: deviceStatus.activeDevice,
        linkedinStatus: 'disconnected_other_device',
      }
    }
  }

  try {
    const { cookieHeader, liAtCookie, jsessionCookie } = await getLinkedInAuthCookies()

    if (!liAtCookie || !jsessionCookie) {
      console.log('[Extension] LinkedIn cookies not found. User may not be logged in.')
      await appendExtensionLog('warn', 'Missing li_at or JSESSIONID — open https://www.linkedin.com and log in')
      await updateStatus('not_logged_in')
      return {
        ok: false,
        error: 'LINKEDIN_NOT_LOGGED_IN',
        message: 'Log in at linkedin.com in this browser, then sync again.',
        linkedinStatus: 'not_logged_in'
      }
    }

    const extensionDeviceId = await getExtensionDeviceId()
    const deviceMeta = await collectDeviceMeta()
    const API_BASE = await getCareerApiBase()
    const url = `${API_BASE}/candidates/career/sync`
    await appendExtensionLog('info', `POST ${url} …`)

    const res = await platformAuthFetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        liAt: liAtCookie.value,
        jsessionId: jsessionCookie.value,
        cookieHeader,
        source: 'extension',
        extensionDeviceId,
        userAgent: deviceMeta.userAgent,
        timezone: deviceMeta.timezone,
        timezoneOffset: deviceMeta.timezoneOffset,
        screen: deviceMeta.screen,
        takeover,
      }),
    })

    if (res.status === 409) {
      let payload = {}
      try {
        payload = await res.json()
      } catch {
        /* ignore */
      }
      await updateStatus('disconnected_other_device')
      await chrome.storage.local.set({
        linkedinDeviceSuperseded: true,
        linkedinActiveDevice: payload.activeDevice || null,
      })
      await appendExtensionLog('warn', 'LinkedIn sync blocked — active on another device')
      return {
        ok: false,
        conflict: true,
        error: payload.reason || 'LINKEDIN_SYNC_ACTIVE_ON_OTHER_DEVICE',
        message: payload.message || 'LinkedIn is already synced on another device.',
        activeDevice: payload.activeDevice,
        linkedinStatus: 'disconnected_other_device',
      }
    }

    if (res.ok) {
      const body = await res.json().catch(() => ({}))
      const lastSync = new Date().toISOString()
      console.log('[Extension] ✅ LinkedIn cookies synced to backend')
      await appendExtensionLog('success', `Backend OK (${res.status}) — cookies saved`)
      await updateStatus('connected')
      await applyLocalDeviceSyncSuccess(body)
      await chrome.storage.local.set({ lastSync })
      return {
        ok: true,
        linkedinStatus: 'connected',
        lastSync,
        platformLabel: body.platformLabel,
        previousDevice: body.previousDevice,
      }
    }

    let errText = res.statusText
    let errJson = {}
    try {
      errJson = await res.json()
      errText = errJson.error || errJson.message || JSON.stringify(errJson)
    } catch {
      /* ignore */
    }
    console.error('[Extension] Sync failed:', errText)
    await appendExtensionLog('error', `Backend error ${res.status}: ${errText}`)
    if (res.status === 401) {
      await chrome.storage.local.remove(['authToken', 'refreshToken', 'xsrfToken'])
      await updateStatus('not_logged_in')
      return {
        ok: false,
        error: 'NOT_LOGGED_IN_EXTENSION',
        message: errText || 'Platform session expired. Sign in to the candidate portal again.',
        linkedinStatus: 'not_logged_in'
      }
    }
    await updateStatus('error')
    return {
      ok: false,
      error: 'SYNC_FAILED',
      message: errText || `Backend error ${res.status}`,
      linkedinStatus: 'error'
    }
  } catch (err) {
    console.error('[Extension] Network error:', err.message)
    await appendExtensionLog('error', `Network: ${err.message}`)
    await updateStatus('error')
    return {
      ok: false,
      error: 'NETWORK_ERROR',
      message: err.message || 'Network error',
      linkedinStatus: 'error'
    }
  }
}

function buildNaukriSearchSuccessResponse({ saved, fetched, keywords, requestedCount, filters, searchCriteria }) {
  const quotaAfter = saved.quotaAfter
  const trackerNote = saved.savedToTracker > 0 ? `${saved.savedToTracker} added to Application Tracker` : ''
  const creditNote =
    saved.savedToLibrary > 0
      ? `${saved.savedToLibrary} new job${saved.savedToLibrary === 1 ? '' : 's'} saved to your library${trackerNote ? ` · ${trackerNote}` : ''}.`
      : saved.savedToTracker > 0
        ? `${saved.savedToTracker} job${saved.savedToTracker === 1 ? '' : 's'} added to Application Tracker.`
        : saved.importMessage || 'Jobs matched your search.'

  return {
    success: true,
    keywordsUsed: keywords,
    searchCriteria: searchCriteria || buildSearchCriteriaSummary('naukri', filters, keywords),
    requestedCount,
    totalFetched: Array.isArray(fetched) ? fetched.length : saved.formatted.length,
    shownCount: Math.min(saved.formatted.length, 10),
    inserted: saved.savedToLibrary,
    savedToLibrary: saved.savedToLibrary,
    savedToTracker: saved.savedToTracker,
    alreadyInTracker: saved.alreadyInTracker || 0,
    duplicatesSkipped: saved.duplicatesSkipped,
    importMessage: saved.importMessage,
    creditNote,
    searchesRemaining: quotaAfter?.naukriJobsRemaining,
    searchesUsed: quotaAfter?.naukriJobsUsed,
    dailySearchLimit: quotaAfter?.dailyNaukriJobsLimit ?? quotaAfter?.dailyIndeedJobsLimit,
    naukriJobsRemaining: quotaAfter?.naukriJobsRemaining,
    dailyNaukriJobsLimit: quotaAfter?.dailyNaukriJobsLimit ?? quotaAfter?.dailyIndeedJobsLimit,
    applyHowTo:
      saved.formatted.length > 0
        ? 'Click Open & apply on each row to apply on Naukri. Saved jobs appear under Job hunt → Naukri jobs and Application Tracker in the dashboard.'
        : '',
    jobs: saved.formatted.slice(0, 10),
    source: 'naukri',
  }
}

function buildMonsterSearchSuccessResponse({ data, keywords, requestedCount, searchCriteria, filters }) {
  const formatted = (Array.isArray(data?.jobs) ? data.jobs : []).map(formatMonsterJobForClient)
  const savedToLibrary = Number(data?.inserted) || 0
  const savedToTracker = Number(data?.savedToTracker) || 0
  const quotaAfter = data?.usage || {}
  const trackerNote = savedToTracker > 0 ? `${savedToTracker} added to Application Tracker` : ''
  const creditNote =
    savedToLibrary > 0
      ? `${savedToLibrary} new job${savedToLibrary === 1 ? '' : 's'} saved to your library${trackerNote ? ` · ${trackerNote}` : ''}.`
      : savedToTracker > 0
        ? `${savedToTracker} job${savedToTracker === 1 ? '' : 's'} added to Application Tracker.`
        : formatted.length
          ? 'Jobs matched your search.'
          : ''

  return {
    success: true,
    keywordsUsed: keywords,
    searchCriteria: searchCriteria || buildSearchCriteriaSummary('monster', filters, keywords),
    requestedCount,
    totalFetched: formatted.length,
    shownCount: Math.min(formatted.length, 10),
    savedToLibrary,
    savedToTracker,
    alreadyInTracker: Number(data?.alreadyInTracker) || 0,
    duplicatesSkipped: Number(data?.skippedDuplicates) || 0,
    importMessage: creditNote,
    creditNote,
    searchesRemaining: quotaAfter?.monsterJobsRemaining,
    searchesUsed: quotaAfter?.monsterJobsUsed,
    dailySearchLimit:
      quotaAfter?.dailyMonsterJobsLimit ?? quotaAfter?.dailyNaukriJobsLimit ?? quotaAfter?.dailyIndeedJobsLimit,
    monsterJobsRemaining: quotaAfter?.monsterJobsRemaining,
    dailyMonsterJobsLimit:
      quotaAfter?.dailyMonsterJobsLimit ?? quotaAfter?.dailyNaukriJobsLimit ?? quotaAfter?.dailyIndeedJobsLimit,
    applyHowTo:
      'Click View & apply on each row to apply on Monster. Saved jobs appear under Job hunt → Monster jobs and Application Tracker in the dashboard.',
    jobs: formatted.slice(0, 10),
    source: 'monster',
  }
}

async function runNaukriExtensionSearchFlow({ keywords, ctx, datePostedDays, naukriFilters, requestedCount, querySets, filters }) {
  await captureNkparamSilently()

  const snap = await getNaukriSessionSnapshot()
  if (!snap.loggedIn) {
    const err = new Error('Log in at naukri.com in this browser, then search again.')
    err.code = 'NAUKRI_NOT_LOGGED_IN'
    throw err
  }

  if (!snap.nkparam) {
    await appendExtensionLog('info', 'Refreshing Naukri session in a background tab…')
  }

  const { jobs: rawJobs } = await searchNaukriJobsInExtension({
    jobTitle: filters?.jobTitle || keywords,
    keywords,
    querySets,
    targetRole: ctx?.targetRole,
    skills: mergeResumeSearchSkills(ctx?.skills, filters?.skills),
    skillsStr: filters?.skills,
    experienceTitles: ctx?.experienceTitles,
    combinedKeywords: ctx?.keywords,
    count: requestedCount,
    datePostedDays,
    ...naukriFilters,
  })
  const fetched = Array.isArray(rawJobs) ? rawJobs : []
  if (!fetched.length) return { empty: true }
  const saved = await saveNaukriSearchResults(fetched, keywords)
  return { success: true, saved, fetched }
}

// ─── Handle messages from popup ───────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SYNC_NOW' || message.type === 'SYNC_LINKEDIN_NOW') {
    appendExtensionLog('info', 'LinkedIn sync requested')
    syncLinkedInCookies({ takeover: message.takeover === true }).then((out) =>
      sendResponse({
        success: out?.ok === true,
        ok: out?.ok === true,
        error: out?.error,
        message: out?.message,
        linkedinStatus: out?.linkedinStatus,
        lastSync: out?.lastSync,
        conflict: out?.conflict === true,
        activeDevice: out?.activeDevice,
        platformLabel: out?.platformLabel,
        previousDevice: out?.previousDevice,
      })
    )
    return true
  }

  if (message.type === 'GET_LINKEDIN_DEVICE_STATUS') {
    fetchLinkedInDeviceStatus().then((out) =>
      sendResponse({ success: Boolean(out), ...(out || {}) })
    )
    return true
  }

  if (message.type === 'OPEN_INDEED_LOGIN') {
    chrome.tabs.create({ url: 'https://in.indeed.com/', active: true }).then(() => {
      sendResponse({ success: true })
    })
    return true
  }

  if (message.type === 'MONSTER_SESSION_CAPTURED') {
    persistMonsterSessionMeta(message.payload || {})
      .then(() => probeMonsterSessionStatus())
      .then(() => sendResponse({ success: true }))
    return true
  }

  if (message.type === 'OPEN_MONSTER_LOGIN') {
    chrome.tabs.create({ url: 'https://www.monster.com/jobs/search', active: true }).then(() => {
      sendResponse({ success: true })
    })
    return true
  }

  if (message.type === 'NAUKRI_NKPARAM_CAPTURED') {
    pullNkparamFromOpenNaukriTabs()
      .then(() => probeNaukriSessionStatus())
      .then((probe) => sendResponse({ success: true, ...probe }))
    return true
  }

  if (message.type === 'NAUKRI_PAGE_ACTIVE') {
    pullNkparamFromOpenNaukriTabs()
      .then(() => probeNaukriSessionStatus())
      .then((probe) => sendResponse({ success: true, ...probe }))
    return true
  }

  if (message.type === 'PROBE_NAUKRI_SESSION') {
    probeNaukriSessionStatus().then(sendResponse)
    return true
  }

  if (message.type === 'OPEN_NAUKRI_LOGIN') {
    chrome.tabs.create({ url: 'https://www.naukri.com/', active: true }).then(() => {
      sendResponse({ success: true })
    })
    return true
  }

  if (message.type === 'SET_AUTH_TOKEN') {
    ;(async () => {
      const stored = await chrome.storage.local.get(['authToken', 'refreshToken', 'xsrfToken'])
      const nextRefresh = 'refreshToken' in message ? message.refreshToken || null : stored.refreshToken
      const nextXsrf = 'xsrfToken' in message ? message.xsrfToken || null : stored.xsrfToken
      const unchanged =
        stored.authToken === message.token &&
        (stored.refreshToken || null) === (nextRefresh || null) &&
        (stored.xsrfToken || null) === (nextXsrf || null)
      if (unchanged) {
        sendResponse({ success: true, skipped: true })
        return
      }
      const patch = { authToken: message.token }
      if ('refreshToken' in message) patch.refreshToken = nextRefresh
      if ('xsrfToken' in message) patch.xsrfToken = nextXsrf
      await chrome.storage.local.set(patch)
      sendResponse({ success: true })
      await appendExtensionLog('info', 'Platform token saved — syncing LinkedIn cookies')
      scheduleAuthCareerSync('set-auth-token')
    })()
    return true
  }

  if (message.type === 'REFRESH_PLATFORM_TOKEN') {
    refreshPlatformAccessToken().then((ok) => sendResponse({ success: ok }))
    return true
  }

  if (message.type === 'GET_STATUS') {
    chrome.storage.local
      .get([
        'linkedinStatus',
        'indeedStatus',
        'naukriStatus',
        'monsterStatus',
        'lastSync',
        'lastIndeedSync',
        'lastNaukriSync',
        'lastMonsterSync',
        'authToken',
        'extensionLog',
        'careerApiBase',
        'aiChatApiBase',
        'linkedinActiveDevice',
        'linkedinDeviceSuperseded',
      ])
      .then(async (data) => {
        const career = normalizeVppoApiBase(data.careerApiBase, DEFAULT_CAREER_API_BASE)
        const ai = normalizeVppoApiBase(data.aiChatApiBase, DEFAULT_AI_CHAT_API_BASE)
        if (stripTrailingSlashes(data.careerApiBase) !== career || stripTrailingSlashes(data.aiChatApiBase) !== ai) {
          await chrome.storage.local.set({ careerApiBase: career, aiChatApiBase: ai })
        }
        if (data.authToken) {
          void probeMonsterSessionStatus().catch(() => null)
          void fetchLinkedInDeviceStatus().catch(() => null)
        }
        sendResponse({ ...data, careerApiBase: career, aiChatApiBase: ai })
      })
      .catch((err) => {
        sendResponse({ authToken: null, error: err?.message || 'GET_STATUS failed' })
      })
    return true
  }

  if (message.type === 'CLEAR_EXTENSION_LOG') {
    chrome.storage.local.set({ extensionLog: [] }).then(() => sendResponse({ success: true }))
    return true
  }

  if (message.type === 'SEND_CONNECTION_REQUEST') {
    handleDirectConnectionRequest(message.payload).then(sendResponse)
    return true
  }

  if (message.type === 'PEOPLE_SEARCH') {
    ;(async () => {
      const { authToken } = await chrome.storage.local.get('authToken')
      if (!authToken) {
        sendResponse({ success: false, error: 'Not logged into platform (open extension and sign in)' })
        return
      }
      const quota = await fetchPlatformQuota()
      if (quota?.success === true && Number(quota.searchesRemaining) <= 0) {
        await appendExtensionLog('warn', 'Platform daily search limit reached')
        sendResponse({ success: false, error: 'PLATFORM_SEARCH_LIMIT' })
        return
      }
      try {
        const out = await searchPeopleInExtension(message.payload || {})
        sendResponse({
          success: true,
          profiles: out?.profiles || [],
          diagnostics: out?.diagnostics
        })
      } catch (e) {
        await appendExtensionLog('error', `People search: ${e?.message || e}`)
        sendResponse({
          success: false,
          error: e?.message || String(e),
          code: e?.code || ''
        })
      }
    })()
    return true
  }

  if (message.type === 'JOB_SEARCH') {
    ;(async () => {
      const { authToken } = await chrome.storage.local.get('authToken')
      if (!authToken) {
        sendResponse({ success: false, error: 'Not logged into platform (open extension and sign in)' })
        return
      }
      const quota = await fetchPlatformQuota()
      if (quota?.success === true && Number(quota.searchesRemaining) <= 0) {
        await appendExtensionLog('warn', 'Platform daily search limit reached (jobs)')
        sendResponse({ success: false, error: 'PLATFORM_SEARCH_LIMIT' })
        return
      }
      try {
        const { ctx, keywords, datePostedDays } = await prepareJobSearchPayload('linkedin', message.payload || {})
        const payload = {
          ...(message.payload || {}),
          keywords,
          datePostedDays,
          experienceLevel:
            message.payload?.experienceLevel ?? ctx?.filters?.linkedin?.experienceLevel,
        }
        const { jobs } = await searchJobsInExtension(payload)
        sendResponse({ success: true, jobs: jobs || [] })
      } catch (e) {
        await appendExtensionLog('error', `Job search: ${e?.message || e}`)
        sendResponse({
          success: false,
          error: e?.message || String(e),
          code: e?.code || ''
        })
      }
    })()
    return true
  }

  if (message.type === 'INDEED_JOB_SEARCH') {
    ;(async () => {
      try {
        const out = await executeAgentClientTool({
          name: 'search_indeed_jobs_in_browser',
          args: message.payload || {},
        })
        if (!out?.success) {
          sendResponse({
            success: false,
            error: out?.error || 'INDEED_SEARCH_FAILED',
            message: out?.message || out?.error || 'Indeed job search failed',
            code: out?.code || out?.error || '',
          })
          return
        }
        sendResponse({
          success: true,
          jobs: out.jobs || [],
          source: 'extension',
          keywords: out.keywordsUsed,
          inserted: out.savedToLibrary ?? 0,
          savedToTracker: out.savedToTracker ?? 0,
          alreadyInTracker: out.alreadyInTracker ?? 0,
          duplicatesSkipped: out.duplicatesSkipped ?? 0,
          message: out.importMessage || out.creditNote || '',
          usage: {
            indeedJobsRemaining: out.indeedJobsRemaining ?? out.searchesRemaining,
            indeedJobsUsed: out.searchesUsed,
          },
        })
      } catch (e) {
        await appendExtensionLog('error', `Indeed job search: ${e?.message || e}`)
        if (e?.code === 'COOKIE_EXPIRED') {
          await setIndeedSessionStatus('session_invalid')
        }
        sendResponse({
          success: false,
          error: e?.message || String(e),
          message: e?.message || String(e),
          code: e?.code || '',
        })
      }
    })()
    return true
  }

  if (message.type === 'NAUKRI_JOB_SEARCH') {
    ;(async () => {
      try {
        const out = await executeAgentClientTool({
          name: 'search_naukri_jobs_in_browser',
          args: message.payload || {},
        })
        if (!out?.success) {
          sendResponse({
            success: false,
            error: out?.error || out?.code || 'NAUKRI_SEARCH_FAILED',
            message: out?.message || out?.error || 'Naukri job search failed',
            code: out?.code || out?.error || '',
            jobs: out?.jobs || [],
          })
          return
        }
        sendResponse({
          success: true,
          jobs: out.jobs || [],
          source: 'naukri',
          keywords: out.keywordsUsed,
          inserted: out.savedToLibrary ?? 0,
          savedToLibrary: out.savedToLibrary ?? 0,
          savedToTracker: out.savedToTracker ?? 0,
          alreadyInTracker: out.alreadyInTracker ?? 0,
          duplicatesSkipped: out.duplicatesSkipped ?? 0,
          totalFetched: out.totalFetched ?? 0,
          message: out.importMessage || out.creditNote || '',
          creditNote: out.creditNote,
        })
      } catch (e) {
        await appendExtensionLog('error', `Naukri job search: ${e?.message || e}`)
        sendResponse({
          success: false,
          error: e?.code || 'SEARCH_FAILED',
          message: e?.message || String(e),
          code: e?.code || '',
        })
      }
    })()
    return true
  }

  if (message.type === 'MONSTER_JOB_SEARCH') {
    ;(async () => {
      const { authToken } = await chrome.storage.local.get('authToken')
      if (!authToken) {
        sendResponse({ success: false, error: 'NOT_LOGGED_IN', message: 'Sign in to the candidate portal first.' })
        return
      }
      const quota = await fetchPlatformQuota()
      if (quota?.success === true && jobSearchQuotaRemaining(quota, 'monster') <= 0) {
        await appendExtensionLog('warn', 'Platform daily Monster job search limit reached')
        sendResponse({ success: false, error: 'PLATFORM_SEARCH_LIMIT' })
        return
      }

      const sessionOut = await ensureBrowserSessionReady('monster')
      if (sessionOut?.ok !== true) {
        sendResponse({
          success: false,
          error: sessionOut?.error || 'MONSTER_NOT_LOGGED_IN',
          message:
            sessionOut?.message ||
            'Open monster.com in Chrome, log in, then search again.',
          openMonsterLogin: sessionOut?.openMonsterLogin === true,
        })
        return
      }

      try {
        const payload = message.payload || {}
        const out = await runMonsterBrowserJobSearch(payload)
        sendResponse(out)
      } catch (e) {
        await appendExtensionLog('error', `Monster job search: ${e?.message || e}`)
        if (e?.code === 'COOKIE_EXPIRED' || e?.code === 'MONSTER_NEEDS_DATADOME') {
          await setMonsterSessionStatus('session_invalid')
        }
        sendResponse({
          success: false,
          error: e?.message || String(e),
          message: e?.message || String(e),
          code: e?.code || e?.reason || '',
        })
      }
    })()
    return true
  }

  if (message.type === 'GET_ACTIVE_PAGE_CONTEXT') {
    ;(async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
        if (!tab?.id) {
          sendResponse({ success: false, error: 'No active tab' })
          return
        }
        const pageContext = await fetchActiveTabPageContext(tab)
        sendResponse({ success: true, pageContext })
      } catch (e) {
        sendResponse({ success: false, error: e.message })
      }
    })()
    return true
  }

  if (message.type === 'ENSURE_PLATFORM_AUTH') {
    ;(async () => {
      const out = await ensurePlatformAuthToken()
      sendResponse(out)
    })()
    return true
  }

  if (message.type === 'ADD_TO_TRACKER') {
    ;(async () => {
      const auth = await ensurePlatformAuthToken()
      if (!auth.ok) {
        sendResponse({
          success: false,
          error: 'NOT_LOGGED_IN',
          message: auth.message || 'Sign in to the candidate portal first.'
        })
        return
      }
      try {
        const out = await addJobToTracker(message.payload || {})
        if (!out.success) {
          await appendExtensionLog('warn', `Add to tracker: ${out.message || out.reason || 'failed'}`)
        } else {
          await appendExtensionLog(
            'info',
            out.duplicate ? 'Job already in tracker' : 'Added job to tracker'
          )
        }
        sendResponse(out)
      } catch (e) {
        sendResponse({ success: false, message: e?.message || String(e) })
      }
    })()
    return true
  }

  if (message.type === 'GET_CLIENT_TOOL_NAMES') {
    sendResponse({
      success: true,
      version: EXTENSION_CLIENT_TOOL_VERSION,
      tools: SUPPORTED_CLIENT_TOOLS
    })
    return true
  }

  if (message.type === 'RUN_AGENT_CLIENT_TOOLS') {
    ;(async () => {
      const results = []
      for (const action of message.actions || []) {
        const out = await executeAgentClientTool({
          ...action,
          args: normalizeClientToolArgs(action?.name, action?.args || {})
        })
        results.push({
          toolCallId: action.toolCallId,
          name: action.name,
          result: out
        })
      }
      sendResponse({ success: true, results })
    })()
    return true
  }

  if (message.type === 'OPEN_SIDE_PANEL') {
    // If the side panel is currently open, we close it by disabling it briefly
    if (isSidePanelOpen) {
      chrome.sidePanel.setOptions({ enabled: false }).then(() => {
        // re-enable immediately so it can be opened again later
        return chrome.sidePanel.setOptions({ enabled: true })
      }).catch(console.error)
      sendResponse({ success: true })
    } else {
      // It's closed, so open it
      chrome.sidePanel.setOptions({ enabled: true }).then(() => {
        if (sender?.tab?.windowId) {
          chrome.sidePanel.open({ windowId: sender.tab.windowId }).catch(err => console.error('Side panel open error', err))
          sendResponse({ success: true })
        } else {
          chrome.windows.getCurrent().then(win => {
            if (win.id) {
              chrome.sidePanel.open({ windowId: win.id }).catch(err => console.error('Side panel open error', err))
              sendResponse({ success: true })
            }
          })
        }
      }).catch(console.error)
    }
    return true
  }
})

// ─── Direct LinkedIn API requests from extension ──────────────────────────────

async function handleDirectConnectionRequest(payload) {
  try {
    const { publicIdentifier, message } = payload

    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) {
      return { success: false, error: 'Not logged into platform (open extension and sign in)' }
    }

    const quota = await fetchPlatformQuota()
    if (quota?.success === true && quota.connectionsRemaining <= 0) {
      await appendExtensionLog('warn', 'Platform daily connection limit reached')
      return { success: false, error: 'PLATFORM_DAILY_LIMIT' }
    }

    // Get CSRF Token
    const jsessionCookie = await chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'JSESSIONID' })
    if (!jsessionCookie) {
      return { success: false, error: 'Not logged into LinkedIn (missing JSESSIONID)' }
    }
    const csrfToken = jsessionCookie.value.replace(/^"(.*)"$/, '$1')

    // 1. Resolve the fsd_profile URN from the public identifier
    const urnRes = await fetch(`https://www.linkedin.com/voyager/api/identity/dash/profiles?q=memberIdentity&memberIdentity=${encodeURIComponent(publicIdentifier)}`, {
      headers: {
        'Accept': 'application/vnd.linkedin.normalized+json+2.1',
        'Csrf-Token': csrfToken
      }
    })

    if (!urnRes.ok) {
      return { success: false, error: `Failed to resolve profile URN (${urnRes.status})` }
    }

    const urnData = await urnRes.json()
    const inviteeUrn = urnData?.data?.['*elements']?.[0]

    if (!inviteeUrn) {
      return { success: false, error: 'Profile URN not found' }
    }

    // 2. Send the connection request
    const body = {
      invitee: {
        inviteeUnion: {
          memberProfile: inviteeUrn,
        },
      },
    }
    if (message) body.customMessage = message

    const pageInstanceSuffix = btoa(String.fromCharCode(...Array.from({ length: 16 }, () => Math.floor(Math.random() * 256))))

    const connectRes = await fetch('https://www.linkedin.com/voyager/api/voyagerRelationshipsDashMemberRelationships?action=verifyQuotaAndCreateV2&decorationId=com.linkedin.voyager.dash.deco.relationships.InvitationCreationResultWithInvitee-2', {
      method: 'POST',
      headers: {
        'Accept': 'application/vnd.linkedin.normalized+json+2.1',
        'Content-Type': 'application/json; charset=UTF-8',
        'Csrf-Token': csrfToken,
        'X-Li-Deco-Include-Micro-Schema': 'true',
        'X-Li-Page-Instance': `urn:li:page:d_flagship3_profile_view_base;${pageInstanceSuffix}`,
        'X-Li-Pem-Metadata': 'Voyager - Profile Actions=topcard-primary-connect-action-click,Voyager - Invitations - Actions=invite-send',
      },
      body: JSON.stringify(body)
    })

    if (connectRes.status === 200 || connectRes.status === 201) {
      await recordPlatformConnectionUsage()
      appendExtensionLog('success', `Direct connect sent to ${publicIdentifier}`)
      return { success: true }
    } else {
      let errData = {}
      try { errData = await connectRes.json() } catch (e) {}

      const code = errData?.data?.code || errData?.code || ''
      const dataStr = JSON.stringify(errData).toLowerCase()

      if (connectRes.status === 400 && (code === 'CANT_RESEND_YET' || dataStr.includes('already'))) {
        return { success: false, error: 'ALREADY_CONNECTED' }
      }
      if (connectRes.status === 400 && (code === 'QUOTA_EXCEEDED' || dataStr.includes('quota'))) {
        return { success: false, error: 'DAILY_LIMIT_REACHED' }
      }
      if ((connectRes.status === 429 || connectRes.status === 400) && code === 'CUSTOM_INVITE_LIMIT_REACHED') {
        // Retry without message logic
        delete body.customMessage
        const retryRes = await fetch('https://www.linkedin.com/voyager/api/voyagerRelationshipsDashMemberRelationships?action=verifyQuotaAndCreateV2&decorationId=com.linkedin.voyager.dash.deco.relationships.InvitationCreationResultWithInvitee-2', {
          method: 'POST',
          headers: {
            'Accept': 'application/vnd.linkedin.normalized+json+2.1',
            'Content-Type': 'application/json; charset=UTF-8',
            'Csrf-Token': csrfToken,
            'X-Li-Deco-Include-Micro-Schema': 'true',
            'X-Li-Page-Instance': `urn:li:page:d_flagship3_profile_view_base;${pageInstanceSuffix}`,
            'X-Li-Pem-Metadata': 'Voyager - Profile Actions=topcard-primary-connect-action-click,Voyager - Invitations - Actions=invite-send',
          },
          body: JSON.stringify(body)
        })
        if (retryRes.status === 200 || retryRes.status === 201) {
          await recordPlatformConnectionUsage()
          appendExtensionLog('success', `Direct connect (no note) sent to ${publicIdentifier}`)
          return { success: true }
        }
        return { success: false, error: `Retry failed with status ${retryRes.status}` }
      }
      if (connectRes.status === 429) {
        return { success: false, error: 'DAILY_LIMIT_REACHED' }
      }

      appendExtensionLog('error', `Direct connect failed ${connectRes.status}`)
      return { success: false, error: `HTTP_${connectRes.status}` }
    }
  } catch (err) {
    appendExtensionLog('error', `Direct connect error: ${err.message}`)
    return { success: false, error: err.message }
  }
}

async function updateStatus(status) {
  await chrome.storage.local.set({ linkedinStatus: status })
}

async function updateIndeedStatus(status) {
  await chrome.storage.local.set({ indeedStatus: status })
}

async function updateNaukriStatus(status) {
  await chrome.storage.local.set({ naukriStatus: status })
}

async function updateMonsterStatus(status) {
  await chrome.storage.local.set({ monsterStatus: status })
}

async function setIndeedSessionStatus(status) {
  await updateIndeedStatus(status)
}

async function setNaukriSessionStatus(status) {
  await updateNaukriStatus(status)
}

async function setMonsterSessionStatus(status) {
  await updateMonsterStatus(status)
}

async function fetchProfileForAutofill() {
  const auth = await ensurePlatformAuthToken()
  if (!auth.ok) return { error: auth.message }
  const base = await getCareerApiBase()
  const [meRes, portalRes] = await Promise.all([
    platformAuthFetch(`${base}/candidates/auth/me`, {}),
    platformAuthFetch(`${base}/candidates/self-healing`, {})
  ])
  const me = await meRes.json().catch(() => ({}))
  const portal = await portalRes.json().catch(() => ({}))
  const user = me.user || me.data?.user
  const personal = portal.data?.personal_details || portal.personal_details || {}
  return {
    name: user?.name || personal.full_name || personal.name || '',
    email: user?.email || personal.email || '',
    mobile: user?.mobile || personal.mobile || personal.phone || '',
    city: personal.city || personal.current_city || '',
    linkedinUrl: personal.linkedin_url || personal.linkedin || ''
  }
}

/** Read job context from any http(s) tab — inject script if needed, then body-text fallback. */
async function fetchActiveTabPageContext(tab) {
  const tabId = tab?.id
  const tabUrl = tab?.url || ''
  const fallback = {
    url: tabUrl,
    title: tab?.title ? String(tab.title) : '',
    site: 'auto',
    isJobPage: false,
    jobTitle: tab?.title ? String(tab.title).split(/[|\-–—]/)[0].trim() : '',
    company: '',
    location: '',
    jobDescription: ''
  }

  if (!tabId || !/^https?:\/\//i.test(tabUrl)) return fallback
  if (/^(chrome|edge|about|moz-extension|chrome-extension):/i.test(tabUrl)) return fallback

  let resp = await chrome.tabs.sendMessage(tabId, { type: 'GET_PAGE_JOB_CONTEXT' }).catch(() => null)
  if (!resp?.success || !resp.pageContext?.jobDescription) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['content-job-assistant.js']
      })
      resp = await chrome.tabs.sendMessage(tabId, { type: 'GET_PAGE_JOB_CONTEXT' }).catch(() => null)
    } catch {
      /* CSP or restricted page */
    }
  }

  if (resp?.success && resp.pageContext) {
    const pc = resp.pageContext
    if (String(pc.jobDescription || '').trim().length > 0) return pc
  }

  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const title = document.title || ''
        const h1 = document.querySelector('h1')
        const jobTitle = (h1?.innerText || title.split(/[|\-–—]/)[0] || '').replace(/\s+/g, ' ').trim()
        const root =
          document.querySelector('main, article, [role="main"], #content, .content') || document.body
        const jobDescription = (root?.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 50000)
        const hay = `${title}\n${jobDescription}`.toLowerCase()
        const signals = [
          'job description',
          'responsibilities',
          'requirements',
          'qualifications',
          'years of experience',
          'apply now',
          'we are hiring',
          'about the role'
        ].filter((s) => hay.includes(s)).length
        return {
          url: location.href,
          title,
          site: 'auto',
          isJobPage: signals >= 2 || jobDescription.length >= 500,
          jobTitle,
          company: '',
          location: '',
          jobDescription
        }
      }
    })
    if (result && String(result.jobDescription || '').trim()) return result
  } catch {
    /* ignore */
  }

  return fallback
}

function normalizeClientToolArgs(name, args) {
  const a = { ...(args || {}) }
  for (const key of ['count', 'batchSize']) {
    if (a[key] != null && typeof a[key] === 'string') {
      const n = parseInt(a[key], 10)
      if (!Number.isNaN(n)) a[key] = n
    }
  }
  if (a.confirm === 'true' || a.confirm === '1') a.confirm = true
  if (a.confirm === 'false' || a.confirm === '0') a.confirm = false
  if (name === 'fill_job_application_form') delete a.confirm
  return a
}

const EXTENSION_CLIENT_TOOL_VERSION = '1.1.7'
const SUPPORTED_CLIENT_TOOLS = [
  'search_linkedin_jobs_in_browser',
  'search_indeed_jobs_in_browser',
  'search_naukri_jobs_in_browser',
  'search_naukri_jobs_via_backend',
  'search_monster_jobs_via_backend',
  'search_linkedin_people_in_browser',
  'find_jobs_on_careers_page',
  'fill_job_application_form'
]

function resolveClientToolName(name) {
  return String(name || '').trim()
}

/** Scan active tab careers listing for job links (no LinkedIn search credit). */
async function handleFindJobsOnCareersPage(args) {
  const { authToken } = await chrome.storage.local.get('authToken')
  if (!authToken) return { success: false, error: 'Not logged in' }

  try {
    const matchKeywords = String(args.keywords || '').trim() || (await fetchJobSearchKeywords())
    const terms = matchKeywords
      .toLowerCase()
      .split(/[\s,]+/)
      .filter((t) => t.length > 2)
      .slice(0, 24)

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    if (!tab?.id) return { success: false, error: 'No active tab' }

    let scan = await chrome.tabs
      .sendMessage(tab.id, { type: 'SCAN_CAREERS_PAGE_JOBS', matchTerms: terms })
      .catch(() => null)

    if (!scan?.success && tab.url && /^https?:\/\//i.test(tab.url)) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content-job-assistant.js']
        })
        scan = await chrome.tabs
          .sendMessage(tab.id, { type: 'SCAN_CAREERS_PAGE_JOBS', matchTerms: terms })
          .catch(() => null)
      } catch {
        /* ignore */
      }
    }

    if (!scan?.success) {
      return {
        success: false,
        error: scan?.error || 'Could not read this page. Open a company careers or jobs listing page.'
      }
    }

    const jobs = (scan.jobs || []).slice(0, 20)
    return {
      success: true,
      pageUrl: scan.pageUrl || tab.url,
      pageTitle: scan.pageTitle || '',
      matchKeywords: matchKeywords,
      totalOnPage: scan.totalOnPage || jobs.length,
      totalFetched: jobs.length,
      matchedCount: jobs.filter((j) => (j.matchScore || 0) > 0).length,
      applyHowTo:
        'Open each role link in a new tab. Use ATS score or Tailor resume on that posting, or Fill form when you reach the application.',
      jobs: jobs.map((j) => ({
        title: j.title,
        company: j.company || '',
        location: j.location || '',
        jobUrl: j.url,
        matchScore: j.matchScore || 0,
        applyLabel: 'Open role'
      }))
    }
  } catch (e) {
    return { success: false, error: e.message }
  }
}

/**
 * Run people search inside an open LinkedIn tab so the native browser cookie
 * context is used — avoids CORS/credential issues from the service worker.
 * Returns an array of raw profile objects, or null if no LinkedIn tab is open.
 */
async function tryPeopleSearchInLinkedInTab(limit, keywordSets) {
  let openedTab = null
  try {
    let tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' })
    let tab = tabs.find((t) => t.status === 'complete') || tabs[0]

    // No LinkedIn tab open — create one temporarily
    if (!tab?.id) {
      openedTab = await chrome.tabs.create({ url: 'https://www.linkedin.com/mynetwork/', active: false })
      // Wait for the tab to finish loading (max 12 s)
      await new Promise((resolve) => {
        const timeout = setTimeout(resolve, 12000)
        const listener = (tabId, info) => {
          if (tabId === openedTab.id && info.status === 'complete') {
            clearTimeout(timeout)
            chrome.tabs.onUpdated.removeListener(listener)
            resolve()
          }
        }
        chrome.tabs.onUpdated.addListener(listener)
      })
      tab = openedTab
    }

    if (!tab?.id) return null

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async (limit, kwSets) => {
        function getCsrf() {
          const m = document.cookie.match(/JSESSIONID="?([^";]+)"?/)
          return m ? m[1] : ''
        }
        const csrf = getCsrf()
        if (!csrf) return null

        const baseHeaders = {
          Accept: 'application/vnd.linkedin.normalized+json+2.1',
          'Accept-Language': 'en-US,en;q=0.9',
          'Csrf-Token': csrf,
          'x-restli-protocol-version': '2.0.0',
          'x-li-lang': 'en_US'
        }

        // Strategy 1: People You May Know
        try {
          const r = await fetch(`/voyager/api/relationships/pymk?count=${limit}&start=0`, {
            headers: baseHeaders,
            credentials: 'include'
          })
          if (r.ok) {
            const data = await r.json()
            const out = []
            for (const el of data.elements || []) {
              const mini = el.memberInfo?.miniProfile || el.miniProfile
              if (!mini) continue
              const id = mini.publicIdentifier || mini.vanityName
              if (!id) continue
              out.push({
                profileId: String(mini.entityUrn || '').split(':').pop() || id,
                publicIdentifier: id,
                firstName: String(mini.firstName || ''),
                lastName: String(mini.lastName || ''),
                headline: String(mini.occupation || mini.headline || ''),
                company: String(mini.currentPositions?.[0]?.companyName || ''),
                location: String(mini.locationName || ''),
                profileUrl: `https://www.linkedin.com/in/${id}`,
                connectionDegree: 'DISTANCE_3'
              })
              if (out.length >= limit) break
            }
            if (out.length) return out
          }
        } catch {}

        // Strategy 2: GraphQL people search for each keyword set
        const graphqlQueryId = 'voyagerSearchDashClusters.181547298141ca2c72182b748713641b'
        for (const kw of (kwSets || ['Technical Recruiter']).slice(0, 4)) {
          try {
            const variables = `(start:0,origin:GLOBAL_SEARCH_HEADER,query:(keywords:${encodeURIComponent(kw)},flagshipSearchIntent:SEARCH_SRP,queryParameters:List((key:resultType,value:List(PEOPLE))),includeFiltersInResponse:false))`
            const qs = new URLSearchParams({ variables, queryId: graphqlQueryId })
            const r = await fetch(`/voyager/api/graphql?${qs}`, {
              headers: {
                ...baseHeaders,
                'x-li-page-instance': `urn:li:page:d_flagship3_search_srp_people;${Date.now()}`,
                Referer: `https://www.linkedin.com/search/results/people/?keywords=${encodeURIComponent(kw)}`
              },
              credentials: 'include'
            })
            if (!r.ok) continue
            const data = await r.json()
            const included = Array.isArray(data.included) ? data.included : []
            const byUrn = new Map()
            for (const obj of included) if (obj.entityUrn) byUrn.set(String(obj.entityUrn), obj)
            const resolve = (obj, key) => {
              if (obj[key] && typeof obj[key] === 'object') return obj[key]
              const ptr = obj[`*${key}`]
              return ptr ? byUrn.get(String(ptr)) : undefined
            }
            const clusters = data?.data?.data?.searchDashClustersByAll?.elements || []
            const out = []
            for (const cluster of clusters) {
              for (const wrapper of cluster.items || []) {
                const itemObj = resolve(wrapper, 'item') || wrapper
                const result = resolve(itemObj, 'entityResult')
                if (!result) continue
                const navUrl = String(result.navigationUrl || '')
                const m = navUrl.match(/\/in\/([^/?#]+)/)
                if (!m) continue
                const handle = decodeURIComponent(m[1])
                const title = String(result.title?.text || '')
                const sub1 = String(result.primarySubtitle?.text || '')
                const parts = title.trim().split(/\s+/)
                out.push({
                  profileId: String(result.trackingUrn || result.entityUrn || '').split(':').pop() || handle,
                  publicIdentifier: handle,
                  firstName: parts[0] || '',
                  lastName: parts.slice(1).join(' ') || '',
                  headline: sub1,
                  company: sub1.includes(' at ') ? sub1.split(' at ').slice(-1)[0].trim() : '',
                  location: String(result.secondarySubtitle?.text || ''),
                  profileUrl: `https://www.linkedin.com/in/${handle}`,
                  connectionDegree: 'DISTANCE_3'
                })
                if (out.length >= limit) break
              }
              if (out.length >= limit) break
            }
            if (out.length) return out
          } catch {}
        }

        // Strategy 3: Blended search
        for (const kw of (kwSets || ['Recruiter']).slice(0, 3)) {
          try {
            const r = await fetch(
              `/voyager/api/search/blended?count=${limit}&filters=List(resultType->PEOPLE)&origin=GLOBAL_SEARCH_HEADER&keywords=${encodeURIComponent(kw)}&q=all&start=0`,
              { headers: baseHeaders, credentials: 'include' }
            )
            if (!r.ok) continue
            const data = await r.json()
            const out = []
            for (const el of data.elements || []) {
              const mini = el.miniProfile || el.memberInfo?.miniProfile
              if (!mini) continue
              const id = mini.publicIdentifier || mini.vanityName
              if (!id) continue
              out.push({
                profileId: String(mini.entityUrn || '').split(':').pop() || id,
                publicIdentifier: id,
                firstName: String(mini.firstName || ''),
                lastName: String(mini.lastName || ''),
                headline: String(mini.occupation || mini.headline || ''),
                profileUrl: `https://www.linkedin.com/in/${id}`,
                connectionDegree: 'DISTANCE_3'
              })
              if (out.length >= limit) break
            }
            if (out.length) return out
          } catch {}
        }

        return null
      },
      args: [limit, keywordSets]
    })

    const profiles = results?.[0]?.result
    if (openedTab?.id) chrome.tabs.remove(openedTab.id).catch(() => {})
    return Array.isArray(profiles) && profiles.length ? profiles : null
  } catch (e) {
    if (openedTab?.id) chrome.tabs.remove(openedTab.id).catch(() => {})
    console.warn('[tryPeopleSearchInLinkedInTab]', e?.message)
    return null
  }
}

async function runNaukriBrowserJobSearch(args = {}) {
  const { authToken } = await chrome.storage.local.get('authToken')
  if (!authToken) return { success: false, error: 'Not logged in' }

  const sessionOut = await ensureBrowserSessionReady('naukri')
  if (sessionOut?.ok !== true) {
    return {
      success: false,
      error: sessionOut?.error || 'NAUKRI_NOT_LOGGED_IN',
      message:
        sessionOut?.message ||
        'Log in on naukri.com in Chrome and browse jobs once, then search again.',
      naukriStatus: sessionOut?.naukriStatus || 'not_logged_in',
      openNaukriLogin: sessionOut?.openNaukriLogin === true || sessionOut?.error === 'NAUKRI_NOT_LOGGED_IN',
    }
  }

  const quotaBefore = await fetchPlatformQuota()
  if (quotaBefore?.success === true && jobSearchQuotaRemaining(quotaBefore, 'naukri') <= 0) {
    return {
      success: false,
      error: 'PLATFORM_SEARCH_LIMIT',
      message: 'Daily Naukri job search limit reached. Try again tomorrow or ask admin to raise your limit.',
    }
  }

  try {
    const requestedCount = resolveJobSearchTarget(args.count)
    const { ctx, keywords, datePostedDays, filters, searchCriteria, querySets } = await prepareJobSearchPayload('naukri', args)
    if (!String(keywords || '').trim() && (!querySets?.length || !filters?.skills)) {
      return {
        success: false,
        error: 'keywords_required',
        message:
          'Set Naukri job title and skills in Settings → Job preferences (auto-filled from your resume).',
      }
    }

    await ensureBrowserSessionReady('naukri').catch(() => {})

    const naukriFilters = resolveNaukriSearchFilters(filters, ctx, args)

    const snap = await getNaukriSessionSnapshot()
    if (snap.loggedIn) {
      try {
        const ext = await runNaukriExtensionSearchFlow({
          keywords,
          ctx,
          datePostedDays,
          naukriFilters,
          requestedCount,
          querySets,
          filters,
        })
        if (ext?.empty) {
          return {
            success: false,
            error: 'no_new_jobs',
            code: 'no_new_jobs',
            message: NAUKRI_NO_NEW_JOBS_MSG,
            keywordsUsed: keywords,
            searchCriteria,
            requestedCount,
            totalFetched: 0,
            shownCount: 0,
            savedToLibrary: 0,
            savedToTracker: 0,
            duplicatesSkipped: 0,
            jobs: [],
            source: 'naukri',
          }
        }
        if (ext?.success) {
          return buildNaukriSearchSuccessResponse({
            saved: ext.saved,
            fetched: ext.fetched,
            keywords,
            requestedCount,
            filters,
            searchCriteria,
          })
        }
      } catch (extErr) {
        await appendExtensionLog('warn', `Naukri extension search: ${extErr?.message || extErr}`)
        if (extErr?.code === 'NAUKRI_NOT_LOGGED_IN' || extErr?.code === 'COOKIE_EXPIRED') {
          return {
            success: false,
            error: extErr.code,
            code: extErr.code,
            message: extErr.message || 'Log in on naukri.com in Chrome, then search again.',
            naukriStatus: 'session_invalid',
            openNaukriLogin: true,
          }
        }
      }
    }

    return {
      success: false,
      error: 'NAUKRI_NOT_LOGGED_IN',
      code: 'NAUKRI_NOT_LOGGED_IN',
      message: 'Log in on naukri.com in this browser, then search again.',
      openNaukriLogin: true,
      source: 'naukri',
    }
  } catch (e) {
    await appendExtensionLog('error', `Naukri job search: ${e?.message || e}`)
    if (e?.code === 'COOKIE_EXPIRED' || e?.code === 'NAUKRI_NOT_LOGGED_IN') {
      await setNaukriSessionStatus('session_invalid')
    }
    return {
      success: false,
      error: e?.code || 'SEARCH_FAILED',
      code: e?.code || '',
      reason: e.reason,
      message: e?.message || 'Naukri search failed. Log in on naukri.com in Chrome, then search again.',
    }
  }
}

async function searchMonsterJobsViaBackendFallback({ keywords, location, count, datePostedDays, filters }) {
  await captureMonsterSessionForSync()
  const snap = await getMonsterSessionSnapshot()
  const base = await getCareerApiBase()
  const controller = new AbortController()
  const abortTimer = setTimeout(() => controller.abort(), 28000)
  try {
    const res = await platformAuthFetch(`${base}/candidates/career/jobs/monster/search`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        keywords,
        location: String(location || '').trim(),
        count,
        datePostedDays,
        radius: filters?.radius || '30',
        cookieHeader: snap.cookieHeader,
        datadomeClientId: snap.datadomeClientId,
        profileId: snap.profileId,
        fingerprintId: snap.fingerprintId,
      }),
    })
    const data = await res.json().catch(() => ({}))
    if (data?.ok && Array.isArray(data.jobs) && data.jobs.length) {
      return { jobs: dedupeSearchJobs(data.jobs, 'monster'), meta: data }
    }
  } catch {
    /* ignore */
  } finally {
    clearTimeout(abortTimer)
  }
  return { jobs: [], meta: null }
}

async function runMonsterExtensionSearchFlow({
  keywords,
  datePostedDays,
  filters,
  requestedCount,
  searchCriteria,
  ctx,
  querySets,
}) {
  try {
    const { jobs: rawJobs } = await searchMonsterJobsInExtension({
      jobTitle: ctx?.targetRole || filters?.jobTitle || keywords,
      keywords,
      querySets,
      targetRole: ctx?.targetRole,
      skills: mergeResumeSearchSkills(ctx?.skills, filters?.skills),
      skillsStr: filters?.skills,
      experienceTitles: ctx?.experienceTitles,
      combinedKeywords: ctx?.keywords,
      location: filters?.location || '',
      count: requestedCount,
      datePostedDays,
      explvl: filters?.explvl,
      radius: filters?.radius,
    })
    let fetched = Array.isArray(rawJobs) ? rawJobs : []
    let backendMeta = null

    if (!fetched.length) {
      await appendExtensionLog('info', 'Monster browser scrape found no jobs — trying backend search with your session')
      const backend = await searchMonsterJobsViaBackendFallback({
        keywords,
        location: filters?.location || '',
        count: requestedCount,
        datePostedDays,
        filters,
      })
      fetched = backend.jobs
      backendMeta = backend.meta
    }

    if (!fetched.length) {
      return {
        success: false,
        error: 'no_new_jobs',
        code: 'no_new_jobs',
        message:
          'No Monster jobs found for this search. Log in on monster.com in Chrome, then try again or adjust job preferences.',
        keywordsUsed: keywords,
        searchCriteria,
        requestedCount,
        totalFetched: 0,
        shownCount: 0,
        savedToLibrary: 0,
        savedToTracker: 0,
        duplicatesSkipped: 0,
        jobs: [],
        source: 'monster',
      }
    }

    if (backendMeta?.ok) {
      return buildMonsterSearchSuccessResponse({
        data: {
          jobs: fetched,
          inserted: backendMeta.inserted,
          savedToTracker: backendMeta.savedToTracker,
          alreadyInTracker: backendMeta.alreadyInTracker,
          skippedDuplicates: backendMeta.skippedDuplicates,
          usage: backendMeta.usage,
        },
        keywords,
        requestedCount,
        searchCriteria,
        filters,
      })
    }

    const saved = await saveMonsterSearchResults(fetched, keywords)
    return buildMonsterSearchSuccessResponse({
      data: {
        jobs: saved.formatted,
        inserted: saved.savedToLibrary,
        savedToTracker: saved.savedToTracker,
        alreadyInTracker: saved.alreadyInTracker,
        skippedDuplicates: saved.duplicatesSkipped,
        usage: saved.quotaAfter,
      },
      keywords,
      requestedCount,
      searchCriteria,
      filters,
    })
  } catch (e) {
    if (e?.code === 'MONSTER_NOT_LOGGED_IN') {
      await setMonsterSessionStatus('not_logged_in')
      return {
        success: false,
        error: 'MONSTER_NOT_LOGGED_IN',
        code: 'MONSTER_NOT_LOGGED_IN',
        message: e.message || 'Log in on monster.com in Chrome, then search again.',
        monsterStatus: 'not_logged_in',
        openMonsterLogin: true,
        source: 'monster',
      }
    }
    throw e
  }
}

async function runMonsterBrowserJobSearch(args = {}) {
  const { authToken } = await chrome.storage.local.get('authToken')
  if (!authToken) return { success: false, error: 'Not logged in' }

  const sessionOut = await ensureBrowserSessionReady('monster')
  if (sessionOut?.ok !== true) {
    return {
      success: false,
      error: sessionOut?.error || 'MONSTER_NOT_LOGGED_IN',
      message:
        sessionOut?.message ||
        'Log in on monster.com in Chrome, then search again.',
      monsterStatus: sessionOut?.monsterStatus || 'not_logged_in',
      openMonsterLogin: sessionOut?.openMonsterLogin === true || sessionOut?.error === 'MONSTER_NOT_LOGGED_IN',
    }
  }

  const quotaBefore = await fetchPlatformQuota()
  if (quotaBefore?.success === true && jobSearchQuotaRemaining(quotaBefore, 'monster') <= 0) {
    return {
      success: false,
      error: 'PLATFORM_SEARCH_LIMIT',
      message: 'Daily Monster job search limit reached. Try again tomorrow or ask admin to raise your limit.',
    }
  }

  try {
    const requestedCount = resolveJobSearchTarget(args.count || 5)
    const { ctx, keywords, datePostedDays, filters, searchCriteria, querySets } =
      await prepareJobSearchPayload('monster', args)
    if (!String(keywords || '').trim()) {
      return {
        success: false,
        error: 'keywords_required',
        message:
          'Set Monster job title and skills in job preferences (auto-filled from your resume).',
      }
    }

    return runMonsterExtensionSearchFlow({
      keywords,
      datePostedDays,
      filters,
      requestedCount,
      searchCriteria,
      ctx,
      querySets,
    })
  } catch (e) {
    await appendExtensionLog('error', `Monster job search: ${e?.message || e}`)
    if (e?.code === 'COOKIE_EXPIRED' || e?.code === 'MONSTER_NEEDS_DATADOME') {
      await setMonsterSessionStatus('session_invalid')
    }
    return {
      success: false,
      error: e?.code || 'SEARCH_FAILED',
      code: e?.code || '',
      reason: e.reason,
      message: e?.message || 'Monster search failed. Log in on monster.com in Chrome, then try again.',
    }
  }
}

async function executeAgentClientTool(action) {
  const name = resolveClientToolName(action?.name)
  const args = normalizeClientToolArgs(name, action?.args || {})

  if (name === 'find_jobs_on_careers_page') {
    return handleFindJobsOnCareersPage(args)
  }

  if (name === 'search_linkedin_jobs_in_browser') {
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) return { success: false, error: 'Not logged in' }

    const quotaBefore = await fetchPlatformQuota()
    if (quotaBefore?.success === true && jobSearchQuotaRemaining(quotaBefore, 'linkedin') <= 0) {
      return {
        success: false,
        error: 'PLATFORM_SEARCH_LIMIT',
        message: 'Daily LinkedIn job search limit reached. Try again tomorrow or ask admin to raise your limit.'
      }
    }

    try {
      const requestedCount = resolveJobSearchTarget(args.count)
      const { ctx, keywords, datePostedDays, filters, searchCriteria, querySets } = await prepareJobSearchPayload('linkedin', args)
      if (!String(keywords || '').trim()) {
        return {
          success: false,
          error: 'keywords_required',
          message:
            'Set LinkedIn job title and skills in Settings → Job preferences (auto-filled from your resume).',
        }
      }

      const { jobs: rawJobs } = await searchJobsInExtension({
        keywords,
        querySets,
        jobTitle: ctx?.targetRole || filters.jobTitle,
        targetRole: ctx?.targetRole,
        skills: mergeResumeSearchSkills(ctx?.skills, filters.skills),
        skillsStr: filters.skills,
        experienceTitles: ctx?.experienceTitles,
        combinedKeywords: ctx?.keywords,
        location: filters.location || '',
        count: requestedCount,
        datePostedDays,
        workplaceType: filters.workplaceType,
        jobType: filters.jobType,
        experienceLevel: filters.experienceLevel ?? ctx?.filters?.linkedin?.experienceLevel,
      })
      const fetched = dedupeSearchJobs(Array.isArray(rawJobs) ? rawJobs : [], 'linkedin')
      const formatted = fetched.map(formatJobForClient)

      let savedToLibrary = 0
      let savedToTracker = 0
      let duplicatesSkipped = 0
      let importMessage = ''
      if (fetched.length) {
        const imp = await importJobsToPlatform(fetched)
        const trackerSync = await syncSearchJobsToTracker(fetched, 'linkedin')
        if (imp?.success) {
          savedToLibrary = Number(imp.inserted) || 0
          savedToTracker = Math.max(Number(imp.savedToTracker) || 0, Number(trackerSync.savedToTracker) || 0)
          duplicatesSkipped = Number(imp.skippedDuplicates) || 0
        } else {
          importMessage = imp?.message || imp?.reason || 'Could not save to job library'
          savedToTracker = Number(trackerSync.savedToTracker) || 0
        }

        applyImportMatchScores(formatted, imp?.jobs)
      }

      const quotaAfter = await fetchPlatformQuota()
      const creditNote =
        savedToLibrary > 0
          ? `1 search credit used (${savedToLibrary} new job${savedToLibrary === 1 ? '' : 's'} saved${savedToTracker > 0 ? `, ${savedToTracker} added to Application Tracker` : ''}).`
          : savedToTracker > 0
            ? `${savedToTracker} job${savedToTracker === 1 ? '' : 's'} added to Application Tracker (already in your library).`
            : fetched.length
              ? 'No search credit used (listings were already in your library or incomplete).'
              : ''

      return {
        success: true,
        keywordsUsed: keywords,
        searchCriteria,
        requestedCount,
        totalFetched: fetched.length,
        shownCount: Math.min(formatted.length, 10),
        savedToLibrary,
        savedToTracker,
        duplicatesSkipped,
        importMessage,
        creditNote,
        searchesRemaining: quotaAfter?.linkedinJobsRemaining ?? quotaAfter?.searchesRemaining,
        searchesUsed: quotaAfter?.linkedinJobsUsed ?? quotaAfter?.searchesUsed,
        dailySearchLimit: quotaAfter?.dailyLinkedinJobsLimit ?? quotaAfter?.dailySearchLimit,
        linkedinJobsRemaining: quotaAfter?.linkedinJobsRemaining ?? quotaAfter?.searchesRemaining,
        dailyLinkedinJobsLimit: quotaAfter?.dailyLinkedinJobsLimit ?? quotaAfter?.dailySearchLimit,
        applyHowTo:
          'Click Open & apply on each row (Easy Apply jobs use LinkedIn one-click apply). Saved jobs appear under Job hunt → LinkedIn jobs and Application Tracker in the dashboard.',
        jobs: formatted.slice(0, 10),
        source: 'linkedin'
      }
    } catch (e) {
      return { success: false, error: e.message }
    }
  }

  if (name === 'search_indeed_jobs_in_browser') {
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) return { success: false, error: 'Not logged in' }

    const sessionOut = await ensureBrowserSessionReady('indeed')
    if (sessionOut?.ok !== true) {
      return {
        success: false,
        error: sessionOut?.error || 'INDEED_NOT_LOGGED_IN',
        message: sessionOut?.message || 'Log in on indeed.com in Chrome, then search again.',
      }
    }

    const quotaBefore = await fetchPlatformQuota()
    if (quotaBefore?.success === true && jobSearchQuotaRemaining(quotaBefore, 'indeed') <= 0) {
      return {
        success: false,
        error: 'PLATFORM_SEARCH_LIMIT',
        message: 'Daily Indeed job search limit reached. Try again tomorrow or ask admin to raise your limit.'
      }
    }

    try {
      const requestedCount = resolveJobSearchTarget(args.count)
      const { ctx, keywords, datePostedDays, filters, searchCriteria, querySets } = await prepareJobSearchPayload('indeed', args)
      if (!String(keywords || '').trim()) {
        return {
          success: false,
          error: 'keywords_required',
          message:
            'Set Indeed job title and skills in Settings → Job preferences (auto-filled from your resume).',
        }
      }
      const { jobs: rawJobs } = await searchIndeedJobsInExtension({
        jobTitle: ctx?.targetRole || filters?.jobTitle || keywords,
        keywords,
        querySets,
        targetRole: ctx?.targetRole,
        skills: mergeResumeSearchSkills(ctx?.skills, filters?.skills),
        skillsStr: filters?.skills,
        experienceTitles: ctx?.experienceTitles,
        combinedKeywords: ctx?.keywords,
        location: filters?.location || '',
        count: requestedCount,
        country: args.country || 'IN',
        datePostedDays,
        explvl: filters?.explvl,
      })
      const fetched = Array.isArray(rawJobs) ? rawJobs : []
      if (!fetched.length) {
        return {
          success: false,
          error: 'no_new_jobs',
          message:
            'No Indeed jobs found for this search. Try again later or adjust your job preferences.',
          keywordsUsed: keywords,
          searchCriteria,
          requestedCount,
          totalFetched: 0,
          shownCount: 0,
          savedToLibrary: 0,
          savedToTracker: 0,
          duplicatesSkipped: 0,
          jobs: [],
          source: 'indeed',
        }
      }
      const saved = await saveIndeedSearchResults(fetched, keywords)
      const formatted = saved.formatted
      const savedToLibrary = saved.savedToLibrary
      const savedToTracker = saved.savedToTracker
      const alreadyInTracker = saved.alreadyInTracker || 0
      const duplicatesSkipped = saved.duplicatesSkipped
      const importMessage = saved.importMessage
      const quotaAfter = saved.quotaAfter
      const trackerNote =
        savedToTracker > 0
          ? `${savedToTracker} added to Application Tracker`
          : alreadyInTracker > 0
            ? `${alreadyInTracker} already in Application Tracker`
            : ''
      const creditNote =
        savedToLibrary > 0
          ? `${savedToLibrary} new job${savedToLibrary === 1 ? '' : 's'} saved to your library${trackerNote ? ` · ${trackerNote}` : ''}.`
          : savedToTracker > 0
            ? `${savedToTracker} job${savedToTracker === 1 ? '' : 's'} added to Application Tracker (already in your library).`
            : fetched.length
              ? 'No new jobs saved — listings may already be in your library.'
              : ''

      return {
        success: true,
        keywordsUsed: keywords,
        searchCriteria,
        requestedCount,
        totalFetched: fetched.length,
        shownCount: Math.min(formatted.length, 10),
        savedToLibrary,
        savedToTracker,
        alreadyInTracker,
        duplicatesSkipped,
        importMessage,
        creditNote,
        searchesRemaining: quotaAfter?.indeedJobsRemaining,
        searchesUsed: quotaAfter?.indeedJobsUsed,
        dailySearchLimit: quotaAfter?.dailyIndeedJobsLimit,
        indeedJobsRemaining: quotaAfter?.indeedJobsRemaining,
        dailyIndeedJobsLimit: quotaAfter?.dailyIndeedJobsLimit,
        applyHowTo:
          'Click Open & apply on each row (Indeed Apply jobs use one-click apply on Indeed). Saved jobs appear under Job hunt → Indeed jobs and Application Tracker in the dashboard.',
        jobs: formatted.slice(0, 10),
        source: 'indeed'
      }
    } catch (e) {
      const code = e?.code || ''
      if (code === 'INDEED_CHALLENGE') {
        return {
          success: false,
          error: 'INDEED_CHALLENGE',
          code: 'INDEED_CHALLENGE',
          message:
            e?.message ||
            'Indeed needs verification — complete the checkbox in the Indeed tab, then run search again.',
          openIndeedVerification: true,
        }
      }
      if (code === 'INDEED_NOT_LOGGED_IN') {
        return {
          success: false,
          error: 'INDEED_NOT_LOGGED_IN',
          code: 'INDEED_NOT_LOGGED_IN',
          message: e?.message || 'Sign in to indeed.com in Chrome, then search again.',
        }
      }
      return { success: false, error: e?.message || String(e), code: code || 'SEARCH_FAILED' }
    }
  }

  if (name === 'search_naukri_jobs_via_backend' || name === 'search_naukri_jobs_in_browser') {
    return runNaukriBrowserJobSearch(args)
  }

  if (name === 'search_monster_jobs_via_backend') {
    return runMonsterBrowserJobSearch(args)
  }

  if (name === 'search_linkedin_people_in_browser') {
    const { authToken } = await chrome.storage.local.get('authToken')
    if (!authToken) return { success: false, error: 'Not logged in' }

    const quotaBefore = await fetchPlatformQuota()
    if (quotaBefore?.success === true && Number(quotaBefore.searchesRemaining) <= 0) {
      return {
        success: false,
        error: 'PLATFORM_SEARCH_LIMIT',
        message: 'Daily search limit reached (people discovery uses the same search quota as jobs).'
      }
    }

    try {
      const requestedCount = Math.min(5, Math.max(1, Number(args.count) || 5))
      const resumeKeywords = await fetchJobSearchKeywords()

      await appendExtensionLog('info', `[FindPeople] start — count=${requestedCount} keywords="${resumeKeywords.slice(0,60)}"`)

      // Strategy 1: backend scrape — uses synced LinkedIn cookies (same as teams sidebar)
      let profiles = []
      let savedToLibrary = 0
      let importMessage = ''
      let scrapeReason = ''

      const scrapeOut = await scrapeLeadsFromBackend(requestedCount)
      console.log('[FindPeople] scrape response:', JSON.stringify(scrapeOut))
      await appendExtensionLog('info', `[FindPeople] scrape → success=${scrapeOut?.success} ok=${scrapeOut?.ok} inserted=${scrapeOut?.inserted} reason=${scrapeOut?.reason || ''} msg=${scrapeOut?.message || ''}`)

      // Backend returns { success: true, inserted, requested, usage, source }
      if (scrapeOut?.success === true || scrapeOut?.ok === true) {
        // Backend found & saved profiles — fetch the most recent ones to display
        const leads = await fetchRecentLeads(requestedCount)
        console.log('[FindPeople] leads fetched:', leads.length, leads.map(r => r.publicIdentifier || r.public_identifier))
        await appendExtensionLog('info', `[FindPeople] leads fetched=${leads.length} identifiers=[${leads.slice(0,5).map(r => r.publicIdentifier || r.public_identifier).join(',')}]`)
        profiles = leads.map((r) => ({
          publicIdentifier: String(r.publicIdentifier || r.public_identifier || ''),
          displayName: String(r.displayName || r.display_name || r.publicIdentifier || ''),
          headline: String(r.headline || ''),
          company: String(r.company || ''),
          location: String(r.location || ''),
          profileUrl: r.publicIdentifier
            ? `https://www.linkedin.com/in/${r.publicIdentifier}`
            : r.public_identifier
              ? `https://www.linkedin.com/in/${r.public_identifier}`
              : '',
          connectLabel: 'Open profile to connect'
        }))
        savedToLibrary = Number(scrapeOut.inserted) || 0
      } else {
        scrapeReason = scrapeOut?.reason || scrapeOut?.message || ''
        await appendExtensionLog('warn', `[FindPeople] scrape failed (${scrapeReason}) — trying tab search`)
        // Strategy 2: run search inside LinkedIn tab (native cookie context)
        const keywordSets = buildPeopleKeywordSets(resumeKeywords, args.keywords || '')
        const tabProfiles = await tryPeopleSearchInLinkedInTab(requestedCount, keywordSets)
        console.log('[FindPeople] tab profiles:', tabProfiles?.length ?? 'null')
        await appendExtensionLog('info', `[FindPeople] tab search → ${tabProfiles?.length ?? 'null'} profiles`)
        if (Array.isArray(tabProfiles) && tabProfiles.length) {
          const imp = await importProfilesToPlatform(tabProfiles.slice(0, requestedCount))
          if (imp?.success) savedToLibrary = Number(imp.inserted) || 0
          else importMessage = imp?.message || ''
          profiles = tabProfiles.slice(0, requestedCount).map(formatProfileForClient)
        } else {
          // Strategy 3: service-worker fetch fallback
          await appendExtensionLog('info', '[FindPeople] tab search empty — trying service worker fallback')
          const { profiles: rawProfiles, diagnostics: diag } = await searchPeopleInExtension({
            keywords: args.keywords || args.title || '',
            resumeKeywords,
            company: args.company || '',
            count: requestedCount
          })
          const fetched = Array.isArray(rawProfiles) ? rawProfiles : []
          await appendExtensionLog('info', `[FindPeople] SW fallback → ${fetched.length} profiles reason=${diag?.emptyReason || ''}`)
          console.log('[FindPeople] SW fallback:', fetched.length, 'profiles, reason:', diag?.emptyReason)
          if (!fetched.length && diag?.emptyReason === 'NOT_LOGGED_IN') {
            return {
              success: false,
              error: 'LINKEDIN_NOT_LOGGED_IN',
              message: diag.hint || 'Sign in to linkedin.com in this browser, then try again.'
            }
          }
          if (fetched.length) {
            const imp = await importProfilesToPlatform(fetched)
            if (imp?.success) savedToLibrary = Number(imp.inserted) || 0
            else importMessage = imp?.message || ''
          }
          profiles = fetched.map(formatProfileForClient)
        }
      }

      await appendExtensionLog('info', `[FindPeople] final profiles=${profiles.length} saved=${savedToLibrary}`)

      const quotaAfter = await fetchPlatformQuota()
      const creditNote =
        savedToLibrary > 0
          ? `1 search credit used (${savedToLibrary} new profile${savedToLibrary === 1 ? '' : 's'} added to Connections).`
          : profiles.length
            ? 'No search credit used (profiles already in your list or none new).'
            : 'No search credit used (nothing found).'

      const warning = !profiles.length
        ? scrapeReason === 'linkedin_not_connected'
          ? 'LinkedIn not synced. Open the extension, tap Sync LinkedIn, then retry.'
          : 'No people found. Open linkedin.com, sign in, then retry.'
        : ''

      return {
        success: true,
        requestedCount,
        keywordsUsed: resumeKeywords || args.keywords || '',
        totalFetched: profiles.length,
        shownCount: Math.min(profiles.length, 5),
        savedToLibrary,
        importMessage,
        creditNote,
        warning,
        searchesRemaining: quotaAfter?.searchesRemaining,
        searchesUsed: quotaAfter?.searchesUsed,
        dailySearchLimit: quotaAfter?.dailySearchLimit,
        connectionsRemaining: quotaAfter?.connectionsRemaining,
        connectHowTo: profiles.length
          ? 'Review each note, then tap Connect.'
          : warning,
        profiles: profiles.slice(0, 5)
      }
    } catch (e) {
      const code = e?.code || ''
      if (code === 'NOT_LOGGED_IN' || code === 'COOKIE_EXPIRED') {
        return {
          success: false,
          error: 'LINKEDIN_NOT_LOGGED_IN',
          message: 'LinkedIn session missing or expired. Sign in on linkedin.com and reload the extension.'
        }
      }
      return { success: false, error: e.message }
    }
  }

  if (name === 'fill_job_application_form') {
    const profile = await fetchProfileForAutofill()
    if (profile.error) return { success: false, error: profile.error }
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    if (!tab?.id) return { success: false, error: 'No active tab' }
    try {
      let resp = await chrome.tabs.sendMessage(tab.id, {
        type: 'FILL_APPLICATION_FORM',
        profile
      }).catch(() => null)
      if (!resp?.success && tab.url && /^https?:\/\//i.test(tab.url)) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content-job-assistant.js']
          })
          resp = await chrome.tabs.sendMessage(tab.id, {
            type: 'FILL_APPLICATION_FORM',
            profile
          }).catch(() => null)
        } catch {
          /* ignore */
        }
      }
      return resp || { success: false, error: 'Content script did not respond' }
    } catch (e) {
      return {
        success: false,
        error:
          'Could not fill form on this page. Click Apply on the job posting to open the application form, then try Fill form again.'
      }
    }
  }

  return {
    success: false,
    error: `Unknown client tool: ${name || '(empty)'}. Reload the extension at chrome://extensions (KareerGrowth → Reload), then try again.`,
    supportedTools: SUPPORTED_CLIENT_TOOLS,
    extensionClientToolVersion: EXTENSION_CLIENT_TOOL_VERSION
  }
}

;(async () => {
  await appendExtensionLog('info', 'Service worker started')
  const { authToken } = await chrome.storage.local.get('authToken')
  if (authToken) scheduleAuthCareerSync('startup')
})()
