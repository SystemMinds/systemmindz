/** Shared job-search preference helpers for the extension service worker. */

import { resolvePlatformExperienceFilters, buildSearchCriteriaSummary } from './experiencePresets.js'

function escapeRegExp(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function normalizeSkillList(skills) {
  if (!skills) return []
  if (Array.isArray(skills)) return skills.map((s) => String(s).trim()).filter(Boolean)
  return String(skills)
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
}

function stripSkillsFromTitle(title, skills) {
  let out = String(title || '').trim()
  if (!out) return ''
  for (const skill of normalizeSkillList(skills)) {
    const re = new RegExp(`\\b${escapeRegExp(skill)}\\b`, 'gi')
    out = out.replace(re, ' ')
  }
  return out.replace(/\s+/g, ' ').trim()
}

/** Indeed search `q` = job title only (never append skills). */
export function resolveIndeedJobTitle(input = {}) {
  const role = String(input.targetRole || '').trim()
  const combined = String(input.combinedKeywords || '').trim()
  const rawTitle = String(input.jobTitle || '').trim()
  const rawKeywords = String(input.keywords || '').trim()
  const skills = input.skills

  const clean = (raw) => {
    const stripped = stripSkillsFromTitle(raw, skills)
    if (!stripped) return ''
    if (role && stripped.toLowerCase() === role.toLowerCase()) return role
    if (role && combined && raw === combined) return role
    if (role && stripped.toLowerCase().startsWith(role.toLowerCase())) {
      const tail = stripSkillsFromTitle(stripped.slice(role.length), skills)
      if (!tail) return role
    }
    return stripped
  }

  if (rawTitle) {
    const t = clean(rawTitle)
    if (t) return t
  }
  if (rawKeywords) {
    const t = clean(rawKeywords)
    if (t) return t
  }
  return role
}

export function keywordsFromTitleAndSkills(title, skillsStr) {
  const t = String(title || '').trim()
  const parts = String(skillsStr || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 6)
  if (t && parts.length) return [t, ...parts.slice(0, 4)].join(' ').trim()
  if (t) return t
  return parts.join(' ').trim()
}

export function resolvePostedWithinDays(raw, fallback = 1) {
  const d = parseInt(String(raw ?? ''), 10)
  if (Number.isFinite(d) && d >= 1 && d <= 7) return d
  return fallback
}

export function normalizeDatePostedDays(platformObj = {}) {
  if (platformObj.datePostedDays != null && platformObj.datePostedDays !== '') {
    return { ...platformObj, datePostedDays: String(resolvePostedWithinDays(platformObj.datePostedDays, 1)) }
  }
  if (platformObj.datePostedPreset === 'pastWeek' || platformObj.datePostedPreset === 'pastMonth') {
    return { ...platformObj, datePostedDays: '7' }
  }
  if (platformObj.datePostedHours != null) {
    const h = parseInt(String(platformObj.datePostedHours), 10)
    if (Number.isFinite(h) && h > 0) {
      return { ...platformObj, datePostedDays: String(Math.min(7, Math.max(1, Math.ceil(h / 24)))) }
    }
  }
  return { ...platformObj, datePostedDays: '1' }
}

function skillsToField(skills) {
  if (!Array.isArray(skills)) return ''
  return skills.map((s) => String(s).trim()).filter(Boolean).slice(0, 24).join(', ')
}

function pickStr(...vals) {
  for (const v of vals) {
    const s = v == null ? '' : String(v).trim()
    if (s) return s
  }
  return ''
}

/** Same shape as CandidateFrontend resolveModalInitialValues — prefs + resume, no modal. */
export function buildAutoSearchFilters(platform, prefs, ctx, payload = {}) {
  const rawSaved = prefs?.[platform] || {}
  const saved = {
    ...normalizeDatePostedDays(rawSaved),
    ...resolvePlatformExperienceFilters(platform, rawSaved),
  }
  const usePrefs = Boolean(prefs?.enabled)
  const kw = String(ctx?.keywords || '').trim()
  const firstPart = kw.split(/\s+/).slice(0, platform === 'naukri' || platform === 'monster' ? 5 : 4).join(' ')
  const p = payload && typeof payload === 'object' ? payload : {}

  const pickPref = (key, ...fallbacks) => pickStr(usePrefs ? saved[key] : '', ...fallbacks, p[key])

  if (platform === 'linkedin') {
    const exp = resolvePlatformExperienceFilters('linkedin', { ...saved, ...p })
    const resumeSkills = skillsToField(ctx?.skills)
    return {
      jobTitle: pickStr(ctx?.targetRole, pickPref('jobTitle', firstPart, ctx?.targetRole)),
      skills: pickStr(resumeSkills, pickPref('skills', skillsToField(ctx?.skills))),
      location: pickStr(saved.location, p.location),
      workplaceType: pickStr(saved.workplaceType, p.workplaceType),
      jobType: pickStr(saved.jobType, p.jobType),
      ...exp,
      datePostedDays: pickStr(p.datePostedDays, saved.datePostedDays, '1'),
    }
  }

  if (platform === 'indeed') {
    const exp = resolvePlatformExperienceFilters('indeed', { ...saved, ...p })
    const resumeSkills = skillsToField(ctx?.skills)
    return {
      jobTitle: pickStr(ctx?.targetRole, saved.jobTitle, p.jobTitle),
      skills: pickStr(resumeSkills, saved.skills, p.skills),
      location: pickStr(saved.location, p.location),
      ...exp,
      jobType: pickStr(saved.jobType, p.jobType),
      remote: p.remote != null ? Boolean(p.remote) : Boolean(saved.remote),
      salary: pickStr(saved.salary, p.salary),
      datePostedDays: pickStr(p.datePostedDays, saved.datePostedDays, '1'),
    }
  }

  if (platform === 'naukri') {
    const exp = resolvePlatformExperienceFilters('naukri', { ...saved, ...p })
    const resumeSkills = skillsToField(ctx?.skills)
    return {
      jobTitle: pickStr(ctx?.targetRole, usePrefs ? saved.jobTitle : '', p.jobTitle),
      skills: pickStr(resumeSkills, usePrefs ? saved.skills : '', p.skills),
      wfhType: pickStr(saved.wfhType, p.wfhType),
      ...exp,
      experience: pickStr(p.experience, exp.experience, ctx?.filters?.naukri?.experience),
      ctcFilter: pickStr(saved.ctcFilter, p.ctcFilter),
      cityTypeGid: pickStr(saved.cityTypeGid, p.cityTypeGid),
      functionAreaIdGid: pickStr(saved.functionAreaIdGid, p.functionAreaIdGid),
      pgTypeGid: pickStr(saved.pgTypeGid, p.pgTypeGid),
      employement: pickStr(saved.employement, p.employement),
      datePostedDays: pickStr(p.datePostedDays, saved.datePostedDays, '1'),
    }
  }

  if (platform === 'monster') {
    const exp = resolvePlatformExperienceFilters('monster', { ...saved, ...p })
    const resumeSkills = skillsToField(ctx?.skills)
    return {
      jobTitle: pickStr(ctx?.targetRole, pickPref('jobTitle', firstPart, ctx?.targetRole)),
      skills: pickStr(resumeSkills, pickPref('skills', skillsToField(ctx?.skills))),
      location: pickStr(saved.location, ctx?.location, ctx?.filters?.monster?.location, p.location),
      ...exp,
      radius: pickStr(saved.radius, ctx?.filters?.monster?.radius, p.radius, '30'),
      datePostedDays: pickStr(p.datePostedDays, saved.datePostedDays, '1'),
    }
  }

  return {}
}

function resolveIndeedSearchTitle(prefs, ctx, payload = {}) {
  const saved = normalizeDatePostedDays(prefs?.indeed || {})
  const base = {
    targetRole: ctx?.targetRole,
    skills: ctx?.skills,
    combinedKeywords: ctx?.keywords,
  }
  if (saved.jobTitle) {
    const fromSaved = resolveIndeedJobTitle({ ...base, jobTitle: saved.jobTitle })
    if (fromSaved) return fromSaved
  }
  const fromPayload = resolveIndeedJobTitle({
    ...base,
    jobTitle: payload.jobTitle,
    keywords: payload.keywords,
  })
  if (fromPayload) return fromPayload
  return String(ctx?.targetRole || '').trim()
}

function resolveNaukriSearchTitle(prefs, ctx, payload = {}) {
  return resolvePlatformSearchTitle(prefs, ctx, payload, 'naukri')
}

function resolveMonsterSearchTitle(prefs, ctx, payload = {}) {
  return resolvePlatformSearchTitle(prefs, ctx, payload, 'monster')
}

function resolvePlatformSearchTitle(prefs, ctx, payload = {}, platform = 'naukri') {
  const saved = normalizeDatePostedDays(prefs?.[platform] || {})
  const base = {
    targetRole: ctx?.targetRole,
    skills: ctx?.skills,
    combinedKeywords: ctx?.keywords,
  }
  if (prefs?.enabled && saved.jobTitle) {
    const fromSaved = resolveIndeedJobTitle({ ...base, jobTitle: saved.jobTitle })
    if (fromSaved) return fromSaved
  }
  const fromPayload = resolveIndeedJobTitle({
    ...base,
    jobTitle: payload.jobTitle,
    keywords: payload.keywords,
  })
  if (fromPayload) return fromPayload
  return String(ctx?.targetRole || '').trim()
}

function filterSkillsNotInTitle(roleTitle, skills = []) {
  const title = String(roleTitle || '').trim().toLowerCase()
  if (!title) return normalizeSkillList(skills)
  const titleTokens = new Set(title.split(/\s+/).filter((t) => t.length > 1))
  return normalizeSkillList(skills).filter((skill) => {
    const sk = String(skill || '').trim().toLowerCase()
    if (!sk || sk.length < 2) return false
    if (titleTokens.has(sk)) return false
    if (title.includes(sk)) return false
    return true
  })
}

function composeJobHuntSearchQuery(roleTitle, skills = [], { maxSkills = 1 } = {}) {
  const role = String(roleTitle || '').trim()
  const topSkills = filterSkillsNotInTitle(role, skills).slice(0, Math.max(0, Number(maxSkills) || 0))
  const core = [role, ...topSkills].filter(Boolean).join(' ').trim()
  return core || 'software engineer'
}

function resolveSearchSkills(prefs, ctx, platform, payload = {}) {
  const saved = normalizeDatePostedDays(prefs?.[platform] || {})
  const usePrefs = Boolean(prefs?.enabled)
  const resumeSkills = skillsToField(ctx?.skills)
  const prefSkills = usePrefs ? String(saved.skills || '').trim() : ''
  const merged = []
  const seen = new Set()
  for (const raw of [...normalizeSkillList(ctx?.skills), ...normalizeSkillList(pickStr(prefSkills, resumeSkills, payload.skills))]) {
    const key = raw.toLowerCase()
    if (!key || key.length < 2 || seen.has(key)) continue
    seen.add(key)
    merged.push(raw)
  }
  return merged.slice(0, 3)
}

export function buildSearchKeywords(platform, prefs, ctx, payload = {}) {
  const fromPayload = String(payload.keywords || payload.jobTitle || '').trim()
  if (fromPayload && !ctx?.targetRole && !prefs?.enabled) return fromPayload

  if (platform === 'indeed') {
    const role = resolveIndeedSearchTitle(prefs, ctx, payload)
    const skills = resolveSearchSkills(prefs, ctx, 'indeed', payload)
    return composeJobHuntSearchQuery(role, skills, { maxSkills: 1 })
  }
  if (platform === 'naukri') {
    const role = resolveNaukriSearchTitle(prefs, ctx, payload)
    const skills = resolveSearchSkills(prefs, ctx, 'naukri', payload)
    return composeJobHuntSearchQuery(role, skills, { maxSkills: 1 })
  }
  if (platform === 'monster') {
    const role = resolveMonsterSearchTitle(prefs, ctx, payload)
    return String(role || '').trim() || composeJobHuntSearchQuery(role, [], { maxSkills: 0 })
  }

  const saved = normalizeDatePostedDays(prefs?.[platform] || {})
  const usePrefs = Boolean(prefs?.enabled)
  const resumeKw = String(ctx?.keywords || '').trim()
  const resumeTitle =
    String(ctx?.targetRole || '').trim() ||
    resumeKw.split(/\s+/).slice(0, 5).join(' ')
  const prefTitle = usePrefs ? String(saved.jobTitle || '').trim() : ''
  const title = pickStr(prefTitle, resumeTitle, fromPayload)
  const skills = resolveSearchSkills(prefs, ctx, platform, payload)
  const composed = composeJobHuntSearchQuery(title, skills, { maxSkills: 2 })
  if (composed) return composed

  if (resumeKw) return resumeKw
  return ''
}

export function resolveDatePostedDays(platform, prefs, payload = {}) {
  const fromPayload = resolvePostedWithinDays(payload.datePostedDays, 0)
  if (fromPayload >= 1) return fromPayload
  if (prefs?.enabled) {
    const saved = normalizeDatePostedDays(prefs[platform] || {})
    return resolvePostedWithinDays(saved.datePostedDays, 1)
  }
  return 1
}

export function linkedInTprFromDays(days) {
  const d = resolvePostedWithinDays(days, 1)
  return `r${d * 86400}`
}

export { buildSearchCriteriaSummary }
