/**
 * Injected on the dashboard (localhost:3002).
 * Never mutate <html> — Next.js/React will hydration-mismatch.
 * Marker is appended to <body> only after load so it runs after the app hydrates.
 */
;(function () {
  function installMarker() {
    try {
      if (document.getElementById('linkedin-auto-extension-marker')) return true
      if (!document.body) return false
      const el = document.createElement('div')
      el.id = 'linkedin-auto-extension-marker'
      el.setAttribute('data-linkedin-auto-extension', '1')
      el.setAttribute('data-version', '1.0.0')
      el.setAttribute('aria-hidden', 'true')
      el.style.cssText = 'display:none!important;width:0;height:0;overflow:hidden;position:absolute'
      document.body.appendChild(el)
      return true
    } catch (_) {
      return false
    }
  }

  function scheduleMarker() {
    installMarker()
    const retry = setInterval(() => {
      if (installMarker()) clearInterval(retry)
    }, 400)
    setTimeout(() => clearInterval(retry), 30000)

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', installMarker, { once: true })
    }
    window.addEventListener('load', installMarker, { once: true })
  }
  scheduleMarker()

  function broadcast() {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage?.local) return
      chrome.storage.local.get(['extensionLog', 'linkedinStatus', 'indeedStatus', 'naukriStatus', 'lastSync', 'lastIndeedSync', 'lastNaukriSync', 'authToken', 'isSidePanelOpen'], (data) => {
        window.postMessage(
          {
            source: 'linkedin-auto-extension',
            type: 'STATE',
            payload: {
              ...data,
              hasAuthToken: !!data.authToken,
            },
          },
          window.location.origin
        )
      })
    } catch (_) {
      /* ignore */
    }
  }

  function startBroadcast() {
    broadcast()
    setInterval(broadcast, 2500)
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    startBroadcast()
  } else {
    document.addEventListener('DOMContentLoaded', startBroadcast, { once: true })
  }

  // Intercept direct clicks to preserve user gesture for Side Panel
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action="open-side-panel"]')
    if (btn) {
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
          alert('Extension was updated or disabled. Please refresh the page to continue using the Side Panel.')
          return
        }
        chrome.runtime.sendMessage({ type: 'OPEN_SIDE_PANEL' })
      } catch (err) {
        console.error('Failed to open side panel:', err)
        if (err.message && err.message.includes('Extension context invalidated')) {
          alert('Extension was updated. Please refresh the page to continue using the Side Panel.')
        }
      }
    }
  })

  // Listen for actions from the web dashboard
  window.addEventListener('message', (event) => {
    // We only accept messages from ourselves
    if (event.source !== window || !event.data || event.data.source !== 'linkedin-auto-web') {
      return
    }

    if (event.data.type === 'EXTENSION_PING') {
      installMarker()
      window.postMessage(
        {
          source: 'linkedin-auto-extension',
          type: 'EXTENSION_PONG',
          payload: { id: event.data.payload?.id },
        },
        window.location.origin
      )
      return
    }

    if (event.data.type === 'SET_AUTH_TOKEN') {
      const payload = event.data.payload || {}
      try {
        if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
          chrome.runtime.sendMessage({
            type: 'SET_AUTH_TOKEN',
            token: payload.token,
            refreshToken: payload.refreshToken,
            xsrfToken: payload.xsrfToken,
          })
        }
      } catch (_) {
        /* ignore */
      }
      return
    }

    if (event.data.type === 'REQUEST_LINKEDIN_SYNC') {
      const requestId = event.data.payload?.requestId
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'LINKEDIN_SYNC_RESPONSE',
              payload: {
                requestId,
                success: false,
                error: 'EXTENSION_NOT_AVAILABLE',
                message: 'Extension runtime not available — reload this page after enabling the extension.'
              }
            },
            window.location.origin
          )
          return
        }
        chrome.runtime.sendMessage({ type: 'SYNC_LINKEDIN_NOW' }, (response) => {
          const err = chrome.runtime.lastError
          if (err) {
            window.postMessage(
              {
                source: 'linkedin-auto-extension',
                type: 'LINKEDIN_SYNC_RESPONSE',
                payload: { requestId, success: false, error: err.message }
              },
              window.location.origin
            )
            return
          }
          const ok = response?.ok === true || response?.success === true
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'LINKEDIN_SYNC_RESPONSE',
              payload: {
                requestId,
                success: ok,
                error: ok ? undefined : response?.error || response?.message || 'Sync failed',
                message: response?.message,
                linkedinStatus: response?.linkedinStatus,
                lastSync: response?.lastSync,
                conflict: response?.conflict,
                activeDevice: response?.activeDevice,
              }
            },
            window.location.origin
          )
        })
      } catch (e) {
        window.postMessage(
          {
            source: 'linkedin-auto-extension',
            type: 'LINKEDIN_SYNC_RESPONSE',
            payload: { requestId, success: false, error: e.message }
          },
          window.location.origin
        )
      }
      return
    }

    if (event.data.type === 'PEOPLE_SEARCH_REQUEST') {
      const requestPayload = event.data.payload
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'PEOPLE_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                success: false,
                error: 'Extension runtime not available — reload the page after enabling the extension.'
              }
            },
            window.location.origin
          )
          return
        }
        chrome.runtime.sendMessage({ type: 'PEOPLE_SEARCH', payload: requestPayload }, (response) => {
          const err = chrome.runtime.lastError
          if (err) {
            window.postMessage(
              {
                source: 'linkedin-auto-extension',
                type: 'PEOPLE_SEARCH_RESPONSE',
                payload: {
                  id: requestPayload?.id,
                  success: false,
                  error: err.message
                }
              },
              window.location.origin
            )
            return
          }
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'PEOPLE_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                ...(response || { success: false, error: 'No response from extension' })
              }
            },
            window.location.origin
          )
        })
      } catch (e) {
        window.postMessage(
          {
            source: 'linkedin-auto-extension',
            type: 'PEOPLE_SEARCH_RESPONSE',
            payload: {
              id: requestPayload?.id,
              success: false,
              error: e.message
            }
          },
          window.location.origin
        )
      }
      return
    }

    if (event.data.type === 'INDEED_JOB_SEARCH_REQUEST') {
      const requestPayload = event.data.payload
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'INDEED_JOB_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                success: false,
                error: 'Extension runtime not available — reload the page after enabling the extension.'
              }
            },
            window.location.origin
          )
          return
        }
        chrome.runtime.sendMessage({ type: 'INDEED_JOB_SEARCH', payload: requestPayload }, (response) => {
          const err = chrome.runtime.lastError
          if (err) {
            window.postMessage(
              {
                source: 'linkedin-auto-extension',
                type: 'INDEED_JOB_SEARCH_RESPONSE',
                payload: { id: requestPayload?.id, success: false, error: err.message }
              },
              window.location.origin
            )
            return
          }
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'INDEED_JOB_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                ...(response || { success: false, error: 'No response from extension', jobs: [] })
              }
            },
            window.location.origin
          )
        })
      } catch (e) {
        window.postMessage(
          {
            source: 'linkedin-auto-extension',
            type: 'INDEED_JOB_SEARCH_RESPONSE',
            payload: { id: requestPayload?.id, success: false, error: e.message, jobs: [] }
          },
          window.location.origin
        )
      }
      return
    }

    if (event.data.type === 'NAUKRI_JOB_SEARCH_REQUEST') {
      const requestPayload = event.data.payload
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'NAUKRI_JOB_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                success: false,
                error: 'EXTENSION_NOT_AVAILABLE',
                message: 'Extension runtime not available — reload this page after enabling the extension.',
              },
            },
            window.location.origin
          )
          return
        }
        chrome.runtime.sendMessage({ type: 'NAUKRI_JOB_SEARCH', payload: requestPayload }, (response) => {
          const err = chrome.runtime.lastError
          if (err) {
            window.postMessage(
              {
                source: 'linkedin-auto-extension',
                type: 'NAUKRI_JOB_SEARCH_RESPONSE',
                payload: { id: requestPayload?.id, success: false, error: err.message, jobs: [] },
              },
              window.location.origin
            )
            return
          }
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'NAUKRI_JOB_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                ...(response || { success: false, error: 'No response from extension', jobs: [] }),
              },
            },
            window.location.origin
          )
        })
      } catch (e) {
        window.postMessage(
          {
            source: 'linkedin-auto-extension',
            type: 'NAUKRI_JOB_SEARCH_RESPONSE',
            payload: { id: requestPayload?.id, success: false, error: e.message, jobs: [] },
          },
          window.location.origin
        )
      }
      return
    }

    if (event.data.type === 'MONSTER_JOB_SEARCH_REQUEST') {
      const requestPayload = event.data.payload
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'MONSTER_JOB_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                success: false,
                error: 'EXTENSION_NOT_AVAILABLE',
                message: 'Extension runtime not available — reload this page after enabling the extension.',
              },
            },
            window.location.origin
          )
          return
        }
        chrome.runtime.sendMessage({ type: 'MONSTER_JOB_SEARCH', payload: requestPayload }, (response) => {
          const err = chrome.runtime.lastError
          if (err) {
            window.postMessage(
              {
                source: 'linkedin-auto-extension',
                type: 'MONSTER_JOB_SEARCH_RESPONSE',
                payload: { id: requestPayload?.id, success: false, error: err.message, jobs: [] },
              },
              window.location.origin
            )
            return
          }
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'MONSTER_JOB_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                ...(response || { success: false, error: 'No response from extension', jobs: [] }),
              },
            },
            window.location.origin
          )
        })
      } catch (e) {
        window.postMessage(
          {
            source: 'linkedin-auto-extension',
            type: 'MONSTER_JOB_SEARCH_RESPONSE',
            payload: { id: requestPayload?.id, success: false, error: e.message, jobs: [] },
          },
          window.location.origin
        )
      }
      return
    }

    if (event.data.type === 'JOB_SEARCH_REQUEST') {
      const requestPayload = event.data.payload
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'JOB_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                success: false,
                error: 'Extension runtime not available — reload the page after enabling the extension.'
              }
            },
            window.location.origin
          )
          return
        }
        chrome.runtime.sendMessage({ type: 'JOB_SEARCH', payload: requestPayload }, (response) => {
          const err = chrome.runtime.lastError
          if (err) {
            window.postMessage(
              {
                source: 'linkedin-auto-extension',
                type: 'JOB_SEARCH_RESPONSE',
                payload: {
                  id: requestPayload?.id,
                  success: false,
                  error: err.message
                }
              },
              window.location.origin
            )
            return
          }
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'JOB_SEARCH_RESPONSE',
              payload: {
                id: requestPayload?.id,
                ...(response || { success: false, error: 'No response from extension', jobs: [] })
              }
            },
            window.location.origin
          )
        })
      } catch (e) {
        window.postMessage(
          {
            source: 'linkedin-auto-extension',
            type: 'JOB_SEARCH_RESPONSE',
            payload: {
              id: requestPayload?.id,
              success: false,
              error: e.message,
              jobs: []
            }
          },
          window.location.origin
        )
      }
      return
    }

    if (event.data.type === 'SEND_CONNECTION_REQUEST') {
      const requestPayload = event.data.payload
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
          window.postMessage(
            {
              source: 'linkedin-auto-extension',
              type: 'SEND_CONNECTION_RESPONSE',
              payload: {
                id: requestPayload?.id,
                success: false,
                error: 'Extension runtime not available — reload the page after enabling the extension.'
              }
            },
            window.location.origin
          )
          return
        }
        chrome.runtime.sendMessage(
          { type: 'SEND_CONNECTION_REQUEST', payload: requestPayload },
          (response) => {
            const err = chrome.runtime.lastError
            if (err) {
              window.postMessage(
                {
                  source: 'linkedin-auto-extension',
                  type: 'SEND_CONNECTION_RESPONSE',
                  payload: {
                    id: requestPayload?.id,
                    success: false,
                    error: err.message
                  }
                },
                window.location.origin
              )
              return
            }
            window.postMessage(
              {
                source: 'linkedin-auto-extension',
                type: 'SEND_CONNECTION_RESPONSE',
                payload: {
                  id: requestPayload?.id,
                  ...(response || { success: false, error: 'No response from extension' })
                }
              },
              window.location.origin
            )
          }
        )
      } catch (e) {
        window.postMessage(
          {
            source: 'linkedin-auto-extension',
            type: 'SEND_CONNECTION_RESPONSE',
            payload: {
              id: requestPayload?.id,
              success: false,
              error: e.message
            }
          },
          window.location.origin
        )
      }
      return
    }
  })

  if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message) => {
      if (message?.type !== 'INDEED_JOBS_SAVED') return
      window.dispatchEvent(new Event('indeed-jobs-changed'))
      window.dispatchEvent(new Event('limits-stale'))
    })
  }

})()
