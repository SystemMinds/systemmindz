/**
 * LinkedIn job discovery from the extension service worker (browser session + Voyager).
 * Mirrors backend/src/services/linkedin/linkedinJobSearch.service.js.
 */

import { voyagerGet } from './linkedinPeopleSearch.js'
import { linkedInTprFromDays, resolvePostedWithinDays } from './jobSearchPrefs.js'
import {
  buildJobSearchQuerySets,
  mergeResumeSearchSkills,
  resolveJobSearchTarget,
  resolveJobsPerApiRequest,
  resolvePerQueryJobBudget,
} from './jobSearchQuerySets.js'
import { capJobDescription } from './jobDescriptionLimits.js'

const DATE_POSTED_RANGE = {
  past24Hours: 'r86400',
  pastWeek: 'r604800',
  pastMonth: 'r2592000'
}

function extractNumericId(urn) {
  if (!urn) return ''
  const m = String(urn).match(/(\d+)/)
  return m ? m[1] : ''
}

function resolveUrn(urn, included) {
  if (!urn || !Array.isArray(included)) return null
  const key = String(urn)
  return included.find((i) => i.entityUrn === key || i['*jobPosting'] === key) || null
}

function textFrom(value) {
  if (value == null) return ''
  if (typeof value === 'string') return value.trim()
  if (typeof value === 'object' && value.text != null) return String(value.text).trim()
  return String(value).trim()
}

function buildDashJobQuery(filters) {
  const rawKw = String(filters.keywords || '')
    .trim()
    .replace(/[(),:]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  const kw = rawKw.split(' ').join('%20')

  const sf = []
  const days = resolvePostedWithinDays(filters.datePostedDays ?? filters.postedWithinDays, 0)
  const timePosted = days >= 1 ? linkedInTprFromDays(days) : null
  if (timePosted) {
    sf.push(`timePostedRange:List(${timePosted})`)
  } else if (filters.datePosted && DATE_POSTED_RANGE[filters.datePosted]) {
    sf.push(`timePostedRange:List(${DATE_POSTED_RANGE[filters.datePosted]})`)
  }
  if (filters.workplaceType === 'remote') sf.push('workplaceType:List(2)')
  if (filters.workplaceType === 'hybrid') sf.push('workplaceType:List(3)')
  if (filters.workplaceType === 'onSite') sf.push('workplaceType:List(1)')

  if (filters.jobType === 'fullTime' || filters.employmentType === 'full_time') sf.push('jobType:List(F)')
  if (filters.jobType === 'partTime' || filters.employmentType === 'part_time') sf.push('jobType:List(P)')
  if (filters.jobType === 'contract') sf.push('jobType:List(C)')
  if (filters.jobType === 'internship' || filters.employmentType === 'internship') sf.push('jobType:List(I)')

  const expLevel = filters.experienceLevel != null && String(filters.experienceLevel).trim()
  if (expLevel) sf.push(`experienceLevel:List(${String(expLevel).trim()})`)

  const parts = ['origin:JOB_SEARCH_PAGE_SEARCH_BUTTON']
  if (kw) parts.push(`keywords:${kw}`)

  const geo = filters.location && String(filters.location).trim()
  if (geo && /^\d+$/.test(geo)) parts.push(`locationUnion:(geoId:${geo})`)

  if (sf.length) parts.push(`selectedFilters:(${sf.join(',')})`)
  parts.push('spellCorrectionEnabled:true')
  return `(${parts.join(',')})`
}

function vectorImageToUrl(imageObj) {
  if (!imageObj) return null
  if (typeof imageObj === 'string') return imageObj.trim() || null
  if (imageObj.url) return String(imageObj.url).trim()
  const root = imageObj.rootUrl
  const arts = imageObj.artifacts
  if (root && Array.isArray(arts) && arts.length) {
    const best = arts[arts.length - 1]
    const seg = best?.fileIdentifyingUrlPathSegment || ''
    return `${root}${seg}`
  }
  return root ? String(root).trim() : null
}

function extractLogoUrl(...sources) {
  for (const src of sources) {
    if (!src) continue
    if (typeof src === 'string') {
      const s = src.trim()
      if (s) return s
      continue
    }
    if (typeof src !== 'object') continue

    const directCandidates = [
      src.logo,
      src.companyLogo,
      src.company?.logo,
      src.companyDetails?.company?.logo,
      src.companyDetails?.logo,
      src.logoResolutionResult,
      src.imageUnion,
      src.vectorImage,
    ]
    for (const c of directCandidates) {
      const url = vectorImageToUrl(c) || vectorImageToUrl(c?.vectorImage)
      if (url) return url
    }

    const decoratedCompany =
      src.companyDetails?.['com.linkedin.voyager.deco.jobs.norms.DecoratedCompany'] ||
      src['com.linkedin.voyager.deco.jobs.norms.DecoratedCompany']
    if (decoratedCompany) {
      const url = extractLogoUrl(decoratedCompany, decoratedCompany.company)
      if (url) return url
    }

    const attrs = src.image?.attributes || src.logo?.attributes
    if (Array.isArray(attrs)) {
      for (const attr of attrs) {
        const detail = attr?.detailData || {}
        const vi =
          detail.companyLogo?.logo?.vectorImage ||
          detail.companyLogo?.vectorImage ||
          detail.organizationalPageLogo?.vectorImage ||
          detail.logo?.vectorImage
        const url = vectorImageToUrl(vi)
        if (url) return url
      }
    }
  }
  return null
}

function extractLogoFromIncluded(included, companyDetails) {
  if (!Array.isArray(included)) return null
  const companyRef =
    companyDetails?.company?.['*company'] ||
    companyDetails?.['*company'] ||
    companyDetails?.company?.entityUrn
  if (companyRef) {
    const company = included.find((i) => String(i.entityUrn) === String(companyRef))
    const url = extractLogoUrl(company)
    if (url) return url
  }
  for (const item of included) {
    const type = String(item?.$type || '')
    if (type.includes('Company') || type.includes('Organization')) {
      const url = extractLogoUrl(item)
      if (url) return url
    }
  }
  return null
}

function extractJobIdFromCard(card, included, posting) {
  const urnFields = [
    card?.jobPostingUrn,
    card?.['*jobPosting'],
    posting?.entityUrn,
    posting?.trackingUrn,
    card?.entityUrn
  ]
  for (const urn of urnFields) {
    const id = extractNumericId(String(urn || ''))
    if (id) return id
  }
  return ''
}

function parseJobPostingCard(card, included) {
  if (!card || typeof card !== 'object') return null

  const jobPostingRef = card['*jobPosting'] || card.jobPostingUrn
  const posting = jobPostingRef ? resolveUrn(jobPostingRef, included) : null
  const jobId = extractJobIdFromCard(card, included, posting)
  if (!jobId) return null

  const title =
    textFrom(card.jobPostingTitle) ||
    textFrom(card.title) ||
    textFrom(posting?.title) ||
    textFrom(posting?.jobPostingTitle)

  const company =
    textFrom(card.primaryDescription) ||
    textFrom(card.subtitle) ||
    textFrom(posting?.companyDetails?.company?.name) ||
    textFrom(posting?.primaryDescription)

  const location =
    textFrom(card.secondaryDescription) ||
    textFrom(posting?.formattedLocation) ||
    textFrom(posting?.secondaryDescription)

  const description = capJobDescription(textFrom(posting?.description))

  let postedAt = new Date()
  const footerItems = Array.isArray(card.footerItems) ? card.footerItems : []
  for (const fi of footerItems) {
    if (fi.type === 'LISTED_DATE' && fi.timeAt) postedAt = new Date(fi.timeAt)
  }
  if (posting?.listedAt) postedAt = new Date(posting.listedAt)

  return {
    jobId,
    title,
    company,
    location,
    description,
    postedAt: postedAt.toISOString(),
    jobUrl: `https://www.linkedin.com/jobs/view/${jobId}`,
    isEasyApply: footerItems.some((fi) => fi.type === 'EASY_APPLY_TEXT'),
    employmentType: String(posting?.employmentType || posting?.employmentStatus || 'FULL_TIME'),
    workplaceType: posting?.workRemoteAllowed ? 'remote' : 'onSite',
    logoUrl: extractLogoUrl(card, posting),
  }
}

function dedupeJobsById(jobs) {
  const seen = new Set()
  const out = []
  for (const j of jobs) {
    if (!j?.jobId || seen.has(j.jobId)) continue
    seen.add(j.jobId)
    out.push(j)
  }
  return out
}

function parseJobCards(data, limit) {
  const included = Array.isArray(data?.included) ? data.included : []
  const jobs = []
  const seen = new Set()

  const pushCard = (card) => {
    const parsed = parseJobPostingCard(card, included)
    if (!parsed || seen.has(parsed.jobId)) return
    seen.add(parsed.jobId)
    jobs.push(parsed)
  }

  const elements = Array.isArray(data?.elements) ? data.elements : []
  for (const el of elements) {
    const unionCard = el?.jobCardUnion?.jobPostingCard
    if (unionCard) pushCard(unionCard)
  }

  for (const item of included) {
    const type = String(item?.$type || '')
    if (item.jobPostingTitle || type.endsWith('JobPostingCard')) {
      pushCard(item)
    }
  }

  return jobs.slice(0, limit)
}

function parseOldJobsSearch(data, limit) {
  const elements = data?.data?.elements || data?.elements || []
  const jobs = []
  for (const element of elements) {
    const hitInfo = element?.hitInfo || element
    const job =
      hitInfo?.['com.linkedin.voyager.deco.jserp.WebJobPostingWithSalary'] ||
      hitInfo?.['com.linkedin.voyager.jobs.JobPosting'] ||
      (typeof hitInfo?.entityUrn === 'string' ? hitInfo : null)
    if (!job || typeof job !== 'object') continue

    const jobId = extractNumericId(String(job.entityUrn || ''))
    if (!jobId) continue

    const companyDetails = job.companyDetails?.['com.linkedin.voyager.deco.jobs.norms.DecoratedCompany']
    const companyName = companyDetails?.company?.name || textFrom(job.companyName)

    jobs.push({
      jobId,
      title: textFrom(job.title) || textFrom(job.jobPostingTitle),
      company: textFrom(companyName),
      location: textFrom(job.formattedLocation),
      description: capJobDescription(textFrom(job.description)),
      postedAt: new Date(job.listedAt || Date.now()).toISOString(),
      jobUrl: `https://www.linkedin.com/jobs/view/${jobId}`,
      isEasyApply: job.applyMethod?.['com.linkedin.voyager.jobs.OffsiteApply'] == null,
      employmentType: String(job.employmentStatus || 'FULL_TIME'),
      workplaceType: job.workRemoteAllowed ? 'remote' : 'onSite',
      logoUrl: extractLogoUrl(job, companyDetails),
    })
    if (jobs.length >= limit) break
  }
  return jobs
}

function isJobComplete(job) {
  const jid = String(job?.jobId || '').trim()
  const title = String(job?.title || '').trim()
  const company = String(job?.company || '').trim()
  const desc = String(job?.description || '').trim()
  return Boolean(jid && title && company && desc.length > 20)
}

function padJobForImport(job) {
  const title = String(job?.title || '').trim()
  const company = String(job?.company || '').trim()
  const location = String(job?.location || '').trim()
  let description = String(job?.description || '').trim()
  const locPart = location ? ` in ${location}` : ''
  if (title && company && description.length < 50) {
    const prefix = `${title} at ${company}${locPart}`
    description = description ? `${prefix}. ${description}` : prefix
  }
  if (description.length < 50) {
    description = `${description || title}. View the full posting on LinkedIn for requirements and how to apply.`.trim()
  }
  return { ...job, description: capJobDescription(description) }
}

async function enrichJobPosting(job) {
  if (!job?.jobId) return job
  const needsLogo = !String(job.logoUrl || '').trim()
  const needsContent = !isJobComplete(job)
  if (!needsLogo && !needsContent) return job

  try {
    const data = await voyagerGet(`/voyager/api/jobs/jobPostings/${job.jobId}`)
    const payload = data?.data || data || {}
    const included = Array.isArray(data?.included) ? data.included : []
    const companyBlock = payload.companyDetails?.company || payload.companyDetails
    const logoUrl =
      job.logoUrl ||
      extractLogoUrl(payload, payload.companyDetails, companyBlock) ||
      extractLogoFromIncluded(included, payload.companyDetails)

    if (!needsContent) {
      return { ...job, logoUrl: logoUrl || null }
    }

    const title = textFrom(payload.title) || job.title
    const company =
      textFrom(companyBlock?.name) || textFrom(payload.companyName) || job.company
    const location = textFrom(payload.formattedLocation) || job.location
    const description = capJobDescription(textFrom(payload.description)) || job.description
    let postedAt = job.postedAt
    if (payload.listedAt) postedAt = new Date(payload.listedAt).toISOString()

    const deadline = payload.appliesUntil || payload.listedUntil ? new Date(payload.appliesUntil || payload.listedUntil).toISOString() : null
    const skillsList = []
    if (Array.isArray(payload.skillMatchStatuses)) {
       payload.skillMatchStatuses.forEach(sm => {
         if (sm.skill && sm.skill.name) skillsList.push(sm.skill.name)
       })
    }
    const skills = skillsList.join(', ') || null
    const experience = payload.formattedExperienceLevel || null
    const education = payload.formattedEmploymentStatus || null

    return {
      ...job,
      title,
      company,
      location,
      description,
      postedAt,
      deadline,
      skills,
      experience,
      education,
      logoUrl: logoUrl || null,
    }
  } catch {
    return job
  }
}

async function enrichIncompleteJobs(jobs, maxEnrich = 20) {
  let enriched = 0
  const out = []
  for (const job of jobs) {
    if (enriched < maxEnrich && !isJobComplete(job)) {
      out.push(await enrichJobPosting(job))
      enriched += 1
    } else {
      out.push(job)
    }
  }
  return out
}

async function enrichMissingJobLogos(jobs, maxEnrich = 15) {
  let enriched = 0
  const out = []
  for (const job of jobs) {
    if (enriched < maxEnrich && !String(job.logoUrl || '').trim()) {
      out.push(await enrichJobPosting(job))
      enriched += 1
    } else {
      out.push(job)
    }
  }
  return out
}

const DASH_DECORATION_IDS = [
  'com.linkedin.voyager.dash.deco.jobs.search.JobSearchCardsCollection-213',
  'com.linkedin.voyager.dash.deco.jobs.search.JobSearchCardsCollection-187'
]

async function searchJobsPage(filters, start) {
  const count = Math.min(25, Math.max(5, Number(filters.count) || 20))
  const query = buildDashJobQuery(filters)

  for (const decorationId of DASH_DECORATION_IDS) {
    try {
      const path = `/voyager/api/voyagerJobsDashJobCards?decorationId=${encodeURIComponent(decorationId)}&count=${count}&q=jobSearch&query=${query}&start=${start}`
      const data = await voyagerGet(path)
      const jobs = dedupeJobsById(parseJobCards(data, count))
      if (jobs.length) return jobs
    } catch (e) {
      const code = e?.code || ''
      if (code === 'COOKIE_EXPIRED' || code === 'RATE_LIMITED') throw e
    }
  }

  try {
    const p = new URLSearchParams()
    p.set('keywords', filters.keywords)
    p.set('origin', 'JOB_SEARCH_PAGE_SEARCH_BUTTON')
    p.set('start', String(start))
    p.set('count', String(count))
    const days = resolvePostedWithinDays(filters.datePostedDays ?? filters.postedWithinDays, 0)
    const timePosted = days >= 1 ? linkedInTprFromDays(days) : null
    if (timePosted) {
      p.set('f_TPR', timePosted)
    } else if (filters.datePosted && DATE_POSTED_RANGE[filters.datePosted]) {
      p.set('f_TPR', DATE_POSTED_RANGE[filters.datePosted])
    }
    if (filters.workplaceType === 'remote') p.set('f_WT', '2')
    if (filters.workplaceType === 'hybrid') p.set('f_WT', '3')
    if (filters.workplaceType === 'onSite') p.set('f_WT', '1')

    const data = await voyagerGet(`/voyager/api/jobs/search?${p.toString()}`)
    const jobs = dedupeJobsById(parseOldJobsSearch(data, count))
    if (jobs.length) return jobs
  } catch (e) {
    const code = e?.code || ''
    if (code === 'COOKIE_EXPIRED' || code === 'RATE_LIMITED') throw e
  }

  return []
}

async function collectJobsForQuery(filters, start, count, exclude) {
  const collected = []
  const maxPages = 3
  let offset = start

  for (let page = 0; page < maxPages && collected.length < count; page += 1) {
    const batch = await searchJobsPage(filters, offset)
    if (!batch.length) break

    let enriched = await enrichIncompleteJobs(batch, batch.length)
    enriched = await enrichMissingJobLogos(enriched, enriched.length)
    for (const job of enriched) {
      const jid = String(job?.jobId || '').trim()
      if (!jid || exclude.has(jid)) continue
      const title = String(job?.title || '').trim()
      const company = String(job?.company || '').trim()
      if (!title || !company) continue
      exclude.add(jid)
      collected.push(isJobComplete(job) ? job : padJobForImport(job))
      if (collected.length >= count) break
    }

    offset += batch.length
    if (batch.length < Math.min(10, count)) break
  }

  return collected
}

/**
 * @param {{ keywords?: string, querySets?: string[], location?: string, datePosted?: string, workplaceType?: string, count?: number, start?: number, excludeJobIds?: string[], skills?: string[], targetRole?: string, jobTitle?: string, skillsStr?: string, combinedKeywords?: string }} opts
 * @returns {Promise<{ jobs: object[] }>}
 */
export async function searchJobsInExtension(opts = {}) {
  const count = resolveJobSearchTarget(opts.count)
  const querySets =
    Array.isArray(opts.querySets) && opts.querySets.length
      ? opts.querySets
      : buildJobSearchQuerySets('linkedin', {
          jobTitle: opts.targetRole || opts.jobTitle,
          targetRole: opts.targetRole,
          skills: mergeResumeSearchSkills(opts.skills, opts.skillsStr),
          skillsStr: opts.skillsStr,
          experienceTitles: opts.experienceTitles,
          keywords: String(opts.keywords || '').trim(),
          combinedKeywords: opts.combinedKeywords,
        })

  const days = resolvePostedWithinDays(opts.datePostedDays ?? opts.postedWithinDays, 1)
  const exclude = new Set((opts.excludeJobIds || []).map(String))
  const collected = []
  const perQueryBudget = resolvePerQueryJobBudget(count, querySets.length)

  for (const keywords of querySets) {
    const perQuery = Math.min(resolveJobsPerApiRequest(opts.count), perQueryBudget + 2)
    const filters = {
      keywords,
      location: opts.location,
      datePostedDays: String(days),
      postedWithinDays: days,
      workplaceType: opts.workplaceType,
      jobType: opts.jobType,
      count: perQuery,
    }
    const batch = await collectJobsForQuery(filters, 0, perQuery, exclude)
    let queryTaken = 0
    for (const job of batch) {
      if (queryTaken >= perQueryBudget) break
      collected.push(job)
      queryTaken += 1
    }
  }

  return { jobs: collected.slice(0, count) }
}
