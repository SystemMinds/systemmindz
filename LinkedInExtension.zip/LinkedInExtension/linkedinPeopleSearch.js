/**
 * LinkedIn people discovery from the extension service worker (same-origin session as the user).
 * Mirrors backend/src/services/linkedin/linkedinPeopleSearch.service.js strategies.
 */

const DEFAULT_GRAPHQL_QUERY_ID =
  'voyagerSearchDashClusters.181547298141ca2c72182b748713641b'

function parseHandle(url) {
  if (!url) return ''
  const path = String(url).split('?')[0]
  const m = path.match(/\/in\/([^/]+)\/?$/)
  return m ? decodeURIComponent(m[1]) : ''
}

function vectorImageToUrl(imageObj) {
  if (!imageObj) return null
  if (typeof imageObj === 'string') return imageObj.trim() || null
  if (imageObj.url) return String(imageObj.url).trim()
  const root = imageObj.rootUrl
  const arts = imageObj.artifacts
  if (root && Array.isArray(arts) && arts.length) {
    const best = arts[arts.length - 1]
    const seg = best?.fileIdentifyingUrlPathSegment || ''
    return `${root}${seg}`
  }
  return root ? String(root).trim() : null
}

function extractProfilePictureFromEntityResult(result) {
  if (!result || typeof result !== 'object') return null
  const direct = vectorImageToUrl(result.image)
  if (direct) return direct
  const attrs = result.image?.attributes
  if (Array.isArray(attrs)) {
    for (const attr of attrs) {
      const detail = attr?.detailData || {}
      const candidates = [
        detail.nonEntityProfilePicture?.vectorImage,
        detail.profilePicture?.displayImageReference?.vectorImage,
        detail.profilePicture?.vectorImage,
        detail.profilePicture?.displayImageUrn,
      ]
      for (const c of candidates) {
        const url = vectorImageToUrl(c)
        if (url) return url
      }
    }
  }
  return null
}

function pictureFromMini(mini) {
  return (
    vectorImageToUrl(mini?.picture) ||
    vectorImageToUrl(mini?.profilePicture?.displayImageReference) ||
    vectorImageToUrl(mini?.profilePicture) ||
    null
  )
}

function miniProfileToResult(mini, degree = 'DISTANCE_3') {
  const publicIdentifier = String(mini.publicIdentifier || mini.vanityName || '')
  if (!publicIdentifier) return null
  const profilePicture = pictureFromMini(mini)
  return {
    profileId: String(mini.entityUrn || '').split(':').pop() || publicIdentifier,
    publicIdentifier,
    firstName: String(mini.firstName || ''),
    lastName: String(mini.lastName || ''),
    headline: String(mini.occupation || mini.headline || ''),
    company: String(mini.currentPositions?.[0]?.companyName || ''),
    location: String(mini.locationName || mini.geoLocationName || ''),
    profileUrl: `https://www.linkedin.com/in/${publicIdentifier}`,
    connectionDegree: degree,
    profilePicture
  }
}

function scanForProfiles(data, limit) {
  const root = data && typeof data === 'object' ? data : {}
  const included = Array.isArray(root.included) ? root.included : []
  const out = []
  for (const item of included) {
    const t = String(item.$type || '')
    if (!t.includes('MiniProfile') && !t.includes('Profile') && !t.includes('Member')) continue
    const p = miniProfileToResult(item)
    if (p) {
      out.push(p)
      if (out.length >= limit) break
    }
  }
  return out
}

import { buildLinkedInVoyagerHeaders } from './linkedinDevice.js'

async function buildVoyagerHeaders() {
  return buildLinkedInVoyagerHeaders()
}

export async function voyagerGet(pathWithQuery) {
  const headers = await buildVoyagerHeaders()
  const url = pathWithQuery.startsWith('http')
    ? pathWithQuery
    : `https://www.linkedin.com${pathWithQuery}`
  const res = await fetch(url, { method: 'GET', headers, credentials: 'include' })
  if (res.status === 401) {
    const e = new Error('COOKIE_EXPIRED')
    e.code = 'COOKIE_EXPIRED'
    throw e
  }
  if (res.status === 429) {
    const e = new Error('RATE_LIMITED')
    e.code = 'RATE_LIMITED'
    throw e
  }
  if (!res.ok) {
    const t = await res.text().catch(() => '')
    const e = new Error(`HTTP_${res.status}`)
    e.code = 'HTTP_ERROR'
    e.bodySnippet = t.slice(0, 200)
    throw e
  }
  return res.json()
}

async function tryPymk(limit) {
  const endpoints = [
    `/voyager/api/relationships/pymk?count=${limit}&start=0`,
    `/voyager/api/growth/normalizedInvitations/pymk?count=${limit}&start=0`
  ]
  for (const path of endpoints) {
    try {
      const data = await voyagerGet(path)
      const out = []
      for (const el of data.elements || []) {
        const mini = el.memberInfo?.miniProfile || el.miniProfile || (typeof el === 'object' ? el : null)
        if (!mini || typeof mini !== 'object') continue
        const p = miniProfileToResult(mini, 'DISTANCE_3')
        if (p) out.push(p)
        if (out.length >= limit) break
      }
      if (!out.length) out.push(...scanForProfiles(data, limit))
      if (out.length) return out
    } catch {
      /* try next */
    }
  }
  return []
}

async function tryConnectionsSearch(limit) {
  const recruiterTerms = ['recruiter', 'talent', 'HR', 'hiring']
  const out = []
  for (const term of recruiterTerms) {
    if (out.length >= limit) break
    try {
      const data = await voyagerGet(
        `/voyager/api/relationships/connections?q=search&keywords=${encodeURIComponent(term)}&count=${limit}&start=0`
      )
      for (const el of data.elements || []) {
        const mini = el.miniProfile || el
        const p = miniProfileToResult(mini, 'DISTANCE_1')
        if (p) out.push(p)
        if (out.length >= limit) break
      }
      if (!out.length) out.push(...scanForProfiles(data, limit))
    } catch {
      /* continue */
    }
  }
  return out.slice(0, limit)
}

function parseGraphqlResponse(json, limit) {
  const included = Array.isArray(json.included) ? json.included : []
  const byUrn = new Map()
  for (const obj of included) {
    if (obj.entityUrn) byUrn.set(String(obj.entityUrn), obj)
  }
  function resolve(obj, key) {
    if (obj[key] && typeof obj[key] === 'object') return obj[key]
    const ptrKey = `*${key}`
    if (obj[ptrKey]) return byUrn.get(String(obj[ptrKey]))
    return undefined
  }
  const clusters = json?.data?.data?.searchDashClustersByAll?.elements || []
  const out = []
  for (const cluster of clusters) {
    const items = cluster.items || []
    for (const wrapper of items) {
      const itemObj = resolve(wrapper, 'item') || wrapper
      const result = resolve(itemObj, 'entityResult')
      if (!result) continue
      const navUrl = String(result.navigationUrl || '')
      const handle = parseHandle(navUrl)
      if (!handle) continue
      const title = String(result.title?.text || '')
      const sub1 = String(result.primarySubtitle?.text || '')
      const sub2 = String(result.secondarySubtitle?.text || '')
      const parts = title.trim().split(/\s+/)
      const id = String(result.trackingUrn || result.entityUrn || '').split(':').pop() || handle
      out.push({
        profileId: id,
        publicIdentifier: handle,
        firstName: parts[0] || '',
        lastName: parts.slice(1).join(' ') || '',
        headline: sub1,
        company: sub1.includes(' at ') ? sub1.split(' at ').slice(1).join(' at ').trim() : '',
        location: sub2,
        profileUrl: `https://www.linkedin.com/in/${handle}`,
        connectionDegree: 'DISTANCE_3',
        profilePicture: extractProfilePictureFromEntityResult(result),
      })
      if (out.length >= limit) return out
    }
  }
  if (!out.length) return scanForProfiles(json, limit)
  return out
}

export function buildPeopleKeywordSets(resumeKeywords = '', customKeywords = '') {
  const custom = String(customKeywords || '').trim()
  if (custom) return [custom]

  const raw = String(resumeKeywords || '').trim()
  const parts = raw.split(/\s+/).filter(Boolean)
  const role = parts.slice(0, 3).join(' ') || 'Software Engineer'
  const skills = parts.slice(3, 6)

  const fromResume = [
    `Recruiter ${role} ${skills.join(' ')}`.trim(),
    `Talent Acquisition ${role}`,
    `Technical Recruiter ${skills[0] || role}`,
    `Hiring Manager ${role}`,
    `"Human Resources" ${role}`,
    `Recruiter ${skills.slice(1, 3).join(' ')}`.trim(),
    `"Talent Partner" ${role}`
  ].filter(Boolean)

  const defaults = ['Technical Recruiter', 'Talent Acquisition', 'Recruiter', 'Hiring Manager']
  const seen = new Set()
  const out = []
  const exclusion = 'NOT "looking for" NOT "seeking" NOT "open to" NOT "student" NOT "aspiring"'

  for (const k of [...fromResume, ...defaults]) {
    const key = k.toLowerCase()
    if (seen.has(key)) continue
    seen.add(key)
    out.push(`${k} ${exclusion}`)
  }
  return out
}

export async function checkLinkedInSession() {
  try {
    await buildVoyagerHeaders()
    return { ok: true }
  } catch (e) {
    return { ok: false, code: e.code || 'NOT_LOGGED_IN', message: e.message }
  }
}

async function fetchMemberByPublicIdentifier(publicIdentifier) {
  const slug = String(publicIdentifier || '').trim()
  if (!slug) return null

  const pick = (profiles) => {
    if (!profiles?.length) return null
    return profiles.find((p) => p.publicIdentifier === slug) || profiles[0]
  }

  try {
    const dash = await voyagerGet(
      `/voyager/api/identity/dash/profiles?q=memberIdentity&memberIdentity=${encodeURIComponent(slug)}`
    )
    const hit = pick(scanForProfiles(dash, 8))
    if (hit) return hit

    const view = await voyagerGet(`/voyager/api/identity/profiles/${encodeURIComponent(slug)}/profileView`)
    return pick(scanForProfiles(view, 8))
  } catch (e) {
    if (e.code === 'COOKIE_EXPIRED' || e.code === 'RATE_LIMITED') throw e
    return null
  }
}

async function enrichMissingProfilePictures(profiles, maxEnrich = 15) {
  const max = Math.min(15, Math.max(0, Number(maxEnrich) || 15))
  let enriched = 0
  const out = []
  for (const profile of profiles || []) {
    if (enriched < max && !String(profile.profilePicture || '').trim()) {
      try {
        const hit = await fetchMemberByPublicIdentifier(profile.publicIdentifier)
        if (hit?.profilePicture) {
          out.push({ ...profile, profilePicture: hit.profilePicture })
        } else {
          out.push(profile)
        }
      } catch {
        out.push(profile)
      }
      enriched += 1
    } else {
      out.push(profile)
    }
  }
  return out
}

async function finalizeProfiles(profiles) {
  if (!Array.isArray(profiles) || !profiles.length) return profiles
  return enrichMissingProfilePictures(profiles, profiles.length)
}

async function tryBlendedPeopleSearch(keywords, limit) {
  const kw = String(keywords || '').trim()
  if (!kw) return []
  try {
    const data = await voyagerGet(
      `/voyager/api/search/blended?count=${limit}&filters=List(resultType->PEOPLE)&origin=GLOBAL_SEARCH_HEADER&keywords=${encodeURIComponent(
        kw
      )}&q=${encodeURIComponent(kw)}&start=0`
    )
    const fromElements = []
    for (const el of data.elements || []) {
      const mini = el.miniProfile || el.memberInfo?.miniProfile
      if (mini) {
        const p = miniProfileToResult(mini)
        if (p) fromElements.push(p)
      }
    }
    if (fromElements.length) return fromElements.slice(0, limit)
    return scanForProfiles(data, limit)
  } catch {
    return []
  }
}

async function tryGraphqlPeopleSearch(limit, offset, queryId, keywordSets) {
  const qid = queryId || DEFAULT_GRAPHQL_QUERY_ID
  const baseHeaders = await buildVoyagerHeaders()
  const sets = Array.isArray(keywordSets) && keywordSets.length ? keywordSets : ['Technical Recruiter']
  for (const kw of sets) {
    const encoded = encodeURIComponent(kw)
    const starts = [offset, offset + 10, offset + 20]
    const collected = new Map()
    for (const start of starts) {
      const variables = `(start:${start},origin:GLOBAL_SEARCH_HEADER,query:(keywords:${encoded},flagshipSearchIntent:SEARCH_SRP,queryParameters:List((key:resultType,value:List(PEOPLE))),includeFiltersInResponse:false))`
      const qs = new URLSearchParams({ variables, queryId: qid })
      const url = `https://www.linkedin.com/voyager/api/graphql?${qs.toString()}`
      try {
        const res = await fetch(url, {
          method: 'GET',
          headers: {
            ...baseHeaders,
            'x-li-page-instance': `urn:li:page:d_flagship3_search_srp_people;${Date.now()}`,
            Referer: `https://www.linkedin.com/search/results/people/?keywords=${encoded}`
          },
          credentials: 'include'
        })
        if (res.status === 401) {
          const e = new Error('COOKIE_EXPIRED')
          e.code = 'COOKIE_EXPIRED'
          throw e
        }
        if (!res.ok) continue
        const data = await res.json()
        const profiles = parseGraphqlResponse(data, limit)
        if (profiles.length) {
          for (const p of profiles) {
            collected.set(p.profileId, p)
            if (collected.size >= limit) break
          }
          if (collected.size >= limit) break
        }
      } catch (e) {
        if (e.code === 'COOKIE_EXPIRED') throw e
      }
    }
    if (collected.size > 0) {
      return Array.from(collected.values()).slice(0, limit)
    }
  }
  return []
}

async function tryCompanySearch(companyName, limit) {
  try {
    const orgData = await voyagerGet(
      `/voyager/api/organization/companies?decorationId=com.linkedin.voyager.deco.organization.web.WebFullCompanyMain-12&q=universalName&universalName=${encodeURIComponent(
        companyName.toLowerCase().replace(/\s+/g, '-')
      )}`
    )
    const company = orgData.elements?.[0]
    if (!company) return []
    const companyUrn = String(company.entityUrn || '')
    const companyId = companyUrn.split(':').pop()
    if (!companyId) return []
    const empData = await voyagerGet(
      `/voyager/api/search/blended?count=${limit}&filters=List(currentCompany->${companyId},resultType->PEOPLE)&origin=COMPANY_PAGE_PEOPLE&q=all&start=0`
    )
    return scanForProfiles(empData, limit)
  } catch {
    return []
  }
}

/**
 * @param {{ count?: number, offset?: number, company?: string, keywords?: string, resumeKeywords?: string, graphqlQueryId?: string }} opts
 * @returns {Promise<{ profiles: object[], diagnostics?: object }>}
 */
export async function searchPeopleInExtension(opts = {}) {
  const limit = Math.min(24, Math.max(4, Number(opts.count) || 16))
  const offset = Math.max(0, Number(opts.offset) || 0)
  const company = opts.company && String(opts.company).trim() ? String(opts.company).trim() : undefined
  const graphqlQueryId = opts.graphqlQueryId && String(opts.graphqlQueryId).trim()
  const keywordSets = buildPeopleKeywordSets(opts.resumeKeywords, opts.keywords)
  const diagnostics = { strategies: [], linkedinSession: null }

  const session = await checkLinkedInSession()
  diagnostics.linkedinSession = session
  if (!session.ok) {
    return {
      profiles: [],
      diagnostics: {
        ...diagnostics,
        emptyReason: 'NOT_LOGGED_IN',
        hint: 'Open linkedin.com in Chrome, sign in, then reload the extension and try again.'
      }
    }
  }

  const pymk = await tryPymk(limit)
  diagnostics.strategies.push({ name: 'pymk', count: pymk.length })
  if (pymk.length) return { profiles: await finalizeProfiles(pymk), diagnostics }

  const conns = await tryConnectionsSearch(limit)
  diagnostics.strategies.push({ name: 'connections', count: conns.length })
  if (conns.length) return { profiles: await finalizeProfiles(conns), diagnostics }

  const graphql = await tryGraphqlPeopleSearch(limit, offset, graphqlQueryId, keywordSets)
  diagnostics.strategies.push({ name: 'graphql', count: graphql.length, keywordsTried: keywordSets.slice(0, 4) })
  if (graphql.length) return { profiles: await finalizeProfiles(graphql), diagnostics }

  for (const kw of keywordSets.slice(0, 3)) {
    const blended = await tryBlendedPeopleSearch(kw, limit)
    if (blended.length) {
      diagnostics.strategies.push({ name: 'blended', count: blended.length, keyword: kw })
      return { profiles: await finalizeProfiles(blended), diagnostics }
    }
  }
  diagnostics.strategies.push({ name: 'blended', count: 0 })

  if (company) {
    const companyHits = await tryCompanySearch(company, limit)
    diagnostics.strategies.push({ name: 'company', count: companyHits.length, company })
    if (companyHits.length) return { profiles: await finalizeProfiles(companyHits), diagnostics }
  }

  return {
    profiles: [],
    diagnostics: {
      ...diagnostics,
      emptyReason: 'NO_RESULTS',
      hint:
        'LinkedIn returned no people. Stay logged in on linkedin.com, avoid VPN blocks, and try again. Recruiters are searched using your resume role/skills.'
    }
  }
}
